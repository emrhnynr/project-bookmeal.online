-- phpMyAdmin SQL Dump
-- version 4.6.6
-- https://www.phpmyadmin.net/
--
-- Anamakine: localhost
-- Üretim Zamanı: 17 Nis 2021, 16:15:08
-- Sunucu sürümü: 5.7.17-log
-- PHP Sürümü: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `mudavim`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `admin_adsoyad` varchar(200) COLLATE utf16_turkish_ci DEFAULT NULL,
  `admin_mail` varchar(200) COLLATE utf16_turkish_ci DEFAULT NULL,
  `admin_sifre` varchar(200) COLLATE utf16_turkish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf16 COLLATE=utf16_turkish_ci;

--
-- Tablo döküm verisi `admin`
--

INSERT INTO `admin` (`admin_id`, `admin_adsoyad`, `admin_mail`, `admin_sifre`) VALUES
(1, 'Emirhan Yener', 'emrhnynr1@gmail.com', '672ffdc78cad98f12b4581d810b983e5'),
(2, 'Buğrahan Saka', 'bugrahansaka@gmail.com', '401d006880a27f564f68335fddf584f3');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `bloglar`
--

CREATE TABLE `bloglar` (
  `blog_id` int(11) NOT NULL,
  `blog_baslik` varchar(200) COLLATE utf16_turkish_ci DEFAULT NULL,
  `blog_text` text COLLATE utf16_turkish_ci,
  `blog_foto` varchar(200) COLLATE utf16_turkish_ci DEFAULT NULL,
  `blog_seo` varchar(200) COLLATE utf16_turkish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf16 COLLATE=utf16_turkish_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `kullanici`
--

CREATE TABLE `kullanici` (
  `kullanici_id` int(11) NOT NULL,
  `kullanici_kayitzaman` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `kullanici_mail` varchar(100) COLLATE utf16_turkish_ci DEFAULT NULL,
  `kullanici_sifre` varchar(100) COLLATE utf16_turkish_ci DEFAULT NULL,
  `kullanici_yetki` enum('1','5') COLLATE utf16_turkish_ci DEFAULT NULL,
  `restoran_id` int(11) DEFAULT NULL,
  `kullanici_adminonay` enum('yes','no') COLLATE utf16_turkish_ci NOT NULL DEFAULT 'no',
  `kullanici_aktivasyonkod` varchar(50) COLLATE utf16_turkish_ci DEFAULT NULL,
  `kullanici_mailonay` enum('no','yes') COLLATE utf16_turkish_ci NOT NULL DEFAULT 'no',
  `kullanici_swiftcode` varchar(100) COLLATE utf16_turkish_ci DEFAULT NULL,
  `kullanici_taxid` varchar(100) COLLATE utf16_turkish_ci DEFAULT NULL,
  `kullanici_bill` varchar(200) COLLATE utf16_turkish_ci DEFAULT NULL,
  `uyelik_turu` enum('1','2','3','4','expired') COLLATE utf16_turkish_ci DEFAULT NULL,
  `uyelik_baslangic` timestamp NULL DEFAULT NULL,
  `uyelik_bitis` timestamp NULL DEFAULT NULL,
  `kullanici_uniq` varchar(1000) COLLATE utf16_turkish_ci DEFAULT NULL,
  `kullanici_asama` enum('1','2') COLLATE utf16_turkish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf16 COLLATE=utf16_turkish_ci;

--
-- Tablo döküm verisi `kullanici`
--

INSERT INTO `kullanici` (`kullanici_id`, `kullanici_kayitzaman`, `kullanici_mail`, `kullanici_sifre`, `kullanici_yetki`, `restoran_id`, `kullanici_adminonay`, `kullanici_aktivasyonkod`, `kullanici_mailonay`, `kullanici_swiftcode`, `kullanici_taxid`, `kullanici_bill`, `uyelik_turu`, `uyelik_baslangic`, `uyelik_bitis`, `kullanici_uniq`, `kullanici_asama`) VALUES
(31, '2021-03-07 07:47:01', 'emrhnynr1@gmail.com', '60f1320e47c3123a497a9b3c954aacf6', '5', 22, 'no', 'B428F', 'yes', NULL, NULL, NULL, '4', '2021-03-07 07:52:50', '2021-03-21 07:52:50', NULL, '2'),
(32, '2021-03-07 08:24:01', 'emirhanyeneer@gmail.com', '60f1320e47c3123a497a9b3c954aacf6', '1', NULL, 'yes', '53927', 'yes', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `onsiparisler`
--

CREATE TABLE `onsiparisler` (
  `siparis_id` int(11) NOT NULL,
  `siparis_no` int(11) DEFAULT NULL,
  `siparis_zaman` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `kullanici_id` int(11) DEFAULT NULL,
  `siparis_ozeltalep` text COLLATE utf16_turkish_ci,
  `siparis_kisisayisi` decimal(20,0) DEFAULT NULL,
  `siparis_tutar` decimal(10,0) DEFAULT NULL,
  `restoran_id` int(11) DEFAULT NULL,
  `siparis_turu` enum('1','5','','') COLLATE utf16_turkish_ci DEFAULT NULL,
  `siparis_variszaman` timestamp NULL DEFAULT NULL,
  `siparis_kaybolmazaman` timestamp NULL DEFAULT NULL,
  `siparis_bildirim` enum('0','1','','') COLLATE utf16_turkish_ci NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf16 COLLATE=utf16_turkish_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `onsiparisyemek`
--

CREATE TABLE `onsiparisyemek` (
  `siparisyemek_id` int(11) NOT NULL,
  `siparis_id` int(11) DEFAULT NULL,
  `yemek_id` int(11) DEFAULT NULL,
  `yemek_adet` decimal(10,0) DEFAULT NULL,
  `siparisyemek_turu` enum('1','5') COLLATE utf16_turkish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf16 COLLATE=utf16_turkish_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `qrkodlar`
--

CREATE TABLE `qrkodlar` (
  `kod_id` int(11) NOT NULL,
  `restoran_id` int(11) DEFAULT NULL,
  `qr_url` varchar(500) COLLATE utf16_turkish_ci DEFAULT NULL,
  `qr_foto` varchar(200) COLLATE utf16_turkish_ci DEFAULT NULL,
  `qr_masano` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf16 COLLATE=utf16_turkish_ci;

--
-- Tablo döküm verisi `qrkodlar`
--

INSERT INTO `qrkodlar` (`kod_id`, `restoran_id`, `qr_url`, `qr_foto`, `qr_masano`) VALUES
(861, 22, 'r-emirrestoran-1', 'dimg/qrkodlar/22_masa-1.png', 1),
(862, 22, 'r-emirrestoran-2', 'dimg/qrkodlar/22_masa-2.png', 2),
(863, 22, 'r-emirrestoran-3', 'dimg/qrkodlar/22_masa-3.png', 3),
(864, 22, 'r-emirrestoran-4', 'dimg/qrkodlar/22_masa-4.png', 4),
(865, 22, 'r-emirrestoran-5', 'dimg/qrkodlar/22_masa-5.png', 5),
(866, 22, 'r-emirrestoran-6', 'dimg/qrkodlar/22_masa-6.png', 6),
(867, 22, 'r-emirrestoran-7', 'dimg/qrkodlar/22_masa-7.png', 7),
(868, 22, 'r-emirrestoran-8', 'dimg/qrkodlar/22_masa-8.png', 8),
(869, 22, 'r-emirrestoran-9', 'dimg/qrkodlar/22_masa-9.png', 9),
(870, 22, 'r-emirrestoran-10', 'dimg/qrkodlar/22_masa-10.png', 10),
(1032, 22, 'r-emirrestoran-11', 'dimg/qrkodlar/22_masa-11.png', 11),
(1033, 22, 'r-emirrestoran-12', 'dimg/qrkodlar/22_masa-12.png', 12),
(1034, 22, 'r-emirrestoran-13', 'dimg/qrkodlar/22_masa-13.png', 13),
(1035, 22, 'r-emirrestoran-14', 'dimg/qrkodlar/22_masa-14.png', 14),
(1036, 22, 'r-emirrestoran-15', 'dimg/qrkodlar/22_masa-15.png', 15),
(1037, 22, 'r-emirrestoran-16', 'dimg/qrkodlar/22_masa-16.png', 16),
(1038, 22, 'r-emirrestoran-17', 'dimg/qrkodlar/22_masa-17.png', 17),
(1039, 22, 'r-emirrestoran-18', 'dimg/qrkodlar/22_masa-18.png', 18),
(1040, 22, 'r-emirrestoran-19', 'dimg/qrkodlar/22_masa-19.png', 19),
(1041, 22, 'r-emirrestoran-20', 'dimg/qrkodlar/22_masa-20.png', 20),
(1042, 22, 'r-emirrestoran-21', 'dimg/qrkodlar/22_masa-21.png', 21),
(1043, 22, 'r-emirrestoran-22', 'dimg/qrkodlar/22_masa-22.png', 22),
(1044, 22, 'r-emirrestoran-23', 'dimg/qrkodlar/22_masa-23.png', 23),
(1045, 22, 'r-emirrestoran-24', 'dimg/qrkodlar/22_masa-24.png', 24),
(1046, 22, 'r-emirrestoran-25', 'dimg/qrkodlar/22_masa-25.png', 25),
(1047, 22, 'r-emirrestoran-26', 'dimg/qrkodlar/22_masa-26.png', 26),
(1048, 22, 'r-emirrestoran-27', 'dimg/qrkodlar/22_masa-27.png', 27),
(1049, 22, 'r-emirrestoran-28', 'dimg/qrkodlar/22_masa-28.png', 28),
(1050, 22, 'r-emirrestoran-29', 'dimg/qrkodlar/22_masa-29.png', 29),
(1051, 22, 'r-emirrestoran-30', 'dimg/qrkodlar/22_masa-30.png', 30),
(1052, 22, 'r-emirrestoran-31', 'dimg/qrkodlar/22_masa-31.png', 31),
(1053, 22, 'r-emirrestoran-32', 'dimg/qrkodlar/22_masa-32.png', 32),
(1054, 22, 'r-emirrestoran-33', 'dimg/qrkodlar/22_masa-33.png', 33),
(1055, 22, 'r-emirrestoran-34', 'dimg/qrkodlar/22_masa-34.png', 34),
(1056, 22, 'r-emirrestoran-35', 'dimg/qrkodlar/22_masa-35.png', 35),
(1057, 22, 'r-emirrestoran-36', 'dimg/qrkodlar/22_masa-36.png', 36),
(1058, 22, 'r-emirrestoran-37', 'dimg/qrkodlar/22_masa-37.png', 37),
(1059, 22, 'r-emirrestoran-38', 'dimg/qrkodlar/22_masa-38.png', 38),
(1060, 22, 'r-emirrestoran-39', 'dimg/qrkodlar/22_masa-39.png', 39),
(1061, 22, 'r-emirrestoran-40', 'dimg/qrkodlar/22_masa-40.png', 40),
(1062, 22, 'r-emirrestoran-41', 'dimg/qrkodlar/22_masa-41.png', 41),
(1063, 22, 'r-emirrestoran-42', 'dimg/qrkodlar/22_masa-42.png', 42),
(1064, 22, 'r-emirrestoran-43', 'dimg/qrkodlar/22_masa-43.png', 43),
(1065, 22, 'r-emirrestoran-44', 'dimg/qrkodlar/22_masa-44.png', 44),
(1066, 22, 'r-emirrestoran-45', 'dimg/qrkodlar/22_masa-45.png', 45),
(1067, 22, 'r-emirrestoran-46', 'dimg/qrkodlar/22_masa-46.png', 46),
(1068, 22, 'r-emirrestoran-47', 'dimg/qrkodlar/22_masa-47.png', 47),
(1069, 22, 'r-emirrestoran-48', 'dimg/qrkodlar/22_masa-48.png', 48),
(1070, 22, 'r-emirrestoran-49', 'dimg/qrkodlar/22_masa-49.png', 49),
(1071, 22, 'r-emirrestoran-50', 'dimg/qrkodlar/22_masa-50.png', 50),
(1072, 22, 'r-emirrestoran-51', 'dimg/qrkodlar/22_masa-51.png', 51),
(1073, 22, 'r-emirrestoran-52', 'dimg/qrkodlar/22_masa-52.png', 52),
(1074, 22, 'r-emirrestoran-53', 'dimg/qrkodlar/22_masa-53.png', 53),
(1075, 22, 'r-emirrestoran-54', 'dimg/qrkodlar/22_masa-54.png', 54),
(1076, 22, 'r-emirrestoran-55', 'dimg/qrkodlar/22_masa-55.png', 55),
(1077, 22, 'r-emirrestoran-56', 'dimg/qrkodlar/22_masa-56.png', 56),
(1078, 22, 'r-emirrestoran-57', 'dimg/qrkodlar/22_masa-57.png', 57),
(1079, 22, 'r-emirrestoran-58', 'dimg/qrkodlar/22_masa-58.png', 58),
(1080, 22, 'r-emirrestoran-59', 'dimg/qrkodlar/22_masa-59.png', 59),
(1081, 22, 'r-emirrestoran-60', 'dimg/qrkodlar/22_masa-60.png', 60),
(1082, 22, 'r-emirrestoran-61', 'dimg/qrkodlar/22_masa-61.png', 61),
(1083, 22, 'r-emirrestoran-62', 'dimg/qrkodlar/22_masa-62.png', 62),
(1084, 22, 'r-emirrestoran-63', 'dimg/qrkodlar/22_masa-63.png', 63);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `restoranlar`
--

CREATE TABLE `restoranlar` (
  `restoran_id` int(11) NOT NULL,
  `restoran_ad` varchar(200) COLLATE utf16_turkish_ci DEFAULT NULL,
  `restoran_seo` varchar(200) COLLATE utf16_turkish_ci DEFAULT NULL,
  `restoran_subdomain` varchar(200) COLLATE utf16_turkish_ci DEFAULT NULL,
  `restoran_adres` text COLLATE utf16_turkish_ci,
  `restoran_eyalet` varchar(100) COLLATE utf16_turkish_ci DEFAULT NULL,
  `restoran_logo` varchar(300) COLLATE utf16_turkish_ci DEFAULT NULL,
  `restoran_sehir` varchar(200) COLLATE utf16_turkish_ci DEFAULT NULL,
  `restoran_semt` int(11) DEFAULT NULL,
  `restoran_wifi` varchar(10) COLLATE utf16_turkish_ci DEFAULT NULL,
  `restoran_vale` varchar(10) COLLATE utf16_turkish_ci DEFAULT NULL,
  `restoran_dismekan` varchar(10) COLLATE utf16_turkish_ci DEFAULT NULL,
  `restoran_icmekan` varchar(10) COLLATE utf16_turkish_ci DEFAULT NULL,
  `restoran_sigaraicmealan` varchar(10) COLLATE utf16_turkish_ci DEFAULT NULL,
  `restoran_yorumsayisi` int(11) NOT NULL DEFAULT '0',
  `restoran_ortalamapuan` float NOT NULL DEFAULT '0',
  `restoran_hizpuani` float NOT NULL DEFAULT '0',
  `restoran_hizdegerlendiren` int(11) DEFAULT '0',
  `restoran_yorumurl` varchar(300) COLLATE utf16_turkish_ci DEFAULT NULL,
  `restoran_pazartesiacilis` varchar(50) COLLATE utf16_turkish_ci DEFAULT NULL,
  `restoran_pazartesikapanis` varchar(50) COLLATE utf16_turkish_ci DEFAULT NULL,
  `restoran_saliacilis` varchar(50) COLLATE utf16_turkish_ci DEFAULT NULL,
  `restoran_salikapanis` varchar(50) COLLATE utf16_turkish_ci DEFAULT NULL,
  `restoran_carsambaacilis` varchar(50) COLLATE utf16_turkish_ci DEFAULT NULL,
  `restoran_carsambakapanis` varchar(50) COLLATE utf16_turkish_ci DEFAULT NULL,
  `restoran_persembeacilis` varchar(50) COLLATE utf16_turkish_ci DEFAULT NULL,
  `restoran_persembekapanis` varchar(50) COLLATE utf16_turkish_ci DEFAULT NULL,
  `restoran_cumaacilis` varchar(50) COLLATE utf16_turkish_ci DEFAULT NULL,
  `restoran_cumakapanis` varchar(50) COLLATE utf16_turkish_ci DEFAULT NULL,
  `restoran_cumartesiacilis` varchar(50) COLLATE utf16_turkish_ci DEFAULT NULL,
  `restoran_cumartesikapanis` varchar(50) COLLATE utf16_turkish_ci DEFAULT NULL,
  `restoran_pazaracilis` varchar(50) COLLATE utf16_turkish_ci DEFAULT NULL,
  `restoran_pazarkapanis` varchar(50) COLLATE utf16_turkish_ci DEFAULT NULL,
  `restoran_mailonay` enum('no','yes') COLLATE utf16_turkish_ci NOT NULL DEFAULT 'no',
  `restoran_masasayisi` int(11) DEFAULT NULL,
  `restoran_renk` varchar(100) COLLATE utf16_turkish_ci NOT NULL DEFAULT '#043D75',
  `kart_preorder` enum('yes','no') COLLATE utf16_turkish_ci DEFAULT 'yes',
  `restoran_currency` enum('$','£','€','₹','₺') COLLATE utf16_turkish_ci DEFAULT NULL,
  `restoran_menuaciklama` varchar(500) COLLATE utf16_turkish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf16 COLLATE=utf16_turkish_ci;

--
-- Tablo döküm verisi `restoranlar`
--

INSERT INTO `restoranlar` (`restoran_id`, `restoran_ad`, `restoran_seo`, `restoran_subdomain`, `restoran_adres`, `restoran_eyalet`, `restoran_logo`, `restoran_sehir`, `restoran_semt`, `restoran_wifi`, `restoran_vale`, `restoran_dismekan`, `restoran_icmekan`, `restoran_sigaraicmealan`, `restoran_yorumsayisi`, `restoran_ortalamapuan`, `restoran_hizpuani`, `restoran_hizdegerlendiren`, `restoran_yorumurl`, `restoran_pazartesiacilis`, `restoran_pazartesikapanis`, `restoran_saliacilis`, `restoran_salikapanis`, `restoran_carsambaacilis`, `restoran_carsambakapanis`, `restoran_persembeacilis`, `restoran_persembekapanis`, `restoran_cumaacilis`, `restoran_cumakapanis`, `restoran_cumartesiacilis`, `restoran_cumartesikapanis`, `restoran_pazaracilis`, `restoran_pazarkapanis`, `restoran_mailonay`, `restoran_masasayisi`, `restoran_renk`, `kart_preorder`, `restoran_currency`, `restoran_menuaciklama`) VALUES
(22, 'Emir Restoran', 'emirrestoran', NULL, NULL, NULL, 'dimg/restoranlogo/6044868ed3bea.png', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, '09:00', '23:00', '09:00', '23:00', '09:00', '23:00', '09:00', '23:00', '09:00', '23:00', '09:00', '23:00', '', '', 'no', 63, '#F24A06', 'yes', '₺', '');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `restoranmenucesit`
--

CREATE TABLE `restoranmenucesit` (
  `cesit_id` int(11) NOT NULL,
  `cesit_ad` varchar(200) COLLATE utf16_turkish_ci DEFAULT NULL,
  `restoran_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf16 COLLATE=utf16_turkish_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `siparisler`
--

CREATE TABLE `siparisler` (
  `siparis_id` int(11) NOT NULL,
  `siparis_no` int(11) DEFAULT NULL,
  `siparis_zaman` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `kullanici_ip` varchar(200) COLLATE utf16_turkish_ci DEFAULT NULL,
  `siparis_ozeltalep` text COLLATE utf16_turkish_ci,
  `siparis_kisisayisi` decimal(20,0) DEFAULT NULL,
  `siparis_tutar` decimal(10,0) DEFAULT NULL,
  `restoran_id` int(11) DEFAULT NULL,
  `siparis_turu` enum('1','5') COLLATE utf16_turkish_ci DEFAULT NULL,
  `siparis_variszaman` timestamp NULL DEFAULT NULL,
  `siparis_kaybolmazaman` timestamp NULL DEFAULT NULL,
  `siparis_bildirim` enum('0','1') COLLATE utf16_turkish_ci NOT NULL DEFAULT '1',
  `siparis_masano` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf16 COLLATE=utf16_turkish_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `siparisyemek`
--

CREATE TABLE `siparisyemek` (
  `siparisyemek_id` int(11) NOT NULL,
  `siparis_id` int(11) DEFAULT NULL,
  `yemek_id` int(11) DEFAULT NULL,
  `yemek_adet` decimal(10,0) DEFAULT NULL,
  `siparisyemek_turu` enum('1','5') COLLATE utf16_turkish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf16 COLLATE=utf16_turkish_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `uyelikpaketleri`
--

CREATE TABLE `uyelikpaketleri` (
  `paket_id` int(11) NOT NULL,
  `paket_ad` varchar(200) COLLATE utf16_turkish_ci DEFAULT NULL,
  `paket_fiyat` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf16 COLLATE=utf16_turkish_ci;

--
-- Tablo döküm verisi `uyelikpaketleri`
--

INSERT INTO `uyelikpaketleri` (`paket_id`, `paket_ad`, `paket_fiyat`) VALUES
(1, 'QR MENU', 13),
(2, 'PRE-ORDER', 30),
(3, 'QR MENU ORDER', 30),
(4, 'QR MENU ORDER + PRE-ORDER', 45);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `yemekler`
--

CREATE TABLE `yemekler` (
  `yemek_id` int(11) NOT NULL,
  `restoran_id` int(11) DEFAULT NULL,
  `yemek_ad` varchar(200) COLLATE utf16_turkish_ci DEFAULT NULL,
  `yemek_aciklama` varchar(400) COLLATE utf16_turkish_ci DEFAULT NULL,
  `yemek_fiyat` float DEFAULT NULL,
  `yemek_cesit` varchar(10) COLLATE utf16_turkish_ci DEFAULT NULL,
  `yemek_foto` varchar(200) COLLATE utf16_turkish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf16 COLLATE=utf16_turkish_ci;

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Tablo için indeksler `bloglar`
--
ALTER TABLE `bloglar`
  ADD PRIMARY KEY (`blog_id`);

--
-- Tablo için indeksler `kullanici`
--
ALTER TABLE `kullanici`
  ADD PRIMARY KEY (`kullanici_id`);

--
-- Tablo için indeksler `onsiparisler`
--
ALTER TABLE `onsiparisler`
  ADD PRIMARY KEY (`siparis_id`);

--
-- Tablo için indeksler `onsiparisyemek`
--
ALTER TABLE `onsiparisyemek`
  ADD PRIMARY KEY (`siparisyemek_id`);

--
-- Tablo için indeksler `qrkodlar`
--
ALTER TABLE `qrkodlar`
  ADD PRIMARY KEY (`kod_id`);

--
-- Tablo için indeksler `restoranlar`
--
ALTER TABLE `restoranlar`
  ADD PRIMARY KEY (`restoran_id`);

--
-- Tablo için indeksler `restoranmenucesit`
--
ALTER TABLE `restoranmenucesit`
  ADD PRIMARY KEY (`cesit_id`);

--
-- Tablo için indeksler `siparisler`
--
ALTER TABLE `siparisler`
  ADD PRIMARY KEY (`siparis_id`);

--
-- Tablo için indeksler `siparisyemek`
--
ALTER TABLE `siparisyemek`
  ADD PRIMARY KEY (`siparisyemek_id`);

--
-- Tablo için indeksler `uyelikpaketleri`
--
ALTER TABLE `uyelikpaketleri`
  ADD PRIMARY KEY (`paket_id`);

--
-- Tablo için indeksler `yemekler`
--
ALTER TABLE `yemekler`
  ADD PRIMARY KEY (`yemek_id`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- Tablo için AUTO_INCREMENT değeri `bloglar`
--
ALTER TABLE `bloglar`
  MODIFY `blog_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- Tablo için AUTO_INCREMENT değeri `kullanici`
--
ALTER TABLE `kullanici`
  MODIFY `kullanici_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
--
-- Tablo için AUTO_INCREMENT değeri `onsiparisler`
--
ALTER TABLE `onsiparisler`
  MODIFY `siparis_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- Tablo için AUTO_INCREMENT değeri `onsiparisyemek`
--
ALTER TABLE `onsiparisyemek`
  MODIFY `siparisyemek_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- Tablo için AUTO_INCREMENT değeri `qrkodlar`
--
ALTER TABLE `qrkodlar`
  MODIFY `kod_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1085;
--
-- Tablo için AUTO_INCREMENT değeri `restoranlar`
--
ALTER TABLE `restoranlar`
  MODIFY `restoran_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
--
-- Tablo için AUTO_INCREMENT değeri `restoranmenucesit`
--
ALTER TABLE `restoranmenucesit`
  MODIFY `cesit_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- Tablo için AUTO_INCREMENT değeri `siparisler`
--
ALTER TABLE `siparisler`
  MODIFY `siparis_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- Tablo için AUTO_INCREMENT değeri `siparisyemek`
--
ALTER TABLE `siparisyemek`
  MODIFY `siparisyemek_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- Tablo için AUTO_INCREMENT değeri `uyelikpaketleri`
--
ALTER TABLE `uyelikpaketleri`
  MODIFY `paket_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- Tablo için AUTO_INCREMENT değeri `yemekler`
--
ALTER TABLE `yemekler`
  MODIFY `yemek_id` int(11) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
