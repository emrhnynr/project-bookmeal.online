<?php require_once 'header.php'; ?>
<title>Topluluk Sözleşmesi</title>

<div class="main-wrapper scrollspy-container">
		
			<!-- start hero-header -->
			
			<div class="container pt-10 pb-30">
			
				
				
				<div style="padding: 50px;" class="row mt-40 mb-30">
					
					<h2 align="center">Topluluk Sözleşmesi</h2>
					<p>
						
İşbu Kullanıcı Sözleşmesi (“Sözleşme”), Bookmeal Teknoloji A.Ş. (“Şirket”, “Biz”, “Bizim”, “Bookmeal”) ile www.bookmeal.online adresinde yer alan siteye (“Site”) kullanıcı (“Kullanıcı”, “Kullanıcılar”, “Müşteri”, “Siz”) ve Tüzel Kişi’nin Temsilcisi (“Yetkili Kişi”) olarak kaydolan kişi arasında akdedilmektedir.

Sözleşme, Kullanıcı tarafından elektronik ortamda kayıt sürecinde kabulü ile birlikte yürürlüğe girecek olup, taraflarca Sözleşme’de belirtilen usuller doğrultusunda sona erdirilmediği sürece yürürlükte kalmaya devam edecektir.


<h3>Madde 2. Sözleşme'nin Konusu ve Kapsamı</h3>


<p>İşbu Kullanıcı Sözleşmesi (“Sözleşme”), Bookmeal Teknoloji A.Ş. (“Şirket”, “Biz”, “Bizim”, “Bookmeal”) ile www.bookmeal.online adresinde yer alan siteye (“Site”) kullanıcı (“Kullanıcı”, “Kullanıcılar”, “Müşteri”, “Siz”) ve Tüzel Kişi’nin Temsilcisi İşbu Sözleşme, Kullanıcı tarafından, Site üzerinden erişilen sipariş yönetim ve QR Menü sistemi çözümü programından (“Uygulama”, “bookmeal.online") faydalanılmasına ve Kullanıcı tarafından Uygulama’ya yüklenen verilere (“İçerik”) ilişkin koşul ve şartlar ile ilgili tarafların hak ve yükümlülüklerinin belirlenmesi amacıyla akdedilmektedir. Site kapsamında Site ve Uygulama’nın kullanımına ilişkin olarak Bookmeal tarafından Kullanıcılar’a sunulan kullanım koşulları, kural ve şartlar da işbu Sözleşme’nin eki ve ayrılmaz bir parçası niteliğinde olup burada yer alan hak ve yükümlülüklerle birlikte tarafların hak ve yükümlülüklerinin tamamını oluşturmaktadır. (“Yetkili Kişi”) olarak kaydolan kişi arasında akdedilmektedir.</p>

<h3>Madde 3. Tarafların Hak ve Yükümlülükleri</h3>

<p><b>3.1</b> Kullanıcı, Uygulama’dan faydalanmak için Bookmeal tarafından talep edilen bilgileri tam, doğru ve güncel bir şekilde sağlayarak işbu Sözleşme’yi onaylaması gerektiğini bildiğini beyan eder. Kullanıcı statüsünün tesisi sırasında sağlanan bilgilerde herhangi bir değişiklik olması halinde, söz konusu bilgiler derhal güncellenmek zorundadır. Bu bilgilerin eksik veya gerçeğe aykırı olarak verilmesi ya da güncel olmaması nedeniyle Site ya da Uygulama’ya erişim sağlanamamasından ve bunlardan faydalanılamamasından Bookmeal sorumlu değildir.</p>

<p><b>3.2</b> Kullanıcı, 18 yaşını doldurmuş olduğunu ve işbu Sözleşme’yi akdetmek için gereken yasal yetkiye sahip bulunduğunu beyan eder. Kullanıcı’nın Site’ye bir işletme adına erişiyor olması halinde, Kullanıcı buna ilişkin gerekli yetkiyi haiz olduğunu kabul ve beyan eder. Gerektiği durumlarda Bookmeal Kullanıcı’dan işletme adına yetkili kişi olduğunu doğrulamasını isteyebilir. Bu durumda Kullanıcı statüsü ile hak ve yükümlülükler söz konusu işletmeye ait olacaktır.</p>


<p><b>3.3</b> Kullanıcı, tek bir Kullanıcı hesabı tesis etme hakkına sahip olup, Kullanıcı hesabının Bookmeal tarafından askıya alınması veya sona erdirilmesini takiben Kullanıcı tarafından aynı veya başka bilgiler kullanılarak ikinci bir hesap tesis edilmesi yasaktır. Bookmeal’ın herhangi bir gerekçe göstermeksizin, tamamen kendi iradesine tabi olarak Kullanıcı hesabının açılmasını reddetme hakkı ve kullanıcı sözleşmesini feshetme hakkı saklıdır.</p>

<p><b>3.4</b> Kullanıcı tarafından Site’ye erişim e-posta adresi ve şifresi kullanılarak gerçekleştirilecektir. Bu şifrenin gizliliğinin ve güvenliğinin korunmasından Kullanıcı sorumlu olacak olup Site ve Uygulama üzerinden söz konusu bilgilerin kullanımı ile gerçekleştirilen her türlü faaliyetin Kullanıcı tarafından gerçekleştirildiği kabul edilecek, bu faaliyetlerden doğan her türlü yasal ve cezai sorumluluk Kullanıcı’ya ait olacaktır. Kullanıcı, şifresinin yetkisiz kullanımı veya güvenliğin başka şekilde ihlalinden haberdar olduğunda bu durumu derhal Bookmeal'a bildirmek zorundadır.</p>

<p><b>3.5</b> Kullanıcı, Uygulama’yı yalnızca yasalara uygun faaliyetleri için kullanacağını, işbu Sözleşme, ekleri, yürürlükteki mevzuat ve Uygulama’ya ilişkin olarak Site’de öngörülen diğer hüküm ve koşullara uygun davranacağını kabul ve taahhüt eder. Kullanıcı, Uygulama ve Site’yi üçüncü kişilere hizmet sunmak için yetkili olduğu sürece üçüncü kişi adına kullanabilecektir. Kullanıcı bu kapsamda, söz konusu kişilerin de işbu Sözleşme ve kendisi için geçerli olan diğer tüm hükümlere uygun davranmasını sağlayacaktır.</p>

<p><b>3.6</b> Kullanıcı, muhtelif zamanlarda Uygulama’yı kullanması için üçüncü bir kişiyi (“Yetkilendirilmiş Kullanıcı”, “Personel Hesabı”, “Personel”) yetkilendirebilir. Personel’in kim olacağı ve Uygulama kapsamındaki yetki seviyesi Kullanıcı tarafından belirlenecektir. Kullanıcı, Yetkilendirilmiş Kullancılar’ın Uygulama’yı kullanmasından sorumlu olup Yetkilendirilmiş Kullanıcılar’ın Uygulama’ya erişimini her zaman kontrol edecek ve Yetkilendirilmiş Kullanıcı’nın Uygulama’ya erişim seviyesini her zaman ve bir nedene bağlı olmaksızın değiştirebilecek veya erişimini iptal edebilecektir. Kullanıcı ve Yetkilendirilmiş Kullanıcı arasında Uygulama’ya erişime ilişkin olarak bir uyuşmazlık çıkması halinde Yetkilendirilmiş Kullanıcı’nın Uygulama veya İçerik’e erişimini ve erişim seviyesine ilişkin kararı Kullanıcı verecektir.</p>

<p><b>3.7</b> Kullanıcı tarafından paylaşılan İçerik Kullanıcı’nın mülkiyetinde olup İçerik’e ilişkin tüm sorumluluk Kullanıcı’ya aittir. Bookmeal, işbu Sözleşme kapsamında Kullanıcı tarafından kendisine sağlanan lisans kapsamında İçerik’i kullanma hakkını sahiptir. İçerik’e veya İçerik’in yol açabileceği kayıp veya zararlara ilişkin olarak Bookmeal sorumlu tutulamayacak olup sayılanlarla sınırlı olmaksızın, hukuka uygunluk, İçerik’in doğruluğuna ilişkin olarak Bookmeal’ın hiçbir sorumluluğu bulunmamaktadır. Kullanıcı, Bookmeal'ın finansal düzenlemeler başta olmak üzere, yürürlükteki mevzuattan kaynaklanan gereksinimlere dayanarak İçerik’i Uygulama’dan ve sistemlerinden silebileceğini ve Bookmeal’ın kayıp veriler de dahil olmak üzere bu kapsamda meydana gelebilecek zararlardan sorumlu olmadığını kabul eder.</p>

<p><b>3.8</b> Kullanıcı, Bookmeal’ın veya Uygulama’nın üçüncü kişiler tarafından barındırılıyor olması halinde bu üçüncü kişilerin bilgisayar ve ağ sistemlerinin güvenlik ve bütünlüğünü tehlikeye düşürecek faaliyetlerde bulunmayacağını, Uygulama’yı, Uygulama’nın, Site’nin veya hizmetlerin sunulduğu diğer sistemlerin işlerliğine veya Uygulama ve Site’den faydalanan diğer kullanıcıların bunlardan faydalanmasına engel olacak veya bunlara zarar verecek şekilde veya hatalı kullanmamayı, Uygulama’nın barındırıldığı bilgisayar sistemlerine veya Uygulama’ya kendisine tanınan erişim kapsamı dışında yetkisiz erişim sağlamayacağını, Site’ye Bookmeal’ın ve üçüncü kişilerin bilgisayar sistemlerine, cihazlarına ve yazılımlarına zarar verecek dosyalar veya hukuka aykırı İçerikler (Kullanıcı’nın üzerinde kullanma hakkı olmayan telif hakkıyla korunan veya ticari sır niteliğinde olan İçerikler ve diğer materyaller de dahil olmak üzere) aktarmayacağını ve yüklemeyeceğini, hizmetlerin sunulmasında veya Site’nin çalışmasında kullanılan bilgisayar programlarını olağan kullanım için mutlak olarak gerekli olmadığı sürece değiştirmeyeceğini, kopyalamayacağını, uyarlamayacağını, çoğaltmayacağını, kaynak kodu oluşturmayacağını veya tersine mühendislik işlemleri yapmayacağını kabul ve taahhüt eder.</p>

<p><b>3.9</b> Kullanıcı, Uygulama’yı kullanmasının aylık işlem ve saklama hacimleri de dahil olmak üzere kısıtlamalara tabi olabileceğini kabul eder. Söz konusu kısıtlamalar Uygulama içinde belirtilecektir.</p>

<p><b>3.10</b> Kullanıcı, Uygulama’ya yüklenen İçerikler’in kopyalarını saklayacaktır. Bookmeal, veri kaybını önlemek için gerekli politika, yasal yükümlülükler ve usullere uymakla beraber, İçerik’in kaybının söz konusu olmayacağına dair garanti vermemektedir. Bookmeal, nasıl ortaya çıktığına bakılmaksızın İçerik’in kaybından sorumlu değildir.</p>

<p><b>3.11</b> Bookmeal, Kullanıcı tarafından kendisi ile paylaşılan bilgi ve verileri işbu Sözleşme’ye ek niteliğinde olan “Gizlilik Politikası” kapsamında saklayacak ve kullanacaktır. Kullanıcı, Bookmeal’ın yürürlükteki mevzuat uyarınca yetkili makamlardan talep gelmesi halinde Kullanıcı’nın kendisinde bulunan bilgilerini ilgili yetkili makamlarla paylaşabileceğini kabul eder. Bunun dışında Kullanıcı’ya ve Kullanıcı tarafından Site üzerinden gerçekleştirilen işlemlere ait bilgiler Kullanıcı’nın güvenliği, Bookmeal’ın yükümlülüklerini bazı istatistiki değerlendirmeler için kullanılabilecektir. Bookmeal ayrıca, müşteri bilgisi dahilinde ya da onayıyla bilgilendirme e-postası gönderme, ödeme bilgisi paylaşma gibi talep edilen hizmetleri sağlamak için İçerik’i diğer kullanıcılarla ve üçüncü kişilerle paylaşma hakkına sahiptir. Bu bilgiler ayrıca bir veritabanı üzerinde tasnif edilip muhafaza edilebilecek ve Bookmeal, Kullanıcı’nın söz konusu kullanım ve işlem bilgilerini performans değerlendirmeleri, Bookmeal’ın ve iş ortaklarının pazarlama kampanyaları, yıllık raporlar ve benzeri işlemler için bunlar için gerekli olan süre boyunca söz konusu verilerin anonim hale getirilmesiyle birlikte kullanabilecektir. Kullanıcı, İçerik ve diğer bilgilerin Bookmeal veya üçüncü kişiler tarafından Türkiye’de veya yurt dışında bulunan veri merkezlerinde saklanabileceğini kabul eder.</p>

<p><b>3.12</b> Uygulama’ya ilişkin teknik sorunlar çıkması halinde Kullanıcı, Bookmeal ile iletişime geçmeden önce sorunu tespit ve teşhis etmek için makul çabayı sarf edecektir. Kullanıcı’nın teknik destek ihtiyacının devam etmesi halinde gerekli destek, Site, Uygulama veya diğer uygun kanallardan sağlanacaktır.</p>

<p><b>3.13</b> Kullanıcı’ya Site üzerinden iletişim araçları (forum, sohbet araçları veya mesaj merkezi gibi) sağlanması durumunda Kullanıcı bu iletişim araçlarını yalnızca hukuka uygun amaçlar çerçevesinde kullanacağını beyan ve taahhüt eder. Kullanıcı, söz konusu iletişim araçlarını ürün ve hizmet satışı, karşı tarafın rızası olmadan gönderilen e-postalar, üçüncü kişilerin yazılım ve bilgisayar sistemlerine zarar verebilecek dosyalar, diğer kullanıcılar bakımından hakaret içeren içerikler veya hukuka aykırı her türlü içerik de dahil olmak üzere Uygulama amacı dışında materyaller paylaşmak için kullanmayacaktır. Kullanıcı, Site üzerinden gerçekleştirdiği her türlü iletişim bakımından bunu yapma yetkisini sahip olduğunu taahhüt eder. Bookmeal'ın Site üzerinden gerçekleştirilen iletişimlerin uygunluğunu veya bunların Uygulama’nın kullanım amaçlarına yönelik olduğunu kontrol etme yükümlülüğü bulunmamaktadır. Uygulama üzerinden erişilen veya Uygulama’ya ilişkin olarak kullanılan diğer web tabanlı iletişim araçları bakımından da Kullanıcı, Site üzerinden sağlanan iletişim araçlarını kullanırken göstermekle yükümlü olduğu özeni gösterecektir. Bookmeal, Site üzerinden sağladığı iletişim araçlarını kendi takdirine bağlı olarak dilediği zaman kaldırma hakkına sahiptir.</p>

<p><b>3.14</b> Bookmeal, herhangi bir ön bildirimde bulunmaksızın işbu Sözleşme ve eklerini revize etme hakkına sahip olup bu hakkın kullanılması halinde ilgili değişiklik Kullanıcı tarafından Site’nin bir sonraki kullanımı ile birlikte yürürlüğe girecektir. Kullanıcı’nın söz konusu değişiklikleri kabul etmemesi halinde işbu Sözleşme’yi aşağıda belirtilen şekilde feshetme hakkı saklıdır.</p>

<p><b>3.15</b> Kullanıcı, Kullanıcı hesabını ve işbu Sözleşme ile Site kullanımından doğan hak ve yükümlülüklerini herhangi bir şekilde üçüncü bir kişiye devir veya temlik edemez.</p>

<p><b>3.16</b> Kullanıcı’nın işbu Sözleşme ve Site kapsamında yer alan diğer koşul ve şartlar ile bu kapsamdaki beyan ve taahhütlerine aykırı davranması halinde Bookmeal Kullanıcı’nın üyeliğini askıya alma veya Sözleşme’yi aşağıda belirtilen şekilde feshederek kullanıcı statüsünü bu şekilde sona erdirme hakkına sahip olacaktır. Böyle bir durumda Bookmeal'ın söz konusu aykırılıktan doğan zararlarının Kullanıcı’dan talep hakkı saklıdır.</p>

<p><b>3.17</b> Bookmeal, ürün özelliklerinde değişiklik yapma hakkını saklı tutar.</p>

<h3>Madde 4. Ödeme Koşulları</h3>

<p><b>4.1</b> Kullanıcı Uygulama’dan ancak Site’de beyan edilen ücretleri yine Site’de beyan edilen ödeme koşulları ve araçları ile tam ve eksiksiz olarak ödemesi karşılığında faydalanabilecektir.</p>

<p><b>4.2</b> Kullanıcı, Uygulama’yı Site’de belirtilecek süre boyunca ücret ödemeden kullanabilecektir. Söz konusu ücretsiz deneme periyodunun bitimiyle ve ödeme yöntemi girildikten sonra Kullanıcı’nın üyeliği, hizmet seviyesi, işlevsellik ve kampanyalar sözleşme süresine göre belirlenecek ücretli üyelik haline gelecektir. Uygulama’ya ilişkin ücretler, ödeme koşulları, ücretlerin yürürlük tarihleri Site’nin ilgili bölümlerinde ilan edilecektir. Kullanıcı, kendi isteğine bağlı olarak üyelik paketini yükseltebilecek veya düşürebilecektir. Buna ilişkin talepler, Bookmeal tarafından aksi öngörülmedikçe ilgili sözleşmeli üyelik döneminin sonunda gerçekleştirilecektir. Kullanıcı’nın üyelik süresi boyunca üyelik paketine ilişkin ücret ve ödeme koşullarında yapılacak değişiklikler, Kullanıcı’nın üyelik döneminin sona ermesine dek uygulanmayacak, yeni ücretler ve ödeme koşulları yeni üyelik döneminin başlamasıyla geçerli olacaktır. Üyelik dönemi boyunca Sözleşme’nin feshi de dahil olmak üzere üyeliğin herhangi bir nedenle sona ermesi halinde geri ödeme yapılmayacaktır.</p>

<p><b>4.3</b> Kullanıcı tarafından periyot bitiminden 14 (on dört) gün öncesine kadar aksi talep edilmediği sürece her periyodun bitiminde Kullanıcı’nın üyeliği otomatik olarak yenilenecektir.</p>

<p><b>4.4</b> Bookmeal, Kullanıcı tarafından iletilen iletişim adresine üyelik döneminin başlangıcında kullanım ücretlerine ilişkin faturayı elektronik ortamdan e-fatura veya e-arşiv fatura olarak iletecektir. Ön ödemeli üyeliklerde tüm faturalar o dönemki üyelik dönemine ilişkin ücretleri içerecektir. Kullanıcı, faturadaki ilgili tutarı fatura kesildiği an ödemek durumundalardır. Yıllık ve aylık aboneliklerde Bookmeal yeni dönem aboneliğinin ücretini yeni dönem başlangıcını takip eden 1 (bir) iş günü içerisinde alamadığı durumlarda, Kullanıcı'nın aldığı uygulama hizmetini durdurabilir. İlgili ücretlere ilişkin vergi ve harçların ödenmesinden Kullanıcı sorumludur.</p>

<p><b>4.5</b> Kullanıcı, Bookmeal veya Bookmeal tarafından onaylanmış üçüncü kişiler üyeliğe ve ödemeye ilişkin işlemler veya banka entegrasyonunu ve ilgili güncellemeleri gerçekleştirmek için Kullanıcı’nın kredi kartı ve ödeme bilgilerini saklayabilecektir.</p>

<p><b>4.6</b> Kullanıcı, ücretsiz deneme periyodu ve ücretli kullanım süresinin toplamı 14 günü geçtiyse eğer ödediği ücretin iade hakkının olmadığını bilir ve kabul eder.</p>

<h3>Madde 5. Fikri Mülkiyet Hakları</h3>

<p><b>5.1</b> Site ve Uygulama üzerindeki her türlü hak, mülkiyet ve menfaat Bookmeal'a aittir. İşbu Sözleşme kapsamında Kullanıcı’ya Site ve Uygulama’yı kullanmak üzere kişiye özel, dünya çapında, telifsiz, devredilemez ve münhasır olmayan lisans verilmektedir. Sözleşme ve Site’ye ilişkin diğer koşullardaki hiçbir hüküm Site ve Uygulama’ya ilişkin hakların ve menfaatlerin Kullanıcı’ya devredildiği şeklinde yorumlanamaz. Kullanıcı, işbu Sözleşme kapsamında Bookmeal’a Kullanıcı’nın Uygulama’ya erişimi, Uygulama’yı kullanması ve hizmetlerin sağlanmasına yönelik diğer amaçlarla, bilgilerinin ve İçerik’in kullanılması, kopyalanması, iletilmesi, saklanması ve yedeğinin alınması için kullanım hakkı tanımaktadır. Bookmeal, hizmetlerin sağlanması amacıyla İçerik’e ilişkin olarak üçüncü kişi geliştiricilere alt lisans verme hakkını sahiptir.</p>

<p><b>5.2</b> Kullanıcı, hiçbir şekilde ve nedenle Site’yi veya Uygulama’yı kopyalama, değiştirme, çoğaltma, ters mühendisliğe tabi tutma, geri derleme ve sair şekillerde Site üzerindeki yazılımın kaynak koduna ulaşma, Site’den işleme eser oluşturma hakkına sahip değildir. Site’ye ilişkin tarayıcı ve içeriklerin herhangi bir şekilde değiştirilmesi, Bookmeal'ın açık izni olmaksızın Site’ye veya Site’den link verilmesi kesinlikle yasaktır.</p>

<h3>Madde 6. Sorumluluğun Kısıtlanması</h3>

<p><b>6.1</b> Site kapsamındaki Uygulama, yazılım ve sair içerikler “OLDUĞU GİBİ” sunulmakta olup, bu kapsamda Bookmeak’ın Uygulama, yazılım ve içeriğin doğruluğu, tamlığı ve güvenilirliği ile ilgili herhangi bir sorumluluk ya da taahhüdü bulunmamaktadır. Kullanıcı, Bookmeal’ın ayrıca İçerik ve diğer Kullanıcı verilerinin birbiriyle ilişkisine dair taahhütte bulunmadığını anlar ve kabul eder. Bookmeal, Uygulama’nın kullanımının kesintisiz ve hatasız olduğunu taahhüt etmemektedir. Bookmeal, Uygulama’nın 7/24 erişilebilir ve kullanılabilir olmasını hedeflemekle birlikte Uygulama’ya erişimi sağlayan sistemlerin işlerliği ve erişilebilirliğine ilişkin bir garanti vermemektedir. Kullanıcı, Uygulama’ya erişimin muhtelif zamanlarda engellenebileceğini ya da erişimin kesilebileceği kabul eder. Bookmeal, söz konusu engelleme veya kesintilerden hiçbir şekilde sorumlu değildir.</p>


<p><b>6.2</b> Kullanıcı, Site üzerinden Bookmeal'ın kontrolünde olmayan başka internet sitelerine ve/veya portallara, dosyalara veya içeriklere link verilebileceğini ve bu tür linklerin yöneldiği internet sitesini veya işleten kişisini desteklemek amacıyla veya internet sitesi veya içerdiği bilgilere yönelik herhangi bir türde bir beyan veya garanti niteliği taşımadığını, söz konusu linkler vasıtasıyla erişilen portallar, internet siteleri, dosyalar ve içerikler, hizmetler veya ürünler veya bunların içeriği hakkında Bookmeal’ın herhangi bir sorumluluğu olmadığını kabul ve beyan eder.</p>

<p><b>6.3</b> Kullanıcı, Site üzerinden sunulan Uygulama ve Uygulama’lara erişim ve bunların kalitesinin büyük ölçüde ilgili İnternet Servis Sağlayıcısı’ndan temin edilen hizmetin kalitesine dayandığını ve söz konusu hizmet kalitesinden kaynaklı sorunlarda Bookmeal’ın herhangi bir sorumluluğunun bulunmadığını kabul eder.</p>

<h3>Madde 7. Sözleşme’nin Yürürlüğü ve Feshi</h3>

<p><b>7.1</b> İşbu Sözleşme Kullanıcı tarafından Uygulama’ya kayıt esnasında elektronik ortamda kabulü ile birlikte yürürlüğe girecek ve taraflardan herhangi biri tarafından aşağıda belirtilen şekilde feshedilmediği sürece yürürlükte kalacaktır.</p>

<p><b>7.2</b> Taraflardan herhangi biri, diğer tarafça bildirilen elektronik posta adresine 1 (bir) hafta önceden yapacağı yazılı bir bildirimle işbu Sözleşme’yi dilediği zaman herhangi bir gerekçe göstermeksizin ve tazminat ödemeksizin feshedebilecektir.</p>

<p><b>7.3</b> Taraflar’dan birinin işbu Sözleşme’den kaynaklanan yükümlülüklerini tam ve gereği gibi yerine getirmemesi ve diğer tarafça yapılacak yazılı bildirime karşın söz konusu aykırılığın verilen süre içerisinde giderilmemesi halinde bu Sözleşme bildirimi yapan tarafça feshedilebilecektir. Bahsi geçen aykırılığın Kullanıcı tarafından gerçekleştirilmesi halinde Bookmeal aykırılık giderilene kadar Kullanıcı statüsünü askıya alma hakkına sahip olacaktır. Kullanıcı’nın yürürlükteki mevzuatı ihlal etmesi halinde Bookmeal Sözleşme’yi derhal geçerli olacak şekilde haklı nedenle feshedebilecektir.</p>

<p><b>7.4</b> Sözleşme’nin feshi Taraflar’ın fesih tarihine kadar doğmuş olan hak ve yükümlülüklerini ortadan kaldırmayacaktır. Sözleşme’nin feshi ile birlikte Kullanıcı, o güne kadar doğmuş olan tüm ücret ve masraflardan sorumlu olup fesih tarihi itibariyle Site ve Uygulama’yı kullanamayacaktır. Ön ödemeli üyeliklerin feshi halinde Kullanıcı’ya para iadesi yapılmaz.</p>

<p><b>7.5</b> Kullanıcı’nın hesabının 3 (üç) ay boyunca pasif olması halinde Bookmeal işbu Sözleşme’yi feshedebilecektir.</p>

<p><b>7.6</b> Bookmeal, işbu Sözleşme yürürlükte olduğu müddetçe İçerik’i veritabanlarında saklama hakkına sahiptir. Kullanıcı’nın üyelik döneminin veya işbu Sözleşme’nin sona ermesini takip eden 1 (bir) ay içinde Kullanıcı İçerik’i ücret ödemeksizin alabilecektir. Bookmeal, bu sürenin sona ermesinden sonra iletilen söz konusu talepler için ücret talep edebilecektir.</p>

<h3>Madde 8. Muhtelif Hükümler</h3>

<p><b>8.1</b> İşbu Sözleşme’nin herhangi bir hükmünün veya sözleşmede yer alan herhangi bir ifadenin geçersizliği, yasaya aykırılığı ve uygulanamazlığı, Sözleşme’nin geri kalan hükümlerinin yürürlüğünü ve geçerliliğini etkilemeyecektir.</p>

<p><b>8.2</b> İşbu Sözleşme ekleri ile bir bütündür. Sözleşme ile ekleri arasında herhangi bir çelişki olması halinde, ilgili eklerde yer alan hükümler geçerli olacaktır.</p>

<p><b>8.3</b> Kullanıcı ile kayıt olurken bildirdikleri e-mail vasıtasıyla veya Site’de yer alan genel bilgilendirme aracılığıyla iletişim kurulacaktır. E-mail ile yapılan iletişim yazılı iletişimin yerini tutar. E-mail adresini güncel tutmak ve Site’yi bilgilendirmeler için düzenli kontrol etmek Kullanıcı’nın sorumluluğundadır.</p>

<p><b>8.4</b> İşbu Sözleşme ve eklerinden kaynaklı uyuşmazlıklarda İstanbul Mahkemeleri ve İcra Daireleri geçerli olacaktır.</p>







					</p>
					
				</div>
						
					</div>

				</div>

<?php require_once 'footer.php'; ?>

<script type="text/javascript">
	

	

</script>