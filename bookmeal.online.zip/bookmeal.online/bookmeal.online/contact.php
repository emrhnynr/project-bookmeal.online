<?php require_once 'header.php'; ?>
<title>İletişim</title>
		
		<!-- start Main Wrapper -->
		<div class="main-wrapper scrollspy-container">

			<div class="container pt-10 pb-50">
			
						
				<div class="mt-40">
				
					<div class="section-title-02">

						<h3><span>İletişim</span></h3>
						<p>Herhangi bir sorunuz veya öneriniz varsa bizimle iletişime geçin. Size yardımcı olmaktan memnuniyet duyacağız.</p>
						
					</div>

					<div class="contact-wrapper GridLex-gap-30">

						<div class="GridLex-grid-noGutter-equalHeight">
								
							<div class="GridLex-col-3_sm-12_xs-12">

								<div class="contact-item-wrapper">
									
									<div class="row">
										
										<div class="col-xss-12 col-xs-6 col-sm-4 col-md-12">
										
											<div class="contact-item mb-25">
												<h6 class="heading">Adres</h6>
												<p><i class="fas fa-map-marker-alt" style="color: #043D75;"></i> Kolektif House - Levent/İstanbul<br></p>
											</div>
										
										</div>
										
										
										<div class="col-xss-12 col-xs-6 col-sm-4 col-md-12">
										
											<div class="contact-item mb-25">
												<h6 class="heading">İletişim</h6>
												<p><b>help@bookmeal.online</b></p>
											</div>
										
										</div>
										
										
										
									</div>

								</div>

							</div>


							
							
							
							<div class="GridLex-col-6_sm-12_xs-12">


							
								<div class="contact-form-wrapper">

									<?php if ($_GET['mail']=="success") { ?>
										<div class="alert alert-success alert-icon">
						
							<i class="fa fa-check-circle"></i>
							
							<h4>Mailinizi aldık. Teşekkür ederiz!</h4>
						
						</div>
								<?php	} ?>
								
									<h6>Bize Mesaj Yazın</h6>
									
									<form class="form-absolute-label" id="mailgonderform" action="musteriislem" method="POST">
									
										<div class="row">
										
											<div class="col-xss-12 col-xs-6 col-sm-4 col-md-12">
										
												<div class="form-group">
													<input id="inputName" name="mail_ad" type="text" class="form-control mail_ad" placeholder="Adınız (Zorunlu)">
													<div class="help-block with-errors"></div>
												</div>
												
											</div>
											
											<div class="col-xss-12 col-xs-6 col-sm-4 col-md-12">
										
												<div class="form-group">
													<input id="inputEmail" name="mail_adres" type="email" class="form-control mail_adres" placeholder="E-Posta Adresiniz (Zorunlu)" maxlength="100" >
													<div class="help-block with-errors"></div>
												</div>
										
											</div>
											
											<div class="col-xss-12 col-xs-12 col-sm-4 col-md-12">
										
												<div class="form-group">
													<input type="text" name="mail_konu" maxlength="100" class="form-control mail_konu" placeholder="Konu (Zorunlu)" />
												</div>
										
											</div>
											
											<div class="col-xss-12 col-xs-12 col-sm-12 col-md-12">
												
												<div class="form-group">
													<textarea id="inputMessage" class="form-control mail_text" placeholder="Mesajınız (Zorunlu)" name="mail_text" rows="5"></textarea>
													<div class="help-block with-errors"></div>
												</div>

												<div style="display: none;" class="alert alert-danger uyarikutu"></div>
												
											</div>


											
											<div class="col-xss-12 col-xs-12 col-sm-12 col-md-12">
												<div class="mt-10 mt-5-sm">
													<button type="submit" id="mailgonderbuton" name="mailgonder" class="btn btn-primary mt-5">Gönder</button>
												</div>


											</div>

											
											
										</div>



									</form>

								</div>
							
							</div>
							
						</div>

					</div>
				
				</div>
				
			</div>
	
		</div>
		<!-- end Main Wrapper -->
		
		<?php require_once 'footer.php'; ?>
		<script type="text/javascript">

			$('#mailgonderform').submit(function(){
                
                
				var mail_ad=$.trim($('.mail_ad').val());
				var mail_adres=$.trim($('.mail_adres').val());
				var mail_konu=$.trim($('.mail_konu').val());
				var mail_text=$.trim($('.mail_text').val());

				if (mail_ad=="") {

					event.preventDefault();
					$('.uyarikutu').show();
					$('.uyarikutu').html("<i class='fas fa-exclamation-circle'></i> Lütfen isminizi yazın.");

				} else if(mail_adres==""){


                  event.preventDefault();
                  $('.uyarikutu').show();
					$('.uyarikutu').html("<i class='fas fa-exclamation-circle'></i> Lütfen e-posta adresinizi yazın.");

				} else if(mail_konu==""){


                  event.preventDefault();
                  $('.uyarikutu').show();
					$('.uyarikutu').html("<i class='fas fa-exclamation-circle'></i> Lütfen mail konunuzu yazın.");


				} else if(mail_text==""){

              event.preventDefault();
              $('.uyarikutu').show();
					$('.uyarikutu').html("<i class='fas fa-exclamation-circle'></i> Lütfen mesajınızı yazın.");

				} else {
$('.uyarikutu').hide();
$('#mailgonderbuton').prop('disabled',true);
$('#mailgonderbuton').html("<img style='width:18px;height:18px;' src='css/images/flex-loader.gif'>");

				}
		     

				
			})
		     
		</script>
		
        