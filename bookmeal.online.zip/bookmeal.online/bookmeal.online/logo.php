<?php require_once 'header.php';

if (empty($_COOKIE['kullanicioturum'])) {
	
	header("Location:/");
	exit;
};

$restoransec=$db->prepare("SELECT * from restoranlar where restoran_id=:id");
$restoransec->execute(array(
"id" => $kullanicioturumcek['restoran_id']
));

$restorancek=$restoransec->fetch(PDO::FETCH_ASSOC);

$restoran_logo=$restorancek['restoran_logo'];

 ?>
<title>Restoran Logo</title>
		
		<!-- start Main Wrapper -->
		<div class="main-wrapper scrollspy-container">
		
		
			

			<div class="container pt-10 pb-60">
			
				
						
				<div class="mt-40">
				
					<div class="row">

						<div class="col-sm-12 col-md-12 col-xs-12 mb-50-xs">
				
							<div class="blog-single-wrapper">
							
								
								
							
								
								<h4>Mevcut Logo</h4>
								<form onsubmit="return false;" id="logoupdateform" >
								<div align="center" class="blog-author clearfix">
									<div class="author-label img-cerceve">
										<img  src="<?php if(empty($restoran_logo)){

                                        echo 'dimg/nophoto.png';

										} else {

                                        echo $restoran_logo;

										} ?>" alt="author image" />
										
										<?php if (!empty($restorancek['restoran_logo'])) { ?>
											<br>
										<a id="logosil" href='javascript:void(0);'><i style="color: #DB3944;" class="far fa-trash-alt"></i></a>
										<?php } ?>
									</div>

									<div  class="author-details">

										<input type="hidden"  name="logoupdate">
										<input type="hidden" id="restoran_id" value="<?php echo $restorancek['restoran_id']; ?>" name="restoran_id">
										
										
										<input type="file" id="restoran_logo" class="form-control" name="restoran_logo">
										<br>
										<div style="display: none;" class="alert alert-danger"></div>
										<button type="submit" class="btn btn-primary mt-40 updatebuton">Güncelle</button>



									</form>
										
										</div>
										

									
									
								</div>


								
							</div>
							
							
							
							
							

							
							

						</div>
						
						
						
					</div>

				</div>
				
			</div>
			
		</div>
		<!-- end Main Wrapper -->
		
	<?php require_once 'footer.php'; ?>
	<script type="text/javascript">
		$('#logoupdateform').submit(function(){

			var logo=$('#restoran_logo').val();
			var logouzanti=logo.split('.').pop();
			var form = $('#logoupdateform')[0];
             var data = new FormData(form);



			if (logo=="") {

   
event.preventDefault();
$('.alert-danger').show();
$('.alert-danger').html('<i class="fas fa-info-circle"></i> Lütfen bir logo yükleyin.');


			} else if (logouzanti!='jpg' && logouzanti!='jpeg' && logouzanti!='png'){


event.preventDefault();
$('.alert-danger').show();
$('.alert-danger').html('<i class="fas fa-info-circle"></i> Dosyanızın uzantısı sadece <b>.jpg, .jpeg, .png</b> olabilir.');

			} else {


$('.alert-danger').hide();
$('.updatebuton').prop('disabled',true);
$('.updatebuton').html('Güncelleniyor...');

$.ajax({
            type : 'POST',
            url : 'ajax.php',
            enctype : 'multipart/form-data',
            data : data,
            processData: false,
            contentType: false,
            cache: false,
            success : function(sonuc){

            	  sonuc=$.trim(sonuc);

            	  if (sonuc=='hata') {

$('.updatebuton').prop('disabled',false);
$('.updatebuton').html('GÜNCELLE');

            	  	swal({

  title: "Bir şeyler ters gitti.",
  icon: "error",
  button: "OK",
});




            	  } else {

$('.updatebuton').prop('disabled',false);
$('.updatebuton').html('GÜNCELLE');

            	  	swal({

  title: "Başarılı",
  text: "Logo Değiştirildi.",
  icon: "success",
  button: "OK",
});

$('.img-cerceve').html(sonuc);
$('#logosil').click(function(){

			var restoran_id=$('#restoran_id').val();

			

			swal({
  title: "Logoyu kaldırmak istediğinize emin misiniz?",
  icon: "warning",
  buttons: ["Cancel", "Remove"],
  dangerMode: true,
})
.then((willDelete) => {
  if (willDelete) {
    
$.ajax({

	 type : 'POST',
            url : 'ajax.php',
            data : {'logosil':'ok','restoran_id':restoran_id},
            success : function(sonuc){

            	sonuc=$.trim(sonuc);

            	if (sonuc=='islemtamam') {

           

            	  	swal({

  title: "Başarılı",
  text: "Logo başarıyla kaldırıldı!",
  icon: "success",
  button: "OK",
});


            	  	$('.img-cerceve').html('<img  src="dimg/nophoto.png" alt="author image" />');


            	}

           
            	
            	
               
            }
})

  } 
});

   
		})


            	  }

            	
               
            }
        })

			}






		});


		$('#logosil').click(function(){

			var restoran_id=$('#restoran_id').val();

			

			swal({
  title: "Logoyu kaldırmak istediğinize emin misiniz?",
  icon: "warning",
  buttons: ["Cancel", "Remove"],
  dangerMode: true,
})
.then((willDelete) => {
  if (willDelete) {
    
$.ajax({

	 type : 'POST',
            url : 'ajax.php',
            data : {'logosil':'ok','restoran_id':restoran_id},
            success : function(sonuc){

            	sonuc=$.trim(sonuc);

            	if (sonuc=='islemtamam') {

           

            	  	swal({

  title: "Başarılı",
  text: "Logo başarıyla kaldırıldı!",
  icon: "success",
  button: "OK",
});


            	  	$('.img-cerceve').html('<img  src="dimg/nophoto.png" alt="author image" />');


            	}

           
            	
            	
               
            }
})

  } 
});

   
		})
	</script>