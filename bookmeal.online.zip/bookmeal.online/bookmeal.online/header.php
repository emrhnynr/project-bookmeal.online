
<?php require_once 'baglann.php'; 
include 'fonksiyon.php';


$ip_adresi=$_SERVER['REMOTE_ADDR'];
date_default_timezone_set('Europe/Istanbul');
/*$query=@unserialize(file_get_contents('http://ip-api.com/php/'.$ip_adresi));

 if ($query && $query['status']=='success'){
    
     $timezone=$query['timezone'];
      date_default_timezone_set($timezone);
      
      
} else {
    
    date_default_timezone_set('America/Los_Angeles');
} */


 $urlpage=pathinfo($_SERVER['PHP_SELF'], PATHINFO_FILENAME);
 
 
 





if (isset($_COOKIE['kullanicioturum'])) {
	
	$kullanicioturumsec=$db->prepare("SELECT * from kullanici where kullanici_mail=:mail");
	$kullanicioturumsec->execute(array(
"mail" => $_COOKIE['kullanicioturum']
	));

	$kullanicioturumcek=$kullanicioturumsec->fetch(PDO::FETCH_ASSOC);


	setcookie('kullanici_id',$kullanicioturumcek['kullanici_id'],time()+31556926);
	$kullanicioturum=$_COOKIE['kullanicioturum'];
};



if ($kullanicioturumcek['kullanici_asama']==1 and $urlpage!='restaurant-submit') {
	
	header("Location:restaurant-submit");
	exit;
}

if ($kullanicioturumcek['kullanici_asama']==2 and $kullanicioturumcek['kullanici_mailonay']=="no" and $urlpage!='email-activation') {
	
	header("Location:email-activation");
	exit;
}


 

$uyelik_turu=$kullanicioturumcek['uyelik_turu'];

if ($uyelik_turu=='expired' and $urlpage!='pricing' and $urlpage!='checkout' and $urlpage!='contact') {
	
	header("Location:pricing");exit;
}

?>

<!doctype html>
<html class="hide-scrollbar" lang="tr">

<head>

	

	<?php if ($ip_adresi!='::1') { ?>
		
	

	<!-- Yandex.Metrika counter -->
<script type="text/javascript" >
   (function(m,e,t,r,i,k,a){m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)};
   m[i].l=1*new Date();k=e.createElement(t),a=e.getElementsByTagName(t)[0],k.async=1,k.src=r,a.parentNode.insertBefore(k,a)})
   (window, document, "script", "https://mc.yandex.ru/metrika/tag.js", "ym");

   ym(68934574, "init", {
        clickmap:true,
        trackLinks:true,
        accurateTrackBounce:true,
        webvisor:true
   });
</script>
<noscript><div><img src="https://mc.yandex.ru/watch/68934574" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter -->
<?php } ?>

	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<!-- Title Of Site -->


	
	<meta name="description" content="Restoran ve cafeler için sipariş yazılımı. QR Menü üzerinden sipariş alın ve maliyetlerinizi düşürün. Ayrıca müşterilerinizin basitçe ön sipariş vermesini sağlayın, geldiklerinde yemekleri hazır olsun. Müşteri memnuniyetinizi artırın. Zamandan kazanın. Restoranınızı veya cafenizi dijitalleştirin." />
	<meta name="keywords" content="restaurant, QR, pre-order, eat, yemek, karekod, öğün, menu, dining, meal, cafe, breakfast, reservation," />
	<meta name="author" content="crenoveative">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	
	<!-- Fav and Touch Icons -->
	<link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/ico/apple-touch-icon-144-precomposed.png">
	<link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/ico/apple-touch-icon-114-precomposed.png">
	<link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/ico/apple-touch-icon-72-precomposed.png">
	<link rel="apple-touch-icon-precomposed" href="images/ico/apple-touch-icon-57-precomposed.png">
	<link rel="shortcut icon" href="images/logo-xs.png">

	



    <!-- Font Awesome -->

	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">

	<!-- CSS Plugins -->
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css" media="screen">	
	<link href="css/animate.css" rel="stylesheet">
	<link href="css/main.css" rel="stylesheet">
	<link href="css/component.css" rel="stylesheet">

	<!-- CSS Custom -->
	<link href="css/style.css" rel="stylesheet">
	
	<!-- For your own style -->
	<link href="css/your-style.css" rel="stylesheet">

	<!-- Magnific Popup core CSS file -->
<link rel="stylesheet" href="css/magnific-popup.css">

	

	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
	<!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
		<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->

	
</head>


	


<body class="full-width-container <?php if ($urlpage=='index' or $urlpage=='orders' or $urlpage=='pricing'){
	echo 'transparent-header';
}; ?> ">


<?php if ($urlpage!='preorder' and $urlpage!='reservation') { ?>
	
	<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5fee366edf060f156a92dcf9/1eqt898l9';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->

<?php } ?>



	<div id="introLoader" class="introLoading"></div>

	<?php if ($urlpage!='reservation' or isset($_COOKIE['kullanicioturum'])) { ?>
		
	
	
	<!-- start Container Wrapper -->
	<div class="container-wrapper">

		<!-- start Header -->
		<header id="header">
	  
			<!-- start Navbar -->
			<nav class="navbar navbar-default navbar-fixed-top">
				
				<div class="header-inner">

					
						

<div class="navbar-header">
						<?php if ($urlpage=='index' or $urlpage=='orders' or $urlpage=='pricing') { ?>

							
							

<a class="navbar-brand hidden-xs off-sticky" href="/"><img src="images/logo-white.png" alt="Image" /></a>
						<a class="navbar-brand hidden-xs on-sticky" href="/"><img src="images/logo.png" alt="Image" /></a>
						<a class="navbar-brand visible-xs" href="/"><img src="images/logo-white-xs.png" alt="Image" /></a>

						

						<?php } else { ?>

							<?php if ($urlpage!='reservation' and $urlpage!='preorder') { ?>

							

								<a class="navbar-brand hidden-xs" href="/"><img src="images/logo.png" alt="Image" /></a>
						<a class="navbar-brand visible-xs" href="/"><img src="images/logo-xs.png" alt="Image" /></a>
								
							
                            
                            


					<?php }	} ?>
					</div>

					
						
					
						
					<div id="navbar" class="collapse navbar-collapse navbar-arrow pull-left">
						
						<?php if ($kullanicioturumcek['kullanici_yetki']==5) {

							$headerrestoransec=$db->prepare("SELECT * from restoranlar where restoran_id=:id");
									$headerrestoransec->execute(array(

										"id" => $kullanicioturumcek['restoran_id']));

									$headerrestorancek=$headerrestoransec->fetch(PDO::FETCH_ASSOC);

										 ?>

										 <ul class="nav navbar-nav" id="responsive-menu">
							
							
							
							<?php if ($uyelik_turu==3 or $uyelik_turu==4) { ?>

                            
 
                      <li><a href="r-<?php echo $headerrestorancek['restoran_seo']; ?>-1">QR Sipariş Sayfam</a></li>

                          

								
							<?php } else if($uyelik_turu==1){ ?>
              
              <li><a href="r-<?php echo $headerrestorancek['restoran_seo']; ?>-1">QR Menü Sayfam</a></li>

							<?php } ?>
							

							<?php if ($uyelik_turu==2 or $uyelik_turu==4) { ?>

                              

                  <li><a href="preorder?sef=<?php echo $headerrestorancek['restoran_seo']; ?>">Ön Sipariş Sayfam</a></li>
                             

								
							<?php } ?>
							<li>
								<a href="javascript:void(0);">Ayarlar</a>
								<ul>
									<li><a href="general-settings">Genel Ayarlar</a></li>
									<li><a href="menu-settings">Menü Ayarları</a></li>

									<?php if ($uyelik_turu==2 or $uyelik_turu==4) { ?>
										<li><a href="opening-hours">Vardiya Saatleri</a></li>
									<?php } ?>
							<li><a href="change-password"> Şifre Değiştir</a></li>
							<li><a href="color-settings">Renk Ayarları</a></li>
							<li><a href="logo">Restoran Logo</a></li>
							<?php if ($uyelik_turu!='expired') { ?>
								<li><a href="membership">Üyelik</a></li>
						<?php } ?>
							
							
							
								</ul>
							</li>



							
							
							<?php if ($uyelik_turu==1 or $uyelik_turu==3 or $uyelik_turu==4) { ?>
                         	<li><a href="qr-codes">QR KODLAR</a></li>
                        <?php } ?>
                        
                        <li><a href="guide">Rehber</a></li>
							<li><a href="contact">İletişim</a></li>



							
						</ul>
							
					<?php	} else if ($kullanicioturumcek['kullanici_yetki']==1){ ?>

						<ul class="nav navbar-nav" id="responsive-menu">

                        						<li><a href="contact">İletişim</a></li>

					</ul>


					<?php }  else { ?>

<?php if ($urlpage!='reservation') { ?>
	<ul class="nav navbar-nav" id="responsive-menu">
							
		
		
		
			<li><a href="restaurant-submit">Kullanmaya Başla</a></li>
			<li><a href="contact">İletişim</a></li>
			<li><a href="pricing">FİYATLAR</a></li>
			

	
							
						</ul>
<?php } ?>

 

					<?php } ?>
					
						
					

					</div><!--/.nav-collapse -->
				
					<div class="pull-right">
						<div class="navbar-mini">
							<ul class="clearfix">
								


							
								<?php if ($kullanicioturumcek['kullanici_yetki']==5) {

									
										
								

									$headerrestoransec=$db->prepare("SELECT * from restoranlar where restoran_id=:id");
									$headerrestoransec->execute(array(

										"id" => $kullanicioturumcek['restoran_id']));

									$headerrestorancek=$headerrestoransec->fetch(PDO::FETCH_ASSOC); ?>

									

										 

										

									<?php if ($uyelik_turu==3 or $uyelik_turu==4) { ?>
										<li class="user-action">
									<a href="mypanel" class="btn btn-primary btn-sm btn-inverse"> Siparişler</a>

								</li>
									<?php } ?>

								<?php if ($uyelik_turu==2 or $uyelik_turu==4) { ?>
									<li class="user-action">
									<a href="preorders" class="btn btn-primary btn-sm btn-inverse"> Ön Siparişler</a>
								</li>
							<?php } ?>

								



								

									
									
									<li class="user-action">
									<a href="logout?url=<?php echo 'http://'.$_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI']; ?>" class="btn btn-primary btn-inverse btn-sm"><i class="fas fa-sign-in-alt"></i> Çıkış Yap</a>
								</li>
								<?php } else if ($kullanicioturumcek['kullanici_yetki']==1){ ?>

									

								<li class="user-action">
									<a href="orders" class="btn btn-primary btn-sm btn-inverse"> Siparişler</a>
								</li>

								<li class="user-action">
									<a href="order-past" class="btn btn-primary btn-sm btn-inverse"> Geçmiş Siparişler</a>
								</li>

		
									
									
									<li class="user-action">
									<a href="logout?url=<?php echo 'http://'.$_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI']; ?>" class="btn btn-primary btn-inverse btn-sm"><i class="fas fa-sign-in-alt"></i> Çıkış Yap</a>
								</li>


								<?php } else { ?>

									<?php if ($urlpage!='reservation') { ?>

										<li class="user-action">
									<a href="javascript:void(0)" class="btn btn-primary btn-inverse btn-sm btn-ajax-register" data-toggle="modal">KAYIT OL</a>
								</li>

										<li class="user-action">
									<a href="javascript:void(0)" class="btn btn-primary btn-inverse btn-sm btn-ajax-login" data-toggle="modal">GİRİŞ YAP</a>
								</li>
										
									<?php } ?>

								

								

								<?php } ?>
									
									
								
							
							</ul>
						</div>
						
					</div>
				
				</div>

				
				<div id="slicknav-mobile"></div>
				
			</nav>
			<!-- end Navbar -->



		</header>
	</div>

	<?php } ?>



		

		




