<?php
require_once 'baglann.php';
 ?>

<div class="modal-header">
	<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
	<h4 class="modal-title text-center">Hesabınıza Giriş Yapın</h4>
</div>

<div class="modal-body">
	<div class="row gap-20">

		

		
	
		
		
		

		<form onsubmit="return false;" id="loginform">
		
		<div style='margin-top:80px;' class="col-xs-12 col-sm-12 col-md-12">

			<div class="form-group"> 
				<label>E-Posta Adresiniz</label>
				<input class="form-control" maxlength="100" placeholder="E-posta adresinizi girin" name="kullanici_mail" type="email"> 
			</div>
		
		</div>
		
		<div class="col-xs-12 col-sm-12 col-md-12">
		
			<div class="form-group"> 
				<label>Şifre</label>
				<input class="form-control" maxlength="40" placeholder="Şifrenizi girin" name="kullanici_sifre" type="password"> 
			</div>
		
		</div>



		<div class="col-xs-12 col-sm-12 col-md-12">
			<div class="register-box-box-action">
				Hesabınız yok mu? <a data-toggle="modal" href="javascript:void(0)" class="registerModal">Kayıt Ol</a>
			</div>
		</div>

		<div align="right" class="col-xs-12 col-sm-12 col-md-12">
			<div class="login-box-link-action">
				<a data-toggle="modal" href="#forgotPasswordModal">Şifrenizi mi unuttunuz?</a> 
			</div>
		</div>

		<input type="hidden" name="uyelogin">


		
		
		
		
		
		
		


		
	</div>

	<div class="alert alert-danger uyarikutu" style="display: none;"></div>
</div>




<div style="margin-top:80px;" class="modal-footer text-center">
	<button  class="btn btn-primary girisyapbuton">GİRİŞ YAP</button>
	<button type="button" data-dismiss="modal" class=" btn btn-dark">KAPAT</button>
</div>

</form>


<script type="text/javascript">
	


	$('.girisyapbuton').click(function(tikla){


$('.girisyapbuton').prop('disabled',true);
$('.girisyapbuton').html("<img style='width:18px;height:18px;' src='css/images/flex-loader.gif'>");
	

		$.ajax({
            type : 'POST',
            url : 'ajax.php',
            data : $('#loginform').serialize(),
            success : function(sonuc){

            	var back = $.trim(sonuc);

            	if (back=='bilgileryanlis') {
                      
                    $('.girisyapbuton').prop('disabled',false);
                    $('.girisyapbuton').html('GİRİŞ YAP');
                    $('.uyarikutu').show();
            		$('.uyarikutu').html("E-Posta veya şifreniz yanlış.");


            	} else if(back=="kullaniciok"){
                   

                   
                    $('.uyarikutu').hide();
            		window.location.reload();

            	} else if(back=="adminok"){


                 
                 $('.uyarikutu').hide();
            		window.location="mypanel";
            	} 
               
            }
        })

	})
		
	


	
</script>

