
<?php 



if (empty($_COOKIE['kullanicioturum'])) {
	
	Header("Location:index");
	exit;
};



	$url=$_GET['url'];
	setcookie('kullanicioturum',"",time()-31556926);
setcookie('kullanici_id',"",time()-31556926);

Header("Location:$url");






 ?>