
<?php require_once 'header.php'; 



$restoran_seo=$_GET['sef'];
$server="$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";



$restoransec=$db->prepare("SELECT * from restoranlar where restoran_seo=:seo");
$restoransec->execute(array(
"seo" => $restoran_seo
));

$restorancek=$restoransec->fetch(PDO::FETCH_ASSOC);

$gun=date('w');

$restoransay=$restoransec->rowCount();

$restorankullanicisec=$db->prepare("SELECT * from kullanici where restoran_id=:id");
$restorankullanicisec->execute(array(
"id" => $restorancek['restoran_id']
));

$restorankullanicicek=$restorankullanicisec->fetch(PDO::FETCH_ASSOC);

$uyelik_turu=$restorankullanicicek['uyelik_turu'];

$restoran_currency=$restorancek['restoran_currency'];

if ($restoransay==0 or ($uyelik_turu!=2 and $uyelik_turu!=4)) {
	
	header("Location:https://bookmeal.online");exit;

} else if (strpos($server,'preorder?sef=') == false) {

header("Location:https://bookmeal.online/preorder?sef=$restoran_seo");exit;
}

$restoran_id=$restorancek['restoran_id'];

$sipariskontrolsec=$db->prepare("SELECT * from onsiparisler where kullanici_id=:id and siparis_bildirim=:bildirim and siparis_turu=:turu");
$sipariskontrolsec->execute(array(
"bildirim" => 1,
"id" => $_COOKIE['kullanici_id'],
"turu" => 1
));

  $sipariskontrolsay=$sipariskontrolsec->rowCount();

 if ($sipariskontrolsay!=0) {
 	
 	while ($sipariskontrolcek=$sipariskontrolsec->fetch(PDO::FETCH_ASSOC)) {

 		 $sipariskontrol_id=$sipariskontrolcek['siparis_id'];
 		
 		if (date('Y-m-d H:i:s')>$sipariskontrolcek['siparis_kaybolmazaman']) {
 			
 			$hazirlaupdate=$db->prepare("UPDATE onsiparisler set 

siparis_bildirim=:siparis_bildirim,
siparis_variszaman=:siparis_variszaman,
siparis_kaybolmazaman=:siparis_kaybolmazaman

where siparis_id='$sipariskontrol_id'
 				");

 			$derleupdate=$hazirlaupdate->execute(array(

"siparis_bildirim" => 0,
"siparis_variszaman" => NULL,
"siparis_kaybolmazaman" => NULL
 			));

 			//----------------------


$hazirla2update=$db->prepare("UPDATE onsiparisler set 

siparis_bildirim=:siparis_bildirim,
siparis_variszaman=:siparis_variszaman,
siparis_kaybolmazaman=:siparis_kaybolmazaman

where siparis_no='$sipariskontrol_id'
 				");

 			$derle2update=$hazirla2update->execute(array(

"siparis_bildirim" => 0,
"siparis_variszaman" => NULL,
"siparis_kaybolmazaman" => NULL
 			));

 		}
 	}
 } 

 






?>

<style type="text/css">
	.hero::before {
    position: absolute;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    content: "";
    background: rgba(0, 0, 0, 0.0);
}
</style>

<title><?php echo $restorancek['restoran_ad']." Ön Sipariş"; ?></title>




		<div class="main-wrapper scrollspy-container">
		
			<!-- start hero-header -->
			<div  class="hero hero-breadcrumb" style="height: 300px;background-color: white;">
			
				<div align="center" class="container">

					<?php if (strlen($restorancek['restoran_logo'])>0) { ?>
						<img  style="max-width: 200px;max-height: 100px;margin-bottom:10px;" src="<?php echo $restorancek['restoran_logo']; ?>">
					<?php } ?>

					
					<h1 style="color:#484848;"><?php echo $restorancek['restoran_ad']."<br>Ön Sipariş"; ?></h1>
					
					

					


				</div>
				
			</div>

			

			

			<div style="background-color: #F3F2F1;" class="container pt-10 pb-30">

				<?php if (!empty($restorancek['restoran_menuaciklama'])) { ?>
						<div class="alert alert-info"><i class="fas fa-quote-right"></i> <?php echo $restorancek['restoran_menuaciklama']; ?></div>
					<?php } ?>

				<?php if ($_GET['order']=='success') { ?>
					<div class="alert alert-success alert-icon">
						
							<i class="fa fa-check-circle"></i>
							
							<h4>Siparişinizi aldık. Teşekkür ederiz!</h4>
						
						</div>
				<?php } ?>

				<div class="row">
					
								
									
									
									<div class="col-xs-12 col-sm-12 col-md-12">
									
										<div class="open-time-box">
										
											<h5 style="color:<?php echo $restorancek['restoran_renk']; ?>">Vardiya Saatleri</h5>

											<hr>





											<?php   switch ($gun) {

													case '0': ?>

													<ul class="open-time-list">

												
											
												<li>
												
													<div class="row">
													
														<div class="col-xs-6 col-sm-6">
															<span class="day">
																PAZARTESİ
															</span>
														</div>
														
														<div class="col-xs-6 col-sm-6">
															<span class="time">


																<?php
                                                                
                                                                if ($restorancek['restoran_pazartesiacilis']=="" or $restorancek['restoran_pazartesikapanis']==""){

                                                                	echo "KAPALI";

                                                                } else {

                                                                	echo $restorancek['restoran_pazartesiacilis']." - ".$restorancek['restoran_pazartesikapanis'];


                                                                }

																  ?>
															</span>
														</div>
														
													</div>
												
												</li>
												
												<li>
												
													<div class="row">
													
														<div class="col-xs-6 col-sm-6">
															<span class="day">
																SALI
															</span>
														</div>
														
														<div class="col-xs-6 col-sm-6">
															<span class="time">


																<?php
                                                                
                                                                if ($restorancek['restoran_saliacilis']=="" or $restorancek['restoran_salikapanis']==""){

                                                                	echo "KAPALI";

                                                                } else {

                                                                	echo $restorancek['restoran_saliacilis']." - ".$restorancek['restoran_salikapanis'];

                                                                }

																  ?>
																
															</span>
														</div>
														
													</div>
												
												</li>
												
												<li>
												
													<div class="row">
													
														<div class="col-xs-6 col-sm-6">
															<span class="day">
																ÇARŞAMBA
															</span>
														</div>
														
														<div class="col-xs-6 col-sm-6">
															<span class="time">
																<?php
                                                                
                                                                if ($restorancek['restoran_carsambaacilis']=="" or $restorancek['restoran_carsambakapanis']==""){

                                                                	echo "KAPALI";

                                                                } else {

                                                                	echo $restorancek['restoran_carsambaacilis']." - ".$restorancek['restoran_carsambakapanis'];

                                                                }

																  ?>
															</span>
														</div>
														
													</div>
												
												</li>
												
												<li>
												
													<div class="row">
													
														<div class="col-xs-6 col-sm-6">
															<span class="day">
																PERŞEMBE
															</span>
														</div>
														
														<div class="col-xs-6 col-sm-6">
															<span class="time">
																<?php
                                                                
                                                                if ($restorancek['restoran_persembeacilis']=="" or $restorancek['restoran_persembekapanis']==""){

                                                                	echo "KAPALI";

                                                                } else {

                                                                	echo $restorancek['restoran_persembeacilis']." - ".$restorancek['restoran_persembekapanis'];

                                                                }

																  ?>
															</span>
														</div>
														
													</div>
												
												</li>
												
												<li>
												
													<div class="row">
													
														<div class="col-xs-6 col-sm-6">
															<span class="day">
																CUMA
															</span>
														</div>
														
														<div class="col-xs-6 col-sm-6">
															<span class="time">
																<?php
                                                                
                                                                if ($restorancek['restoran_cumaacilis']=="" or $restorancek['restoran_cumakapanis']==""){

                                                                	echo "KAPALI";

                                                                } else {

                                                                	echo $restorancek['restoran_cumaacilis']." - ".$restorancek['restoran_cumakapanis'];

                                                                }

																  ?>
															</span>
														</div>
														
													</div>
												
												</li>
												
												<li>
												
													<div class="row">
													
														<div class="col-xs-6 col-sm-6">
															<span class="day">
																CUMARTESİ
															</span>
														</div>
														
														<div class="col-xs-6 col-sm-6">
															<span class="time">
																<?php
                                                                
                                                                if ($restorancek['restoran_cumartesiacilis']=="" or $restorancek['restoran_cumartesikapanis']==""){

                                                                	echo "KAPALI";

                                                                } else {

                                                                	echo $restorancek['restoran_cumartesiacilis']." - ".$restorancek['restoran_cumartesikapanis'];

                                                                }

																  ?>
															</span>
														</div>
														
													</div>
												
												</li>
												
												<li style="color: <?php echo $restorancek['restoran_renk']; ?>;font-weight: 700;">
												
													<div class="row">
													
														<div class="col-xs-6 col-sm-6">
															<span style="color: <?php echo $restorancek['restoran_renk']; ?>;font-weight: 700;" class="day">
																PAZAR
															</span>
														</div>
														
														<div class="col-xs-6 col-sm-6">
															<span style="color: <?php echo $restorancek['restoran_renk']; ?>;font-weight: 700;" class="time text-uppercase font700 spacing-2">
																<?php if ($restorancek['restoran_pazaracilis']=="" or $restorancek['restoran_pazarkapanis']=="") {
																	echo "KAPALI";
																} else {
																	echo $restorancek['restoran_pazaracilis']." - ".$restorancek['restoran_pazarkapanis'];
																} ?>
															</span>
														</div>
														
													</div>
												
												</li>
												
											</ul>
											
														
                                                   
														<?php break;

														case '1': ?>

														<ul class="open-time-list">

												
											
												<li style="color: <?php echo $restorancek['restoran_renk']; ?>;font-weight: 700;">
												
													<div class="row">
													
														<div class="col-xs-6 col-sm-6">
															<span style="color: <?php echo $restorancek['restoran_renk']; ?>;font-weight: 700;" class="day">
																PAZARTESİ
															</span>
														</div>
														
														<div class="col-xs-6 col-sm-6">
															<span style="color: <?php echo $restorancek['restoran_renk']; ?>;font-weight: 700;" class="time">
																<?php if ($restorancek['restoran_pazartesiacilis']=="" or $restorancek['restoran_pazartesikapanis']=="") {
																	echo "KAPALI";
																} else {

																	echo $restorancek['restoran_pazartesiacilis']." - ".$restorancek['restoran_pazartesikapanis'];
																} ?>
															</span>
														</div>
														
													</div>
												
												</li>
												
												<li>
												
													<div class="row">
													
														<div class="col-xs-6 col-sm-6">
															<span class="day">
																SALI
															</span>
														</div>
														
														<div class="col-xs-6 col-sm-6">
															<span class="time">
																<?php
                                                                
                                                                if ($restorancek['restoran_saliacilis']=="" or $restorancek['restoran_salikapanis']==""){

                                                                	echo "KAPALI";

                                                                } else {

                                                                	echo $restorancek['restoran_saliacilis']." - ".$restorancek['restoran_salikapanis'];

                                                                }

																  ?>
															</span>
														</div>
														
													</div>
												
												</li>
												
												<li>
												
													<div class="row">
													
														<div class="col-xs-6 col-sm-6">
															<span class="day">
																ÇARŞAMBA
															</span>
														</div>
														
														<div class="col-xs-6 col-sm-6">
															<span class="time">
																<?php
                                                                
                                                                if ($restorancek['restoran_carsambaacilis']=="" or $restorancek['restoran_carsambakapanis']==""){

                                                                	echo "KAPALI";

                                                                } else {

                                                                	echo $restorancek['restoran_carsambaacilis']." - ".$restorancek['restoran_carsambakapanis'];

                                                                }

																  ?>
															</span>
														</div>
														
													</div>
												
												</li>
												
												<li>
												
													<div class="row">
													
														<div class="col-xs-6 col-sm-6">
															<span class="day">
																PERŞEMBE
															</span>
														</div>
														
														<div class="col-xs-6 col-sm-6">
															<span class="time">
																<?php
                                                                
                                                                if ($restorancek['restoran_persembeacilis']=="" or $restorancek['restoran_persembekapanis']==""){

                                                                	echo "KAPALI";

                                                                } else {

                                                                	echo $restorancek['restoran_persembeacilis']." - ".$restorancek['restoran_persembekapanis'];

                                                                }

																  ?>
															</span>
														</div>
														
													</div>
												
												</li>
												
												<li>
												
													<div class="row">
													
														<div class="col-xs-6 col-sm-6">
															<span class="day">
																CUMA
															</span>
														</div>
														
														<div class="col-xs-6 col-sm-6">
															<span class="time">
																<?php
                                                                
                                                                if ($restorancek['restoran_persembeacilis']=="" or $restorancek['restoran_persembekapanis']==""){

                                                                	echo "KAPALI";

                                                                } else {

                                                                	echo $restorancek['restoran_persembeacilis']." - ".$restorancek['restoran_persembekapanis'];

                                                                }

																  ?>
															</span>
														</div>
														
													</div>
												
												</li>
												
												<li>
												
													<div class="row">
													
														<div class="col-xs-6 col-sm-6">
															<span class="day">
																CUMARTESİ
															</span>
														</div>
														
														<div class="col-xs-6 col-sm-6">
															<span class="time">
																<?php
                                                                
                                                                if ($restorancek['restoran_cumartesiacilis']=="" or $restorancek['restoran_cumartesikapanis']==""){

                                                                	echo "KAPALI";

                                                                } else {

                                                                	echo $restorancek['restoran_cumartesiacilis']." - ".$restorancek['restoran_cumartesikapanis'];

                                                                }

																  ?>
															</span>
														</div>
														
													</div>
												
												</li>
												
												<li>
												
													<div class="row">
													
														<div class="col-xs-6 col-sm-6">
															<span class="day">
																PAZAR
															</span>
														</div>
														
														<div class="col-xs-6 col-sm-6">
															<span class="time">
																<?php
                                                                
                                                                if ($restorancek['restoran_pazaracilis']=="" or $restorancek['restoran_pazarkapanis']==""){

                                                                	echo "KAPALI";

                                                                } else {

                                                                	echo $restorancek['restoran_pazaracilis']." - ".$restorancek['restoran_pazarkapanis'];

                                                                }

																  ?>
															</span>
														</div>
														
													</div>
												
												</li>
												
											</ul>
											

														<?php break;

														case '2': ?>
                                                 
                                                 <ul class="open-time-list">

												
											
												<li>
												
													<div class="row">
													
														<div class="col-xs-6 col-sm-6">
															<span class="day">
																PAZARTESİ
															</span>
														</div>
														
														<div class="col-xs-6 col-sm-6">
															<span class="time">
																<?php
                                                                
                                                                if ($restorancek['restoran_pazartesiacilis']=="" or $restorancek['restoran_pazartesikapanis']==""){

                                                                	echo "KAPALI";

                                                                } else {

                                                                	echo $restorancek['restoran_pazartesiacilis']." - ".$restorancek['restoran_pazartesikapanis'];

                                                                }

																  ?>
															</span>
														</div>
														
													</div>
												
												</li>
												
												<li style="color: <?php echo $restorancek['restoran_renk']; ?>;font-weight: 700;">
												
													<div class="row">
													
														<div class="col-xs-6 col-sm-6">
															<span style="color: <?php echo $restorancek['restoran_renk']; ?>;font-weight: 700;" class="day">
																SALI
															</span>
														</div>
														
														<div class="col-xs-6 col-sm-6">
															<span style="color: <?php echo $restorancek['restoran_renk']; ?>;font-weight: 700;" class="time">
																<?php if ($restorancek['restoran_saliacilis']=="" or $restorancek['restoran_salikapanis']=="") {
																	echo "KAPALI";
																} else {

																	echo $restorancek['restoran_saliacilis']." - ".$restorancek['restoran_salikapanis'];
																} ?>
															</span>
														</div>
														
													</div>
												
												</li>
												
												<li>
												
													<div class="row">
													
														<div class="col-xs-6 col-sm-6">
															<span class="day">
																ÇARŞAMBA
															</span>
														</div>
														
														<div class="col-xs-6 col-sm-6">
															<span class="time">
																<?php
                                                                
                                                                if ($restorancek['restoran_carsambaacilis']=="" or $restorancek['restoran_carsambakapanis']==""){

                                                                	echo "KAPALI";

                                                                } else {

                                                                	echo $restorancek['restoran_carsambaacilis']." - ".$restorancek['restoran_carsambakapanis'];

                                                                }

																  ?>
															</span>
														</div>
														
													</div>
												
												</li>
												
												<li>
												
													<div class="row">
													
														<div class="col-xs-6 col-sm-6">
															<span class="day">
																PERŞEMBE
															</span>
														</div>
														
														<div class="col-xs-6 col-sm-6">
															<span class="time">
																<?php
                                                                
                                                                if ($restorancek['restoran_persembeacilis']=="" or $restorancek['restoran_persembekapanis']==""){

                                                                	echo "KAPALI";

                                                                } else {

                                                                	echo $restorancek['restoran_persembeacilis']." - ".$restorancek['restoran_persembekapanis'];

                                                                }

																  ?>
															</span>
														</div>
														
													</div>
												
												</li>
												
												<li>
												
													<div class="row">
													
														<div class="col-xs-6 col-sm-6">
															<span class="day">
																CUMA
															</span>
														</div>
														
														<div class="col-xs-6 col-sm-6">
															<span class="time">
																<?php
                                                                
                                                                if ($restorancek['restoran_cumaacilis']=="" or $restorancek['restoran_cumakapanis']==""){

                                                                	echo "KAPALI";

                                                                } else {

                                                                	echo $restorancek['restoran_cumaacilis']." - ".$restorancek['restoran_cumakapanis'];

                                                                }

																  ?>
															</span>
														</div>
														
													</div>
												
												</li>
												
												<li>
												
													<div class="row">
													
														<div class="col-xs-6 col-sm-6">
															<span class="day">
																CUMARTESİ
															</span>
														</div>
														
														<div class="col-xs-6 col-sm-6">
															<span class="time">
																<?php
                                                                
                                                                if ($restorancek['restoran_cumartesiacilis']=="" or $restorancek['restoran_cumartesikapanis']==""){

                                                                	echo "KAPALI";

                                                                } else {

                                                                	echo $restorancek['restoran_cumartesiacilis']." - ".$restorancek['restoran_cumartesikapanis'];

                                                                }

																  ?>
															</span>
														</div>
														
													</div>
												
												</li>
												
												<li>
												
													<div class="row">
													
														<div class="col-xs-6 col-sm-6">
															<span class="day">
																PAZAR
															</span>
														</div>
														
														<div class="col-xs-6 col-sm-6">
															<span class="time">
																<?php
                                                                
                                                                if ($restorancek['restoran_pazaracilis']=="" or $restorancek['restoran_pazarkapanis']==""){

                                                                	echo "KAPALI";

                                                                } else {

                                                                	echo $restorancek['restoran_pazaracilis']." - ".$restorancek['restoran_pazarkapanis'];

                                                                }

																  ?>
															</span>
														</div>
														
													</div>
												
												</li>
												
											</ul>
											


													<?php	break;

														case '3': ?>

														<ul class="open-time-list">

												
											
												<li>
												
													<div class="row">
													
														<div class="col-xs-6 col-sm-6">
															<span class="day">
																PAZARTESİ
															</span>
														</div>
														
														<div class="col-xs-6 col-sm-6">
															<span class="time">
																<?php
                                                                
                                                                if ($restorancek['restoran_pazartesiacilis']=="" or $restorancek['restoran_pazartesikapanis']==""){

                                                                	echo "KAPALI";

                                                                } else {

                                                                	echo $restorancek['restoran_pazartesiacilis']." - ".$restorancek['restoran_pazartesikapanis'];

                                                                }

																  ?>
															</span>
														</div>
														
													</div>
												
												</li>
												
												<li>
												
													<div class="row">
													
														<div class="col-xs-6 col-sm-6">
															<span class="day">
																SALI
															</span>
														</div>
														
														<div class="col-xs-6 col-sm-6">
															<span class="time">
																<?php
                                                                
                                                                if ($restorancek['restoran_saliacilis']=="" or $restorancek['restoran_salikapanis']==""){

                                                                	echo "KAPALI";

                                                                } else {

                                                                	echo $restorancek['restoran_saliacilis']." - ".$restorancek['restoran_salikapanis'];

                                                                }

																  ?>
															</span>
														</div>
														
													</div>
												
												</li>
												
												<li style="color: <?php echo $restorancek['restoran_renk']; ?>;font-weight: 700;">
												
													<div class="row">
													
														<div class="col-xs-6 col-sm-6">
															<span style="color: <?php echo $restorancek['restoran_renk']; ?>;font-weight: 700;" class="day">
																ÇARŞAMBA
															</span>
														</div>
														
														<div class="col-xs-6 col-sm-6">
															<span style="color: <?php echo $restorancek['restoran_renk']; ?>;font-weight: 700;" class="time">
																<?php if ($restorancek['restoran_carsambaacilis']=="" or $restorancek['restoran_carsambakapanis']=="") {
																	echo "KAPALI";
																} else {

																	echo $restorancek['restoran_carsambaacilis']." - ".$restorancek['restoran_carsambakapanis'];
																}  ?>
															</span>
														</div>
														
													</div>
												
												</li>
												
												<li>
												
													<div class="row">
													
														<div class="col-xs-6 col-sm-6">
															<span class="day">
																PERŞEMBE
															</span>
														</div>
														
														<div class="col-xs-6 col-sm-6">
															<span class="time">
																<?php
                                                                
                                                                if ($restorancek['restoran_persembeacilis']=="" or $restorancek['restoran_persembekapanis']==""){

                                                                	echo "KAPALI";

                                                                } else {

                                                                	echo $restorancek['restoran_persembeacilis']." - ".$restorancek['restoran_persembekapanis'];

                                                                }

																  ?>
															</span>
														</div>
														
													</div>
												
												</li>
												
												<li>
												
													<div class="row">
													
														<div class="col-xs-6 col-sm-6">
															<span class="day">
																CUMA
															</span>
														</div>
														
														<div class="col-xs-6 col-sm-6">
															<span class="time">
																<?php
                                                                
                                                                if ($restorancek['restoran_cumaacilis']=="" or $restorancek['restoran_cumakapanis']==""){

                                                                	echo "KAPALI";

                                                                } else {

                                                                	echo $restorancek['restoran_cumaacilis']." - ".$restorancek['restoran_cumakapanis'];

                                                                }

																  ?>
															</span>
														</div>
														
													</div>
												
												</li>
												
												<li>
												
													<div class="row">
													
														<div class="col-xs-6 col-sm-6">
															<span class="day">
																CUMARTESİ
															</span>
														</div>
														
														<div class="col-xs-6 col-sm-6">
															<span class="time">
																<?php
                                                                
                                                                if ($restorancek['restoran_cumartesiacilis']=="" or $restorancek['restoran_cumartesikapanis']==""){

                                                                	echo "KAPALI";

                                                                } else {

                                                                	echo $restorancek['restoran_cumartesiacilis']." - ".$restorancek['restoran_cumartesikapanis'];

                                                                }

																  ?>
															</span>
														</div>
														
													</div>
												
												</li>
												
												<li>
												
													<div class="row">
													
														<div class="col-xs-6 col-sm-6">
															<span class="day">
																PAZAR
															</span>
														</div>
														
														<div class="col-xs-6 col-sm-6">
															<span class="time">
																<?php
                                                                
                                                                if ($restorancek['restoran_pazaracilis']=="" or $restorancek['restoran_pazarkapanis']==""){

                                                                	echo "KAPALI";

                                                                } else {

                                                                	echo $restorancek['restoran_pazaracilis']." - ".$restorancek['restoran_pazarkapanis'];

                                                                }

																  ?>
															</span>
														</div>
														
													</div>
												
												</li>
												
											</ul>
											

														<?php break;

														case '4': ?>

														<ul class="open-time-list">

												
											
												<li>
												
													<div class="row">
													
														<div class="col-xs-6 col-sm-6">
															<span class="day">
																PAZARTESİ
															</span>
														</div>
														
														<div class="col-xs-6 col-sm-6">
															<span class="time">
																<?php if ($restorancek['restoran_pazartesiacilis']=="" or $restorancek['restoran_pazartesikapanis']=="") {
																	echo "KAPALI";
																} else {

																	echo $restorancek['restoran_pazartesiacilis']." - ".$restorancek['restoran_pazartesikapanis'];
																}  ?>
															</span>
														</div>
														
													</div>
												
												</li>
												
												<li>
												
													<div class="row">
													
														<div class="col-xs-6 col-sm-6">
															<span class="day">
																SALI
															</span>
														</div>
														
														<div class="col-xs-6 col-sm-6">
															<span class="time">
																<?php
                                                                
                                                                if ($restorancek['restoran_saliacilis']=="" or $restorancek['restoran_salikapanis']==""){

                                                                	echo "KAPALI";

                                                                } else {

                                                                	echo $restorancek['restoran_saliacilis']." - ".$restorancek['restoran_salikapanis'];

                                                                }

																  ?>
															</span>
														</div>
														
													</div>
												
												</li>
												
												<li>
												
													<div class="row">
													
														<div class="col-xs-6 col-sm-6">
															<span class="day">
																ÇARŞAMBA
															</span>
														</div>
														
														<div class="col-xs-6 col-sm-6">
															<span class="time">
																<?php
                                                                
                                                                if ($restorancek['restoran_carsambaacilis']=="" or $restorancek['restoran_carsambakapanis']==""){

                                                                	echo "KAPALI";

                                                                } else {

                                                                	echo $restorancek['restoran_carsambaacilis']." - ".$restorancek['restoran_carsambakapanis'];

                                                                }

																  ?>
															</span>
														</div>
														
													</div>
												
												</li>
												
												<li style="color: <?php echo $restorancek['restoran_renk']; ?>;font-weight: 700;">
												
													<div class="row">
													
														<div class="col-xs-6 col-sm-6">
															<span style="color: <?php echo $restorancek['restoran_renk']; ?>;font-weight: 700;" class="day">
																PERŞEMBE
															</span>
														</div>
														
														<div class="col-xs-6 col-sm-6">
															<span style="color: <?php echo $restorancek['restoran_renk']; ?>;font-weight: 700;" class="time">
																<?php if ($restorancek['restoran_persembeacilis']=="" or $restorancek['restoran_persembekapanis']=="") {
																	echo "KAPALI";
																} else {

																	echo $restorancek['restoran_persembeacilis']." - ".$restorancek['restoran_persembekapanis'];
																}  ?>
															</span>
														</div>
														
													</div>
												
												</li>
												
												<li>
												
													<div class="row">
													
														<div class="col-xs-6 col-sm-6">
															<span class="day">
																CUMA
															</span>
														</div>
														
														<div class="col-xs-6 col-sm-6">
															<span class="time">
																<?php
                                                                
                                                                if ($restorancek['restoran_cumaacilis']=="" or $restorancek['restoran_cumakapanis']==""){

                                                                	echo "KAPALI";

                                                                } else {

                                                                	echo $restorancek['restoran_cumaacilis']." - ".$restorancek['restoran_cumakapanis'];

                                                                }

																  ?>
															</span>
														</div>
														
													</div>
												
												</li>
												
												<li>
												
													<div class="row">
													
														<div class="col-xs-6 col-sm-6">
															<span class="day">
																CUMARTESİ
															</span>
														</div>
														
														<div class="col-xs-6 col-sm-6">
															<span class="time">
																<?php
                                                                
                                                                if ($restorancek['restoran_cumartesiacilis']=="" or $restorancek['restoran_cumartesikapanis']==""){

                                                                	echo "KAPALI";

                                                                } else {

                                                                	echo $restorancek['restoran_cumartesiacilis']." - ".$restorancek['restoran_cumartesikapanis'];

                                                                }

																  ?>
															</span>
														</div>
														
													</div>
												
												</li>
												
												<li>
												
													<div class="row">
													
														<div class="col-xs-6 col-sm-6">
															<span class="day">
																PAZAR
															</span>
														</div>
														
														<div class="col-xs-6 col-sm-6">
															<span class="time">
																<?php
                                                                
                                                                if ($restorancek['restoran_pazaracilis']=="" or $restorancek['restoran_pazarkapanis']==""){

                                                                	echo "KAPALI";

                                                                } else {

                                                                	echo $restorancek['restoran_pazaracilis']." - ".$restorancek['restoran_pazarkapanis'];

                                                                }

																  ?>
															</span>
														</div>
														
													</div>
												
												</li>
												
											</ul>
											

														<?php break;

														case '5': ?>

														<ul class="open-time-list">

												
											
												<li>
												
													<div class="row">
													
														<div class="col-xs-6 col-sm-6">
															<span class="day">
																PAZARTESİ
															</span>
														</div>
														
														<div class="col-xs-6 col-sm-6">
															<span class="time">
																<?php
                                                                
                                                                if ($restorancek['restoran_pazartesiacilis']=="" or $restorancek['restoran_pazartesikapanis']==""){

                                                                	echo "KAPALI";

                                                                } else {

                                                                	echo $restorancek['restoran_pazartesiacilis']." - ".$restorancek['restoran_pazartesikapanis'];

                                                                }

																  ?>
															</span>
														</div>
														
													</div>
												
												</li>
												
												<li>
												
													<div class="row">
													
														<div class="col-xs-6 col-sm-6">
															<span class="day">
																SALI
															</span>
														</div>
														
														<div class="col-xs-6 col-sm-6">
															<span class="time">
																<?php
                                                                
                                                                if ($restorancek['restoran_saliacilis']=="" or $restorancek['restoran_salikapanis']==""){

                                                                	echo "KAPALI";

                                                                } else {

                                                                	echo $restorancek['restoran_saliacilis']." - ".$restorancek['restoran_salikapanis'];

                                                                }

																  ?>
															</span>
														</div>
														
													</div>
												
												</li>
												
												<li>
												
													<div class="row">
													
														<div class="col-xs-6 col-sm-6">
															<span class="day">
																ÇARŞAMBA
															</span>
														</div>
														
														<div class="col-xs-6 col-sm-6">
															<span class="time">
																<?php
                                                                
                                                                if ($restorancek['restoran_carsambaacilis']=="" or $restorancek['restoran_carsambakapanis']==""){

                                                                	echo "KAPALI";

                                                                } else {

                                                                	echo $restorancek['restoran_carsambaacilis']." - ".$restorancek['restoran_carsambakapanis'];

                                                                }

																  ?>
															</span>
														</div>
														
													</div>
												
												</li>
												
												<li>
												
													<div class="row">
													
														<div class="col-xs-6 col-sm-6">
															<span class="day">
																PERŞEMBE
															</span>
														</div>
														
														<div class="col-xs-6 col-sm-6">
															<span class="time">
																<?php
                                                                
                                                                if ($restorancek['restoran_persembeacilis']=="" or $restorancek['restoran_persembekapanis']==""){

                                                                	echo "KAPALI";

                                                                } else {

                                                                	echo $restorancek['restoran_persembeacilis']." - ".$restorancek['restoran_persembekapanis'];

                                                                }

																  ?>
															</span>
														</div>
														
													</div>
												
												</li>
												
												<li style="color: <?php echo $restorancek['restoran_renk']; ?>">
												
													<div class="row">
													
														<div class="col-xs-6 col-sm-6">
															<span style="color: <?php echo $restorancek['restoran_renk']; ?>;font-weight: 700;" class="day">
																CUMA
															</span>
														</div>
														
														<div class="col-xs-6 col-sm-6">
															<span style="color: <?php echo $restorancek['restoran_renk']; ?>;font-weight: 700;" class="time">
																<?php if ($restorancek['restoran_cumaacilis']=="" or $restorancek['restoran_cumakapanis']=="") {
																	echo "KAPALI";
																} else {

																	echo $restorancek['restoran_cumaacilis']." - ".$restorancek['restoran_cumakapanis'];
																}  ?>
															</span>
														</div>
														
													</div>
												
												</li>
												
												<li>
												
													<div class="row">
													
														<div class="col-xs-6 col-sm-6">
															<span class="day">
																CUMARTESİ
															</span>
														</div>
														
														<div class="col-xs-6 col-sm-6">
															<span class="time">
																<?php
                                                                
                                                                if ($restorancek['restoran_cumartesiacilis']=="" or $restorancek['restoran_cumartesikapanis']==""){

                                                                	echo "KAPALI";

                                                                } else {

                                                                	echo $restorancek['restoran_cumartesiacilis']." - ".$restorancek['restoran_cumartesikapanis'];

                                                                }

																  ?>
															</span>
														</div>
														
													</div>
												
												</li>
												
												<li>
												
													<div class="row">
													
														<div class="col-xs-6 col-sm-6">
															<span class="day">
																PAZAR
															</span>
														</div>
														
														<div class="col-xs-6 col-sm-6">
															<span class="time">
																<?php
                                                                
                                                                if ($restorancek['restoran_pazaracilis']=="" or $restorancek['restoran_pazarkapanis']==""){

                                                                	echo "KAPALI";

                                                                } else {

                                                                	echo $restorancek['restoran_pazaracilis']." - ".$restorancek['restoran_pazarkapanis'];

                                                                }

																  ?>
															</span>
														</div>
														
													</div>
												
												</li>
												
											</ul>
											

														<?php break;

														case '6': ?>

														<ul class="open-time-list">

												
											
												<li>
												
													<div class="row">
													
														<div class="col-xs-6 col-sm-6">
															<span class="day">
																PAZARTESİ
															</span>
														</div>
														
														<div class="col-xs-6 col-sm-6">
															<span class="time">
																<?php
                                                                
                                                                if ($restorancek['restoran_pazartesiacilis']=="" or $restorancek['restoran_pazartesikapanis']==""){

                                                                	echo "KAPALI";

                                                                } else {

                                                                	echo $restorancek['restoran_pazartesiacilis']." - ".$restorancek['restoran_pazartesikapanis'];

                                                                }

																  ?>
															</span>
														</div>
														
													</div>
												
												</li>
												
												<li>
												
													<div class="row">
													
														<div class="col-xs-6 col-sm-6">
															<span class="day">
																SALI
															</span>
														</div>
														
														<div class="col-xs-6 col-sm-6">
															<span class="time">
																<?php
                                                                
                                                                if ($restorancek['restoran_saliacilis']=="" or $restorancek['restoran_salikapanis']==""){

                                                                	echo "KAPALI";

                                                                } else {

                                                                	echo $restorancek['restoran_saliacilis']." - ".$restorancek['restoran_salikapanis'];

                                                                }

																  ?>
															</span>
														</div>
														
													</div>
												
												</li>
												
												<li>
												
													<div class="row">
													
														<div class="col-xs-6 col-sm-6">
															<span class="day">
																ÇARŞAMBA
															</span>
														</div>
														
														<div class="col-xs-6 col-sm-6">
															<span class="time">
																<?php
                                                                
                                                                if ($restorancek['restoran_carsambaacilis']=="" or $restorancek['restoran_carsambakapanis']==""){

                                                                	echo "KAPALI";

                                                                } else {

                                                                	echo $restorancek['restoran_carsambaacilis']." - ".$restorancek['restoran_carsambakapanis'];

                                                                }

																  ?>
															</span>
														</div>
														
													</div>
												
												</li>
												
												<li>
												
													<div class="row">
													
														<div class="col-xs-6 col-sm-6">
															<span class="day">
																PERŞEMBE
															</span>
														</div>
														
														<div class="col-xs-6 col-sm-6">
															<span class="time">
																<?php
                                                                
                                                                if ($restorancek['restoran_persembeacilis']=="" or $restorancek['restoran_persembekapanis']==""){

                                                                	echo "KAPALI";

                                                                } else {

                                                                	echo $restorancek['restoran_persembeacilis']." - ".$restorancek['restoran_persembekapanis'];

                                                                }

																  ?>
															</span>
														</div>
														
													</div>
												
												</li>
												
												<li>
												
													<div class="row">
													
														<div class="col-xs-6 col-sm-6">
															<span class="day">
																CUMA
															</span>
														</div>
														
														<div class="col-xs-6 col-sm-6">
															<span class="time">
																<?php
                                                                
                                                                if ($restorancek['restoran_cumaacilis']=="" or $restorancek['restoran_cumakapanis']==""){

                                                                	echo "KAPALI";

                                                                } else {

                                                                	echo $restorancek['restoran_cumaacilis']." - ".$restorancek['restoran_cumakapanis'];

                                                                }

																  ?>
															</span>
														</div>
														
													</div>
												
												</li>
												
												<li style="color: <?php echo $restorancek['restoran_renk']; ?>;font-weight: 700;">
												
													<div class="row">
													
														<div class="col-xs-6 col-sm-6">
															<span style="color: <?php echo $restorancek['restoran_renk']; ?>;font-weight: 700;" class="day">
																CUMARTESİ
															</span>
														</div>
														
														<div class="col-xs-6 col-sm-6">
															<span style="color: <?php echo $restorancek['restoran_renk']; ?>;font-weight: 700;" class="time">
																<?php if ($restorancek['restoran_cumartesiacilis']=="" or $restorancek['restoran_cumartesikapanis']=="") {
																	echo "KAPALI";
																} else {

																	echo $restorancek['restoran_cumartesiacilis']." - ".$restorancek['restoran_cumartesikapanis'];
																}  ?>
															</span>
														</div>
														
													</div>
												
												</li>
												
												<li>
												
													<div class="row">
													
														<div class="col-xs-6 col-sm-6">
															<span class="day">
																PAZAR
															</span>
														</div>
														
														<div class="col-xs-6 col-sm-6">
															<span class="time">
																<?php
                                                                
                                                                if ($restorancek['restoran_pazaracilis']=="" or $restorancek['restoran_pazarkapanis']==""){

                                                                	echo "KAPALI";

                                                                } else {

                                                                	echo $restorancek['restoran_pazarcilis']." - ".$restorancek['restoran_pazarkapanis'];

                                                                }

																  ?>
															</span>
														</div>
														
													</div>
												
												</li>
												
											</ul>
											

													<?php	break;
													
													
												} ?>
											
											
										</div>
										
									</div>
								
								
				</div>

				
			
			
				
				<div class="row mt-40 mb-30">

					<div class="col-xs-12 col-xs-12 col-md-12">
						
						<div class="submite-list-wrapper">
						
							
							
							<div class="submite-list-box">
							
								<div class="row">
								
									<div class="col-xs-12 col-sm-12 mb-30-xs">
									
										<div class="row gap-20">
											
											<?php $anliksiparissec=$db->prepare("SELECT * from onsiparisler where siparis_turu=:turu and restoran_id=:id and kullanici_id=:kulid and siparis_bildirim=:bildirim");

											$anliksiparissec->execute(array(

"id" => $restoran_id,
"kulid" => $_COOKIE['kullanici_id'],
"turu" => 1,
"bildirim" => 1

											));

											$anliksiparissay=$anliksiparissec->rowCount();

											if ($anliksiparissay==0) { ?>
											 	
                                
										

										
											
											
											
											
											
											

											<form id="siparisverform">

												<div class="col-xs-12 col-sm-6 col-md-6">
											
												<div class="form-group">
													<label>Misafir Sayısı*</label>
													<select class="form-control" name="siparis_kisisayisi">
														<option selected="">1</option>
														<option>2</option>
														<option>3</option>
														<option>4</option>
													</select>
												</div>
												
											</div>

											<div class="col-xs-12 col-sm-6 col-md-6">
											
												<div class="form-group">
													<label>Varış Saati (Bugün)*</label>
													<input type="time" name="siparis_variszaman" class="form-control">
												</div>
												
											</div>
											
											

											<input type="hidden" value="<?php echo $restoran_id; ?>" name="restoran_id">

											

											

											
											
											

											
											

											<div class="col-xs-12 col-sm-12">
												
												<div id="detail-content-sticky-nav-01" class="detail-content-section clearfix">
							
								<div class="section-title-02">
									<h3><span>MENÜ</span></h3>
								</div>
								
								<div class="tab-style-01-wrapper mt-30 mb-20">

									<?php $menucesitsec=$db->prepare("SELECT * from restoranmenucesit where restoran_id=:id");
										$menucesitsec->execute(array(

											"id" => $restoran_id

										));

										$menucesitsay=$menucesitsec->rowCount();



										if ($menucesitsay==0 and ($restoran_id==$kullanicioturumcek['restoran_id'])) { ?>
											
                                        <h4 align="center">Henüz menü eklememişsiniz. <br><a href="menu-settings">Hemen ekleyin <i style='font-size: 17px;' class="fas fa-arrow-right"></i></a></h4>

									<?php	} ?>

								

									
							
									<ul class="tab-responsive tab-nav">

										<?php

										$say=0;


										while ($menucesitcek=$menucesitsec->fetch(PDO::FETCH_ASSOC)) { $say++; ?>

											<li  <?php if ($say==1) { ?>
												class='active'
											<?php } ?> ><a style="color:<?php echo $restorancek['restoran_renk']; ?>;" href="#cesit_id<?php echo $menucesitcek['cesit_id']; ?>" data-toggle="tab"><?php echo $menucesitcek['cesit_ad']; ?></a></li>
								
										<?php } ?>
										
										
									</ul>
									
									<div class="tab-content" >


										<?php $menucesitsec2=$db->prepare("SELECT * from restoranmenucesit where restoran_id=:id");
										$menucesitsec2->execute(array(

											"id" => $restoran_id

										));

										$say=0;


										while ($menucesitcek2=$menucesitsec2->fetch(PDO::FETCH_ASSOC)) { $say++; ?>


											<div class="tab-pane fade in <?php if($say==1){ ?>

												active


										<?php	} ?> " id="cesit_id<?php echo $menucesitcek2['cesit_id']; ?>">


										

											<div class="tab-inner">
												
												<div class="food-menu-wrapper">
												
													<div class="GridLex-gap-30">


													
														<div class="GridLex-grid-noGutter-equalHeight">

															<?php $yemeksec=$db->prepare("SELECT * from yemekler where restoran_id=:id and yemek_cesit=:cesit");
										$yemeksec->execute(array(

											"id" => $restoran_id,
											"cesit" => $menucesitcek2['cesit_id']

										));

										$say=0;

										while ($yemekcek=$yemeksec->fetch(PDO::FETCH_ASSOC)) { $say++; ?>

											<div class="GridLex-col-6_sm-12_xs-12_xss-12">
															
																
                                                  <?php if (empty($yemekcek['yemek_foto'])) { ?>

                                                  	<div class="food-menu-item no-image clearfix">


                                                  	
                                                  <?php } else { ?>


                                                                <div class="food-menu-item clearfix">

																	<div class="image">
																		<img style="height: 70px;" src="<?php echo $yemekcek['yemek_foto']; ?>" alt="image" />
																	</div>


                                                 <?php } ?>
																	
																
								
																	<div class="content">
																	
																		<h6><span><?php echo $yemekcek['yemek_ad']; ?></span></h6>
																		<p><?php echo $yemekcek['yemek_aciklama']; ?></p>
																		
																		<div style="color: <?php echo $restorancek['restoran_renk']; ?>;" class="price">
																			<?php echo $restoran_currency." ".$yemekcek['yemek_fiyat']; ?>
																		</div>

																		
																		
																	</div>

																	<div class="checkbox-block font-icon-checkbox">
								<select  name="yemekadet_<?php echo $yemekcek['yemek_id']; ?>" class="form-control adetoption" >
									<option value="0"  selected="">Adet</option>
									<option value="1">1</option>
									<option value="2">2</option>
									<option value="3">3</option>
									<option value="4">4</option>
									<option value="5">5</option>
								</select>

								<input type="hidden" type="text" value="<?php echo $yemekcek['yemek_id']; ?>" name="yemekler[]">
							</div>


                                                                

																	
																</div>




															
															</div>

															
 




											

									<?php	} ?>

           
						

										 
														
															
															
														</div>
														
													</div>
												
												</div>

											</div>
										</div>
										
										
											

										<?php } ?>

										

									
										

									</div>

									<input type="hidden" name="onsiparisver">
									<input type="hidden" value="<?php echo $restorancek['restoran_id']; ?>" name="restoran_id">
								
								</div>
								
							</div>


							
											</div>

											 <div class="col-xs-12 col-sm-12">
									
												<div class="form-group bootstrap3-wysihtml5-wrapper">
												
													<label>Özel İstek (opsiyonel)</label>
													<textarea class="bootstrap3-wysihtml5 form-control" maxlength="500" name="siparis_ozeltalep"  style="height: 100px;"></textarea>
													
												</div>
												
											</div>



											

											
											
											
												<div class="col-xs-12 col-sm-12">

												
											 <?php if (isset($_COOKIE['kullanicioturum'])) { ?>
											 	
											 	<button style="background-color:<?php echo $restorancek['restoran_renk']; ?>;border:1px solid <?php echo $restorancek['restoran_renk']; ?>" type="submit" id="siparisverbutton" name="siparisver" class="btn btn-primary mt-15">Siparişi Tamamla</button>

											<?php } else { ?>

												<a href="javascript:void(0);" class="btn btn-primary mt-15 btn-ajax-login">Siparişi Tamamla</a>


											<?php } ?>
												
												
												
											
											</div>
											

											</form>
											
										

											<?php } else { ?>

												<?php while ($anliksipariscek=$anliksiparissec->fetch(PDO::FETCH_ASSOC)) {
													
                                                 $restoransec=$db->prepare("SELECT * from restoranlar where restoran_id=:id");
								$restoransec->execute(array(

									"id" => $kayitlisipariscek['restoran_id']
								));

								$restorancek=$restoransec->fetch(PDO::FETCH_ASSOC); ?>

								<div class="col-xs-12 col-md-12 col-sm-12">

								<div class="restaurant-list-item clearfix">
							
								<div class="GridLex-grid-noGutter-equalHeight">
								
									
									
									<div class="GridLex-col-12_sm-12_xss-12">
									
										<div class="GridLex-grid-noGutter-equalHeight">
										
											<div class="GridLex-col-9_sm-12 content-wrapper">
											
												<div class="content">

													<p style="font-weight: bold; color: #043D75;"> Sipariş No: #<?php echo $anliksipariscek['siparis_id']; ?></p>

													<p style="font-weight: bold;"><i class="fas fa-user"></i> <?php echo $anliksipariscek['siparis_kisisayisi']." Misafir"; ?></p>

													<p style="font-weight: bold;"><i class="fas fa-clock"></i> Varış Saati: <?php echo substr($anliksipariscek['siparis_variszaman'],11,5); ?></p>
													
													
												

													<?php if (!empty($anliksipariscek['siparis_ozeltalep'])) { ?>

 														<p style="font-weight: bold;"><i class="fas fa-edit"></i> <?php echo $anliksipariscek['siparis_ozeltalep']; ?></p>

													<?php } ?>

													
													
													<p class="cuisine"><b>Siparişiniz:</b> <?php $siparisyemeksec=$db->prepare("SELECT * from onsiparisyemek where siparis_id=:id");
													$siparisyemeksec->execute(array(

														"id" => $anliksipariscek['siparis_id']
					

													));  while ($siparisyemekcek=$siparisyemeksec->fetch(PDO::FETCH_ASSOC)) { 

														$yemeksec=$db->prepare("SELECT * from yemekler where yemek_id=:id");
														$yemeksec->execute(array(

															"id" => $siparisyemekcek['yemek_id']
														));

														$yemekcek=$yemeksec->fetch(PDO::FETCH_ASSOC); ?>
															<span><?php echo $yemekcek['yemek_ad']."<b> x ".$siparisyemekcek['yemek_adet']."</b>"; ?></span>
														<?php } ?> </p>
												</div>
											
											</div>
											
											<div class="GridLex-col-3_sm-12 meta-wrapper">
											
												<div class="meta">
													
													<div class="right-bottom">
														<div class="price">Sipariş Tutarı: <span><?php echo $restoran_currency."".$anliksipariscek['siparis_tutar']; ?></span></div>
														<div class="clear"></div>
														
													</div>
												</div>
											
											</div>
										
										</div>
										
									</div>
									
								</div>
							
							</div>

							</div>

												<?php } ?>






											<?php } ?>

										</div>

									</div>
									
									
									
								</div>

							</div>

						</div>
						
					</div>

				</div>

			</div>
			
		</div>
		
		<?php require_once 'footer.php'; ?>
		<script type="text/javascript">

			
			
			$('#siparisverform').submit(function(){

$('#siparisverbutton').prop('disabled',true);


 event.preventDefault();
var seciliyemekler =  $(".adetoption>option:not([value='0']):selected").length;


  if(seciliyemekler==0){
     
    $('#siparisverbutton').prop('disabled',false);
    


    swal({

  title: "Yemek seçimi yapılmadı",
  text: "Hiçbir yemek seçimi yapmadınız.",
  icon: "warning",
  button: "OK",
});

               
   

} else {

$('#siparisverbutton').html("<img style='width:18px;height:18px;' src='css/images/flex-loader.gif'>");

	$.ajax({
            type : 'POST',
            url : 'ajax.php',
            data : $('#siparisverform').serialize(),
            success : function(sonuc){

            	
               sonuc=$.trim(sonuc);
               


            	if (sonuc=='mekankapali') {

       	 $('#siparisverbutton').prop('disabled',false);
       	 $('#siparisverbutton').html('Siparişi Tamamla');
    swal({
  title: "Restoran Kapalı",
  text: "Restoran bugün hizmet vermiyor.",
  icon: "info",
  button: "OK",
});

               } else if(sonuc=='mekanacilmadi'){

               	 $('#siparisverbutton').prop('disabled',false);
               	 $('#siparisverbutton').html('Siparişi Tamamla');

swal({
  title: "Restoran açılmamış olacak",
  text: "Belirlediğiniz varış saatinde restoran açılmamış olacak. Açılış saatinden sonrası için zaman belirleyebilirsiniz.",
  icon: "info",
  button: "OK",
});

               }  else if(sonuc=='mekankapandi'){

               	 $('#siparisverbutton').prop('disabled',false);
               	 $('#siparisverbutton').html('Siparişi Tamamla');

swal({
  title: "Restoran Kapalı",
  text: "Restoranın kapanış saati geçti.",
  icon: "info",
  button: "OK",
});

               } else if (sonuc=='zamanyanlis') {

               	 $('#siparisverbutton').prop('disabled',false);
               	 $('#siparisverbutton').html('Siparişi Tamamla');

    swal({
  title: "Uyarı",
  text: "Belirlediğiniz varış saati geçmiş zaman olamaz.",
  icon: "warning",
  button: "OK",
});

               } else if(sonuc=='mekankapanacak'){

               	 $('#siparisverbutton').prop('disabled',false);
               	 $('#siparisverbutton').html('Siparişi Tamamla');


               	swal({
  title: "Restoran kapanmış olacak",
  text: "Belirlediğiniz vakitte restoran kapanmış olacak.",
  icon: "info",
  button: "OK",
});


               } else {

               	var url = window.location.href;    
if (url.indexOf('?') > -1){
   url += '&order=success'
}else{
   url += '?order=success'
}
window.location.href = url;


               }


            	

  
               

               

            }
        })
}











			})

		</script>
			
		