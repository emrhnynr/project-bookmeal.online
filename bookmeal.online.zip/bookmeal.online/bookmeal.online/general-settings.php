<?php require_once 'header.php'; 

if ($kullanicioturumcek['kullanici_yetki']!=5) {

	header("Location:/");
	exit;
}


$restoransec=$db->prepare("SELECT * from restoranlar where restoran_id=:id");
$restoransec->execute(array(
"id" => $kullanicioturumcek['restoran_id']
));

$restorancek=$restoransec->fetch(PDO::FETCH_ASSOC);


?>

<title>Genel Ayarlar</title>
		<!-- start Main Wrapper -->
		<div class="main-wrapper scrollspy-container">
		
			




			<div class="container pt-10 pb-30">
			
				

					<div class="breadcrumb-wrapper">
				
					<ol class="breadcrumb">
					
						<li><a href="/">Anasayfa</a></li>
						<li class="active">Genel Ayarlar</li>
						
					</ol>
					
				</div>

			
				
				<div class="row mt-40 mb-30">

					<div class="col-xs-12 col-sm-10 col-sm-offset-1 col-md-10 ">

						

							<div class="submite-list-wrapper">

								<?php if($_GET['update']=="ok"){ ?>

								<div class="alert alert-success alert-icon">
						
							<i class="fa fa-check-circle"></i>
							
							<h4>Güncelleme Başarılı</h4>
						
						</div>
						<?php	} ?>

							<form onsubmit="return false;"  id="generalupdateform">

							

							
							
							
						
							<div class="row">
					
								<div class="col-md-8">
								
									<div class="section-title-02 mb-20">

										<h3><span>Genel Ayarlar</span></h3>
									
										
									
									</div>
								
								</div>
								
							</div>

							
							
							
							<div class="submite-list-box">
							
								<div class="row ga-20">
								
									<div class="col-xs-12 col-sm-12">
									
										<div class="form-group form-group-lg">
										
											<label>Restoran Adı <span class="text-danger">*</span></label>
											<input type="text" value="<?php echo $restorancek['restoran_ad']; ?>" name="restoran_ad" maxlength="80" class="form-control"/>
											
										</div>
									
									</div>

									<div class="col-xs-12 col-sm-12">
									
										<div class="form-group form-group-lg">
										
											<label>Restoran Subdomain (<b style='color:#043D75;'>xxxxx</b>.bookmeal.online) <span class="text-danger">*</span></label>
											<input type="text" value="<?php echo $restorancek['restoran_seo']; ?>" name="restoran_subdomain" placeholder="ex.myrestaurant" maxlength="100" class="form-control"/>
											
										</div>
									
									</div>

									

									<div class="col-xs-12 col-sm-12">
									
										<div class="form-group form-group-lg">
										
											<label>Para Birimi <span class="text-danger">*</span></label>
											<select class="form-control" name="restoran_currency">
												
												<option <?php if ($restorancek['restoran_currency']=="₺") { ?>
													selected=""
												<?php } ?> value="₺">TRY (₺)</option>
												<option <?php if ($restorancek['restoran_currency']=="$") { ?>
													selected=""
												<?php } ?> value="$">USD ($)</option>
												<option <?php if ($restorancek['restoran_currency']=="₹") { ?>
													selected=""
												<?php } ?> value="₹">INR (₹)</option>
												<option <?php if ($restorancek['restoran_currency']=="€") { ?>
													selected=""
												<?php } ?> value="€">EUR (€)</option>
												<option  <?php if ($restorancek['restoran_currency']=="£") { ?>
													selected=""
												<?php } ?> value="£">GBP (£)</option>
											</select>
											
										</div>
									
									</div>

									


									


									
									
									
									
									
								</div>

								

							
								
								
								
								
								
								
							</div>
							
							

							

							<div class="submite-list-box">

								

							

							


								
								
								
							</div>
							
							
							
							

							
							
							<div class="mt-30">
					

								<div style="display: none;" class="alert alert-danger uyarikutu" ></div>

								<input type="hidden" name="generalupdate" >

								<input type="hidden" name="restoran_id" value="<?php echo $restorancek['restoran_id']; ?>">
								
								<button type="submit" id="generalupdatebutton" class="btn btn-primary mt-15">GÜNCELLE</button><br>

								
							</div>

							</form>
							
						</div>
							
						
						
						
						
					</div>

				</div>

			</div>
			
		</div>
		
	<?php require_once 'footer.php'; ?>
	<script type="text/javascript" src="js/bootstrap3-wysihtml5.min.js"></script>
<script type="text/javascript" src="js/bootstrap-tokenfield.js"></script>
<script type="text/javascript" src="js/typeahead.bundle.min.js"></script>
<script type="text/javascript" src="js/jquery-ui.min.js"></script>
<script type="text/javascript" src="js/dropzone.min.js"></script>
<script type="text/javascript" src="js/jquery.ui.timepicker.js"></script>
<script type="text/javascript" src="js/infobox.js"></script>
<script type="text/javascript" src="js/richmarker-compiled.js"></script>
<script type="text/javascript" src="js/customs-submit.js"></script>
<script type="text/javascript">
	
$('#generalupdateform').submit(function(){


$('#generalupdatebutton').prop('disabled', true);

var restoran_ad=$.trim($('[name ="restoran_ad"]').val());
var restoran_subdomain=$.trim($('[name ="restoran_subdomain"]').val());
var restoran_currency=$('[name="restoran_currency"]').val();

if (restoran_ad.length<3) {

 $('#generalupdatebutton').prop('disabled', false);
event.preventDefault();
$('.uyarikutu').show();
$('.uyarikutu').html('<i class="fas fa-info-circle"></i> Restoran ismi minimum 3 karakter içermeli.');

} else if (restoran_subdomain.length<2) {

 $('#generalupdatebutton').prop('disabled', false);
event.preventDefault();
$('.uyarikutu').show();
$('.uyarikutu').html('<i class="fas fa-info-circle"></i> Restoran subdomain minimum 2 karakter içermeli');

} else {


$('#generalupdatebutton').html("<img style='width:18px;height:18px;' src='css/images/flex-loader.gif'>");

$.ajax({
            type : 'POST',
            url : 'ajax.php',
            data : $('#generalupdateform').serialize(),
            success : function(sonuc){

            	  sonuc=$.trim(sonuc);

        if (sonuc=='mevcutsubdomain') {

$('#generalupdatebutton').prop('disabled', false);
$('#generalupdatebutton').html("GÜNCELLE");
event.preventDefault();
$('.uyarikutu').show();
$('.uyarikutu').html('<i class="fas fa-info-circle"></i> Bu subdomain zaten mevcut.');

            	 } else if(sonuc=="hata"){

 $('#generalupdatebutton').prop('disabled', false);
 $('#generalupdatebutton').html("GÜNCELLE");
event.preventDefault();
$('.uyarikutu').show();
$('.uyarikutu').html('<i class="fas fa-info-circle"></i> Bir şeyler ters gitti.');

            	 } else if (sonuc=="ok") {
                     
                
                    $('.uyarikutu').hide();
                    window.location = 'general-settings?update=ok';
            	 	
            	 }

            	   }

            	})

}


})

</script>