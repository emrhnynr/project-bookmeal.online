


<?php require_once 'header.php'; ?>

        <!-- page content -->
        <div class="right_col" role="main">

        	<div class="row tile_count">
            <a href="aktifrestoranlar">
            <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
              <span class="count_top"><i class="fa fa-user"></i> Aktif Restoran</span>

<?php $restoransec=$db->prepare("SELECT * from restoranlar where restoran_mailonay=:mailonay");
$restoransec->execute(array(

"mailonay" => "yes"
));

$restoransay=$restoransec->rowCount();
 ?>

              <div class="count green"><?php echo $restoransay; ?></div>
            </div>
            </a>
           <a href="aktifkullanicilar">
            <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
              <span class="count_top"><i class="fa fa-user"></i> Aktif Kullanıcı</span>
              <?php $kullanicisec=$db->prepare("SELECT * from kullanici where kullanici_mailonay=:mailonay and kullanici_yetki=:yetki");
              $kullanicisec->execute(array(

"mailonay" => "yes",
"yetki" => 1
              ));


$kullanicisay=$kullanicisec->rowCount();
               ?>
              <div class="count green"><?php echo $kullanicisay; ?></div>
              
            </div>

          </a>

            <a href="maildogrulamamiskullanicilar">
             <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
              <span class="count_top"><i class="fa fa-user"></i> Mail Doğrulamamış Kul.</span>
              <?php $kullanicisec=$db->prepare("SELECT * from kullanici where kullanici_mailonay=:mailonay and kullanici_yetki=:yetki");
              $kullanicisec->execute(array(

"mailonay" => "no",
"yetki" => 1
              ));


$kullanicisay=$kullanicisec->rowCount();
               ?>
              <div class="count green"><?php echo $kullanicisay; ?></div>
              
            </div>
          </a>

            <a href="maildogrulamamisrestoranlar">
             <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
              <span class="count_top"><i class="fa fa-user"></i> Mail Doğrulamamış Res.</span>
              <?php $kullanicisec=$db->prepare("SELECT * from kullanici where kullanici_mailonay=:mailonay and kullanici_yetki=:yetki");
              $kullanicisec->execute(array(

"mailonay" => "no",
"yetki" => 5
              ));


$kullanicisay=$kullanicisec->rowCount();
               ?>
              <div class="count green"><?php echo $kullanicisay; ?></div>
              
            </div>

            </a>
            
          </div>
          <div class="">
            

            <br />




            
          </div>
        </div>
        <!-- /page content -->
<?php require_once 'footer.php'; ?>