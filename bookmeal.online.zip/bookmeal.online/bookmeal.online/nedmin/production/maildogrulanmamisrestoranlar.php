<?php require_once 'header.php'; ?>

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Mail Doğrulanmamış Restoranlar</h3>
              </div>

              
            </div>

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12">
                <div class="x_panel">
                  <div class="x_content">
                    <div class="row">
                     

                      <div class="clearfix"></div>

<?php $restoransec=$db->prepare("SELECT * from restoranlar where restoran_mailonay=:mailonay");
$restoransec->execute(array(
"mailonay" => "no"
));

while ($restorancek=$restoransec->fetch(PDO::FETCH_ASSOC)) { 

$restoran_id=$restorancek['restoran_id'];
$restoran_ad=$restorancek['restoran_ad'];
$restoran_logo=$restorancek['restoran_logo'];

 ?>
  
<div class="col-md-4 col-sm-4 col-xs-12 profile_details">
                        <div class="well profile_view">
                          <div class="col-sm-12">
                            
                            <div class="left col-xs-7">
                              <h2><a href="../../r-<?php echo $restorancek['restoran_seo']; ?>"><?php echo $restoran_ad; ?></a></h2>
                              
                              <ul class="list-unstyled">
                                
                                
                              </ul>
                            </div>
                            <div class="right col-xs-5 text-center">
                              <img style='width: 100px;height: 100px;' src="../../<?php echo $restoran_logo; ?>" alt="" class="img-circle img-responsive">
                            </div>
                          </div>
                          <div class="col-xs-12 bottom text-center">
                            
                            <div class="col-xs-12 col-sm-12 emphasis">
                              
                              <a href="restoran-duzenle?restoran_id=<?php echo $restoran_id; ?>"><button type="button" class="btn btn-primary btn-xs">
                                <i class="fa fa-eye"> </i> View
                              </button></a>
                              
                            </div>
                          </div>
                        </div>
                      </div>

<?php } ?>
 
                      

                      
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

       <?php require_once 'footer.php'; ?>
       <script type="text/javascript">
         

$('.silbuton').click(function(){

  var id1=$(this).attr("id");
  var id=id1.substring(3);

  swal({
  title: "Emin Misin?",
  text: "Silmek istiyor musun?",
  icon: "warning",
  buttons: ["Vazgeç", "Sil"],
  dangerMode: true,
})
.then((willDelete) => {
  if (willDelete) {
    window.location = '../../adminislem?restoranreddet=ok&restoran_id='+id;
  } 
});

})


$('.onaylabuton').click(function(){

  var id1=$(this).attr("id");
  var id=id1.substring(3);

  swal({
  title: "Emin Misin?",
  text: "Onaylamak istiyor musun?",
  icon: "success",
  buttons: ["Vazgeç", "Onayla"],
  dangerMode: true,
})
.then((willDelete) => {
  if (willDelete) {
    window.location = '../../adminislem?restoranonayla=ok&restoran_id='+id;
  } 
});

})

       </script>