<?php require_once 'header.php'; ?>
        <div class="right_col" role="main">
          <div class="">
            
            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                 
                  <div class="x_content">
                    
                    

                   

                     <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                  
                    
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">

                    <!-- start accordion -->
                    <div class="accordion" id="accordion1" role="tablist" aria-multiselectable="true">
                      <div class="panel">
                        <a class="panel-heading" role="tab" id="headingOne1" data-toggle="collapse" data-parent="#accordion1" href="#collapseOne1" aria-expanded="true" aria-controls="collapseOne">
                          <h4 class="panel-title"><b>Genel Özellikler</b></h4>
                        </a>
                        <div id="collapseOne1" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne">
                          <div class="panel-body">
                            
                            <form class="form-horizontal form-label-left" action="../../adminislem" method="POST" enctype="multipart/form-data">

                     
                      

                      <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Restoran Ad <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input id="name" class="form-control col-md-7 col-xs-12"  name="restoran_ad" required="required" type="text">
                        </div>
                      </div>

                      <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Restoran SEO <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input id="name" class="form-control col-md-7 col-xs-12"  name="restoran_seo" required="required" type="text">
                        </div>
                      </div>

                      <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Restoran Adres <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input id="name" class="form-control col-md-7 col-xs-12"  name="restoran_adres" required="required" type="text">
                        </div>
                      </div>

                      <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Restoran Kapak Foto <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input id="name" class="form-control col-md-7 col-xs-12"  name="restoran_kapakfoto" required="required" type="file">
                        </div>
                      </div>

                        <div class="x_content">

                  <div class="">
                    <ul class="to_do">
                      <li>
                        <p>
                          <input type="checkbox" class="checkbox" id="filter_cuisine-1" value="0" name="icmekan" class="flat"> İç Mekan </p>
                      </li>
                      <li>
                        <p>
                          <input type="checkbox" class="checkbox" value="0" id="filter_cuisine-2" name="dismekan" class="flat"> Dış Mekan</p>
                      </li>
                      <li>
                        <p>
                          <input type="checkbox" class="checkbox" value="0" id="filter_cuisine-3" name="wifi" class="flat"> Wifi</p>
                      </li>
                      <li>
                        <p>
                          <input type="checkbox" class="checkbox" value="0" id="filter_cuisine-4" name="sigaraicmealan" class="flat"> Sigara İçme Alanı</p>
                      </li>
                      <li>
                        <p>
                          <input type="checkbox" class="checkbox" value="0" id="filter_cuisine-5" name="vale" class="flat"> Vale</p>
                      </li>
                  
                    </ul>
                  </div>
                </div> 


                     
                   
                    
                      
                     
                          </div>
                        </div>
                      </div>

                      

                      <div class="panel">
                        <a class="panel-heading collapsed" role="tab" id="headingTwo1" data-toggle="collapse" data-parent="#accordion1" href="#collapseTwo1" aria-expanded="false" aria-controls="collapseTwo">
                          <h4 class="panel-title"><b>Menü</b></h4>
                        </a>
                        <div id="collapseTwo1" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
                          <div class="panel-body">





                  <?php $x=0; 

                  while ($x<40) {
                    
                    $x++; ?>

                    <input type="text" class="form-control"  placeholder="ad" name="yemek_ad<?php echo $x; ?>">
                  <input type="text" class="form-control" placeholder="fiyat" name="yemek_fiyat<?php echo $x; ?>">
                  <input type="text" class="form-control" placeholder="açıklama" name="yemek_aciklama<?php echo $x; ?>">
                  <select name="yemek_cesit<?php echo $x; ?>" class="form-control">
                   <?php $menucesitsec=$db->prepare("SELECT * from menucesit");
                   $menucesitsec->execute();

                   while ($menucesitcek=$menucesitsec->fetch(PDO::FETCH_ASSOC)) { ?>
                      <option value="<?php echo $menucesitcek['cesit_id']; ?>"><?php echo $menucesitcek['cesit_ad']; ?></option>
                 <?php   } ?>
                  </select>

                  <br>

                  <?php } ?>
                  
                  
                 

              

              

                         

                         </div>
                        </div>
                      </div>

                     
                      <div class="panel">
                        <a class="panel-heading collapsed" role="tab" id="headingThree1" data-toggle="collapse" data-parent="#accordion1" href="#collapseThree1" aria-expanded="false" aria-controls="collapseThree">
                          <h4 class="panel-title"><b>Çalışma Saatleri</b></h4>
                        </a>
                        <div id="collapseThree1" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">
                          <div class="panel-body">
                            
                            
                            <div class="row">
                              <div class="col-md-6">
                                <input type="time" class="form-control" placeholder="Pazartesi Açılış Saati" name="restoran_pazartesiacilis">
                              </div>

                              <div class="col-md-6">
                                <input type="time" class="form-control" placeholder="Pazartesi Kapanış Saati" name="restoran_pazartesikapanis">
                              </div>

                              <br><br>

                              <div class="col-md-6">
                                <input type="time" class="form-control" placeholder="Salı Açılış Saati" name="restoran_saliacilis">
                              </div>

                              <div class="col-md-6">
                                <input type="time" class="form-control" placeholder="Salı Kapanış Saati" name="restoran_salikapanis">
                              </div>

                               <br><br>

                              <div class="col-md-6">
                                <input type="time" class="form-control" placeholder="Çarşamba Açılış Saati" name="restoran_carsambaacilis">
                              </div>

                              <div class="col-md-6">
                                <input type="time" class="form-control" placeholder="Çarşamba Kapanış Saati" name="restoran_carsambakapanis">
                              </div>

                               <br><br>

                              <div class="col-md-6">
                                <input type="time" class="form-control" placeholder="Perşembe Açılış Saati" name="restoran_persembeacilis">
                              </div>

                              <div class="col-md-6">
                                <input type="time" class="form-control" placeholder="Perşembe Kapanış Saati" name="restoran_persembekapanis">
                              </div>

                               <br><br>

                              <div class="col-md-6">
                                <input type="time" class="form-control" placeholder="Cuma Açılış Saati" name="restoran_cumaacilis">
                              </div>

                              <div class="col-md-6">
                                <input type="time" class="form-control" placeholder="Cuma Kapanış Saati" name="restoran_cumakapanis">
                              </div>

                               <br><br>

                              <div class="col-md-6">
                                <input type="time" class="form-control" placeholder="Cumartesi Açılış Saati" name="restoran_cumartesiacilis">
                              </div>

                              <div class="col-md-6">
                                <input type="time" class="form-control" placeholder="Cumartesi Kapanış Saati" name="restoran_cumartesikapanis">
                              </div>

                               <br><br>

                              <div class="col-md-6">
                                <input type="time" class="form-control" placeholder="Pazar Açılış Saati" name="restoran_pazaracilis">
                              </div>

                              <div class="col-md-6">
                                <input type="time" class="form-control" placeholder="Pazar Kapanış Saati" name="restoran_pazarkapanis">
                              </div>
                            </div>

                          </div>
                        </div>


                      </div>


                      <div class="panel">
                        

                        <a class="panel-heading collapsed" role="tab" id="headingFour1" data-toggle="collapse" data-parent="#accordion1" href="#collapseFour1" aria-expanded="false" aria-controls="collapseFour">
                          <h4 class="panel-title"><b>Restoran Admin Bilgileri</b></h4>
                        </a>
                        <div id="collapseFour1" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingFour">
                          <div class="panel-body">
                            
                           
                      <div class="row">
                        <div class="col-md-6"><input class="form-control" type="text" name="kullanici_gsm" placeholder="Admin GSM"></div>
                        <di class='col-md-6'><input class="form-control" type="password" placeholder="Admin Şifre" name="kullanici_sifre"></div>
                      </div>

                          </div>
                        </div>

                      </div>


                      
                      </div>
                    </div>

                    <hr>

                     <button id="send" type="submit" name="restoranekle" class="btn btn-success">Ekle</button>

                      </form>
                    <!-- end of accordion -->


                  </div>
                </div>
              </div>

                  
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->
<?php require_once 'footer.php'; ?>
<script type="text/javascript">
      $('#filter_cuisine-1').change(function(){

        if ($('#filter_cuisine-1').prop('checked')) {

          $('#filter_cuisine-1').val('1');
        } else {

          $('#filter_cuisine-1').val('0');
        };

      });

      $('#filter_cuisine-2').change(function(){

        if ($('#filter_cuisine-2').prop('checked')) {

          $('#filter_cuisine-2').val('1');
        } else {

          $('#filter_cuisine-2').val('0');
        };

      });

      $('#filter_cuisine-3').change(function(){

        if ($('#filter_cuisine-3').prop('checked')) {

          $('#filter_cuisine-3').val('1');
        } else {

          $('#filter_cuisine-3').val('0');
        };

      });

      $('#filter_cuisine-4').change(function(){

        if ($('#filter_cuisine-4').prop('checked')) {

          $('#filter_cuisine-4').val('1');
        } else {

          $('#filter_cuisine-4').val('0');
        };

      });

      $('#filter_cuisine-5').change(function(){

        if ($('#filter_cuisine-5').prop('checked')) {

          $('#filter_cuisine-5').val('1');
        } else {

          $('#filter_cuisine-5').val('0');
        };

      });
    </script>