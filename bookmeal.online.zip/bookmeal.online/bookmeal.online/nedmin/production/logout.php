<?php session_start();

if (isset($_SESSION['admin_oturum'])) {
	
	unset($_SESSION['admin_oturum']);
Header("Location:login.php");

} else {

	Header("Location:login.php");
}


 ?>