<?php
require_once 'baglann.php'; ?>

<div class="modal-header">
	<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
	<h4 class="modal-title text-center">Ücretsiz hesap oluştur</h4>
</div>

<div class="modal-body">
						
	<div class="row gap-20">

		
	
		
		
		

		<form onsubmit="return false;" id="kayitform">
		
		
		
		<div style='margin-top:10px;' class="col-xs-12 col-sm-12 col-md-12">

			<div class="form-group"> 
				<label>E-Posta Adresi</label>
				<input class="form-control" id="email" maxlength="100"  name="kullanici_mail" placeholder="E-Posta adresinizi girin" type="email"> 
			</div>
		
		</div>
		
		<div class="col-xs-12 col-sm-12 col-md-12">
		
			<div class="form-group"> 
				<label>Şifre</label>
				<input class="form-control" maxlength="40"  id="sifre" name="kullanici_sifre" placeholder="Minimum 8 karakter" type="password"> 
			</div>
		
		</div>
		
		<div class="col-xs-12 col-sm-12 col-md-12">
		
			<div class="form-group"> 
				<label>Şifre Tekrar</label>
				<input class="form-control" maxlength="40" id="sifretekrar" name="kullanici_sifretekrar" placeholder="Şifrenizi tekrar girin" type="password"> 
			</div>
		
		</div>

		<input type="hidden" name="uyekayit">
		
		
		
		<div style='margin-bottom:10px;' class="col-xs-12 col-sm-12 col-md-12">
			<div class="login-box-box-action">
				Zaten hesabınız var mı ? <a data-toggle="modal" href="#loginModal">Giriş Yap</a>
			</div>
		</div>


		
	</div>

	<div class="alert alert-danger uyarikutu" style="display: none;"></div>

</div>

<div class="modal-footer text-center">
	<button class="btn btn-primary kayitbuton">ÜYE OL</button>
	<button type="button" data-dismiss="modal" class="btn btn-dark">KAPAT</button>
</div>

</form>

<script type="text/javascript">
	


	$('.kayitbuton').click(function(){

		$('.kayitbuton').prop('disabled', true);
		$('.kayitbuton').html("<img style='width:18px;height:18px;' src='css/images/flex-loader.gif'>");

		$.ajax({
            type : 'POST',
            url : 'ajax.php',
            data : $('#kayitform').serialize(),
            success : function(sonuc){

            	if ($.trim(sonuc)=="yanlismail") {
                     $('.kayitbuton').prop('disabled', false);
                     $('.kayitbuton').html('KAYIT OL');
            		$('.uyarikutu').show();
            		$('.uyarikutu').html('Lütfen eposta adresinizi kontrol edin.');

            	} else if($.trim(sonuc)=="mevcutmail"){

                     $('.kayitbuton').prop('disabled', false);
                     $('.kayitbuton').html('KAYIT OL');
                     $('.uyarikutu').show();
            		$('.uyarikutu').html('Bu eposta adresi sistemimizde mevcut.');

            	} else if($.trim(sonuc)=="eksiksifre"){

$('.kayitbuton').prop('disabled', false);
$('.kayitbuton').html('KAYIT OL');
                     $('.uyarikutu').show();
            		$('.uyarikutu').html("Şifreniz 8 karakterden kısa olamaz.");

            	} else if($.trim(sonuc)=="sifreleruyusmuyor"){

$('.kayitbuton').prop('disabled', false);
$('.kayitbuton').html('KAYIT OL');
            		 $('.uyarikutu').show();
            		$('.uyarikutu').html("Şifreler uyuşmuyor. Lütfen kontrol edin.");


            	} else if($.trim(sonuc)=="hata"){

$('.kayitbuton').prop('disabled', false);
$('.kayitbuton').html('KAYIT OL');
            		 $('.uyarikutu').show();
            		$('.uyarikutu').html('Bir şeyler ters gitti.');


            	} else if($.trim(sonuc)=="ok"){

                    
            		 $('.uyarikutu').hide();
            		window.location.reload();


            	}
               
            }
        })

	})


	
</script>

