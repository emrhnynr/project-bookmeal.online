<?php require_once 'header.php';

$kullanici_uniq=$_GET['u'];
$kullanici_id=$_GET['id'];

$kullanicisec=$db->prepare("SELECT * from kullanici where kullanici_id=:id and kullanici_uniq=:uniq");
$kullanicisec->execute(array(
"uniq" => $kullanici_uniq,
"id" => $kullanici_id
));

$kullanicisay=$kullanicisec->rowCount();

if ($kullanicisay==0 or isset($_COOKIE['kullanicioturum'])) {
	
	header("Location:/");
	exit;
}

$kullanicicek=$kullanicisec->fetch(PDO::FETCH_ASSOC);

 ?>
<title>Şifre Yenileme</title>
		<!-- start Main Wrapper -->
		<div class="main-wrapper scrollspy-container">
		
			<!-- start hero-header -->
			

			<div class="container pt-10 pb-30">
			
				
				
				<div style="min-height: 365px;" class="row mt-40 mb-30">

					<div class="col-xs-12 col-sm-10 col-sm-offset-1 col-md-8 col-md-offset-2">
						
						<div class="submite-list-wrapper">
						
							<div class="row">
					
								<div class="col-md-8">
								
									<div class="section-title-02 mb-20">

										<h3><span>Şifre Yenile</span></h3>
									
										
									
									</div>
								
								</div>
								
							</div>
							
							<div class="submite-list-box">
							
								<div class="row">

									<form onsubmit="return false;" id="resetpasswordform">
								
									<div class="col-xs-12 col-sm-12 mb-30-xs">
									
										<div class="row gap-20">
										
											<div class="col-xs-12 col-sm-12">
											
												<div class="form-group">
													<label>E-Posta Adresiniz*</label>
													<input type="text" disabled="" value="<?php echo $kullanicicek['kullanici_mail']; ?>" class="form-control mevcut_sifre" />
												</div>
												
											</div>
											
											<div class="col-xs-12 col-sm-6">
											
												<div class="form-group">
													<label>Yeni Şifreniz*</label>
													<input type="password" maxlength="40" name="yeni_sifre" placeholder="Minimum 8 karakter" class="form-control yeni_sifre" />
												</div>
												
											</div>
											
											<div class="col-xs-12 col-sm-6">
											
												<div class="form-group">
													<label>Yeni Şifre Tekrar*</label>
													<input type="password" name="yeni_sifre_tekrar" placeholder="Yeni şifrenizi tekrar girin" maxlength="40" class="form-control yeni_sifre_tekrar" />
												</div>
												
											</div>

											<input type="hidden"  name="sifreyenile">
											<input type="hidden" value="<?php echo $kullanicicek['kullanici_id']; ?>" name="kullanici_id">

											<div class="col-xs-12 col-sm-12">
											
												
												<button id="resetpasswordbutton" class="btn btn-primary mt-15">YENİLE</button>
											
											</div>

											</form>
											
											
											
											
										</div>

									</div>
									
									
									
								</div>

							</div>

						</div>
						
					</div>

				</div>

			</div>
			
		</div>
		
		<?php require_once 'footer.php'; ?>
	    <script type="text/javascript">
	    	$('#resetpasswordbutton').click(function(){

$('#resetpasswordbutton').prop('disabled', true);
$('#resetpasswordbutton').html('<img style="width:18px;height:18px;" src="css/images/flex-loader.gif">');


$.ajax({
            type : 'POST',
            url : 'ajax.php',
            data : $('#resetpasswordform').serialize(),
            success : function(sonuc){

            	sonuc=$.trim(sonuc);

            	 if(sonuc=="kisasifre"){

$('#resetpasswordbutton').prop('disabled', false);
$('#resetpasswordbutton').html('YENİLE');
 swal({
  title: "Kısa Şifre",
  text: "Şifreniz minimum 8 karakter içermelidir.",
  icon: "warning",
  button: "OK",
});
            	} else if(sonuc=="uyusmayansifre"){


$('#resetpasswordbutton').prop('disabled', false);
$('#resetpasswordbutton').html('YENİLE');
swal({
  title: "Yeni şifreler uyuşmuyor.",
  text: "Girdiğiniz yeni şifreler uyuşmuyor.",
  icon: "warning",
  button: "OK",
});
            	}  else if(sonuc=="ok"){





swal({
  title: "Şifreniz Değiştirildi!",
  icon: "success",
  button: "OK",
});

window.location='/';





            	}

            	
               
            }
        })
	    		
	    	})
	    </script>