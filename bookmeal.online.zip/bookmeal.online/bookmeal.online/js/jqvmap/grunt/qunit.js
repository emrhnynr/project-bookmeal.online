module.exports = {
  dist: ['tests/*.html']
};
