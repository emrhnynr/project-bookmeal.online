<?php require_once 'baglann.php';

require_once 'fonksiyon.php';

 $ip_adresi=$_SERVER['REMOTE_ADDR'];
$query=@unserialize(file_get_contents('http://ip-api.com/php/'.$ip_adresi));

if($query && $query['status']=='success'){
    
     $timezone=$query['timezone'];
      date_default_timezone_set($timezone);
      
      
} else {
    
    date_default_timezone_set('America/Los_Angeles');
}



$tamsuan=date('Y-m-d H:i:s');


$kullanicisec=$db->prepare("SELECT * from kullanici where kullanici_yetki='5' and uyelik_turu!='expired' and uyelik_turu!='NULL' and uyelik_bitis<'$tamsuan'");
$kullanicisec->execute();

while ($kullanicicek=$kullanicisec->fetch(PDO::FETCH_ASSOC)) {
  
$kullanici_id=$kullanicicek['kullanici_id'];

$hazirla=$db->prepare("UPDATE kullanici set

uyelik_turu=:uyelik_turu

where kullanici_id='$kullanici_id'

  ");

$derle=$hazirla->execute(array(

"uyelik_turu" => 'expired'
));

}





















 ?>