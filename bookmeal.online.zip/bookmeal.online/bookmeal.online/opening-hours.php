<?php require_once 'header.php'; 

if ($uyelik_turu!=2 and $uyelik_turu!=4) {
	
	header("Location:/");
};

$restoransec=$db->prepare("SELECT * from restoranlar where restoran_id=:id");
$restoransec->execute(array(
"id" => $kullanicioturumcek['restoran_id']
));

$restorancek=$restoransec->fetch(PDO::FETCH_ASSOC);

?>
<title>Vardiya Saatleri</title>
		
		<!-- start Main Wrapper -->
		<div class="main-wrapper scrollspy-container">
		
			<!-- start hero-header -->
			

			<div class="container pt-10 pb-30">
			
				
				
				<div class="row mt-40 mb-30">

					<div class="col-xs-12 col-sm-10 col-sm-offset-1 col-md-10 ">

						
						
						<div class="submite-list-wrapper">
						
							
							
							<div class="submite-list-box">
							
								

								
								
								
								
								
								
								
								<h6 class="text-primary text-uppercase mt-15">Vardiya Saatleri<small style="font-size: 13px;"> (Doldurmadığınız gün restoranınız kapalı varsayarız.)</small></h6>

								<div class="opening-hours-wrapper">

									<?php if ($_GET['update']=="ok") { ?>
										
										<div class="alert alert-success alert-icon">
						
							<i class="fa fa-check-circle"></i>
							
							<h4>Güncelleme Başarılı</h4>
						
						</div>
									<?php } ?>
								
									<div class="opening-hours-box">
									
										<div class="row gap-20">

											<form onsubmit="return false;" id="openinghoursform">
										
											<div class="col-xs-12 col-sm-6 col-md-6">
											
												<label class="day-name">Pazartesi</label>
												
												<div class="row gap-10">
												
													<div class=" col-xs-6 col-sm-6 col-md-6">
													
														<div class="input-group from mb-15">
															<span class="input-group-addon">-dan</span>
															<input class="oh-timepicker form-control" value="<?php echo $restorancek['restoran_pazartesiacilis']; ?>" type="time" name="restoran_pazartesiacilis">
														</div>
														
													</div>
													
													<div class=" col-xs-6 col-sm-6 col-md-6">
													
														<div class="input-group to mb-15">
															<span class="input-group-addon">-e</span>
															<input class="oh-timepicker form-control" type="time" value="<?php echo $restorancek['restoran_pazartesikapanis']; ?>" name="restoran_pazartesikapanis">
														</div>
														
													</div>
													
												</div>
												
											</div>
											
											<div class="col-xs-12 col-sm-6 col-md-6">
											
												<label class="day-name">Salı</label>
												
												<div class="row gap-10">
												
													<div class=" col-xs-6 col-sm-6 col-md-6">
													
														<div class="input-group from mb-15">
															<span class="input-group-addon">-dan</span>
															<input class="oh-timepicker form-control" type="time" value="<?php echo $restorancek['restoran_saliacilis']; ?>" name="restoran_saliacilis">
														</div>
														
													</div>
													
													<div class=" col-xs-6 col-sm-6 col-md-6">
													
														<div class="input-group to mb-15">
															<span class="input-group-addon">-e</span>
															<input class="oh-timepicker form-control" type="time" value="<?php echo $restorancek['restoran_salikapanis']; ?>" name="restoran_salikapanis">
														</div>
														
													</div>
													
												</div>
												
											</div>
											
											<div class="col-xs-12 col-sm-6 col-md-6">
											
												<label class="day-name">Çarşamba</label>
												
												<div class="row gap-10">
												
													<div class=" col-xs-6 col-sm-6 col-md-6">
													
														<div class="input-group from mb-15">
															<span class="input-group-addon">-dan</span>
															<input class="oh-timepicker form-control" type="time" value="<?php echo $restorancek['restoran_carsambaacilis']; ?>" name="restoran_carsambaacilis">
														</div>
														
													</div>
													
													<div class=" col-xs-6 col-sm-6 col-md-6">
													
														<div class="input-group to mb-15">
															<span class="input-group-addon">-e</span>
															<input class="oh-timepicker form-control" type="time" value="<?php echo $restorancek['restoran_carsambakapanis']; ?>" name="restoran_carsambakapanis">
														</div>
														
													</div>
													
												</div>
												
											</div>
											
											<div class="col-xs-12 col-sm-6 col-md-6">
											
												<label class="day-name">Perşembe</label>
												
												<div class="row gap-10">
												
													<div class=" col-xs-6 col-sm-6 col-md-6">
													
														<div class="input-group from mb-15">
															<span class="input-group-addon">-dan</span>
															<input class="oh-timepicker form-control" type="time" value="<?php echo $restorancek['restoran_persembeacilis']; ?>" name="restoran_persembeacilis">
														</div>
														
													</div>
													
													<div class=" col-xs-6 col-sm-6 col-md-6">
													
														<div class="input-group to mb-15">
															<span class="input-group-addon">-e</span>
															<input class="oh-timepicker form-control" type="time" value="<?php echo $restorancek['restoran_persembekapanis']; ?>" name="restoran_persembekapanis">
														</div>
														
													</div>
													
												</div>
												
											</div>
											
											<div class="col-xs-12 col-sm-6 col-md-6">
											
												<label class="day-name">Cuma</label>
												
												<div class="row gap-10">
												
													<div class=" col-xs-6 col-sm-6 col-md-6">
													
														<div class="input-group from mb-15">
															<span class="input-group-addon">-dan</span>
															<input class="oh-timepicker form-control" value="<?php echo $restorancek['restoran_cumaacilis']; ?>" type="time" name="restoran_cumaacilis">
														</div>
														
													</div>
													
													<div class=" col-xs-6 col-sm-6 col-md-6">
													
														<div class="input-group to mb-15">
															<span class="input-group-addon">-e</span>
															<input class="oh-timepicker form-control" value="<?php echo $restorancek['restoran_cumakapanis']; ?>" type="time" name="restoran_cumakapanis">
														</div>
														
													</div>
													
												</div>
												
											</div>
											
											<div class="col-xs-12 col-sm-6 col-md-6">
											
												<label class="day-name">Cumartesi</label>
												
												<div class="row gap-10">
												
													<div class=" col-xs-6 col-sm-6 col-md-6">
													
														<div class="input-group from mb-15">
															<span class="input-group-addon">-dan</span>
															<input class="oh-timepicker form-control" type="time" value="<?php echo $restorancek['restoran_cumartesiacilis']; ?>" name="restoran_cumartesiacilis">
														</div>
														
													</div>
													
													<div class=" col-xs-6 col-sm-6 col-md-6">
													
														<div class="input-group to mb-15">
															<span class="input-group-addon">-e</span>
															<input class="oh-timepicker form-control" type="time" value="<?php echo $restorancek['restoran_cumartesikapanis']; ?>" name="restoran_cumartesikapanis">
														</div>
														
													</div>
													
												</div>
												
											</div>
											
											<div class="col-xs-12 col-sm-6 col-md-6">
											
												<label class="day-name">Pazar</label>
												
												<div class="row gap-10">
												
													<div class=" col-xs-6 col-sm-6 col-md-6">
													
														<div class="input-group from mb-15">
															<span class="input-group-addon">-dan</span>
															<input class="oh-timepicker form-control" type="time" value="<?php echo $restorancek['restoran_pazaracilis']; ?>" name="restoran_pazaracilis">
														</div>
														
													</div>
													
													<div class=" col-xs-6 col-sm-6 col-md-6">
													
														<div class="input-group to mb-15">
															<span class="input-group-addon">-e</span>
															<input class="oh-timepicker form-control" type="time" value="<?php echo $restorancek['restoran_pazarkapanis']; ?>" name="restoran_pazarkapanis">
														</div>
														
													</div>
													
												</div>
												
											</div>

										</div>
									
									</div>

								</div>

								<input type="hidden" name="openinghoursupdate">

								<input type="hidden" value="<?php echo $restorancek['restoran_id']; ?>" name="restoran_id">

								
								
							</div>
							
							
							
							<div class="mt-30">
					
								
								
								<button id="openinghoursbutton" class="btn btn-primary mt-15">GÜNCELLE</button>
								
							</div>
							
						</div>

						</form>
						
					</div>

				</div>

			</div>
			
		</div>
		
	<?php require_once 'footer.php'; ?>
	<script type="text/javascript" src="js/jquery-ui.min.js"></script>
	<script type="text/javascript" src="js/jquery.ui.timepicker.js"></script>
	<script type="text/javascript">
		
		$('#openinghoursbutton').click(function(){



			$('#openinghoursbutton').prop('disabled',true);
			$('#openinghoursbutton').html("<img style='width:18px;height:18px;' src='css/images/flex-loader.gif'>");

			$.ajax({
            type : 'POST',
            url : 'ajax.php',
            data : $('#openinghoursform').serialize(),
            success : function(sonuc){

sonuc=$.trim(sonuc);

             if (sonuc=="hata") {

          $('#openinghoursbutton').prop('disabled',false);
          $('#openinghoursbutton').html("GÜNCELLE");

          swal({

  title: "Hata",
  text: "Bir şeyler ters gitti.",
  icon: "error",
  button: "OK",
});


             } else if(sonuc=="ok"){

             	 window.location = 'opening-hours?update=ok';
             }
            	
               

            }
        })
		})

	</script>