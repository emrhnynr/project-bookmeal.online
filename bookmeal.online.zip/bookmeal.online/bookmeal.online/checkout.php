
<?php 

 require_once 'baglann.php'; 

$kullanici_id=$_COOKIE['kullanici_id'];
$kullanicisec=$db->prepare("SELECT * from kullanici where kullanici_id=:id");
$kullanicisec->execute(array(
"id" => $kullanici_id
));
$kullanicicek=$kullanicisec->fetch(PDO::FETCH_ASSOC);
$uyelik_turu=$_GET['membership'];
$ip_adresi=$_SERVER['REMOTE_ADDR'];

if ($uyelik_turu!='1' and $uyelik_turu!='2' and $uyelik_turu!='3' and $uyelik_turu!='4' or $kullanicicek['uyelik_turu']!='expired') {
  
  header("Location:/");
}

 ?>

 

<head>

  <?php if ($ip_adresi!='::1') { ?>
    
  

  <script type="text/javascript" >
   (function(m,e,t,r,i,k,a){m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)};
   m[i].l=1*new Date();k=e.createElement(t),a=e.getElementsByTagName(t)[0],k.async=1,k.src=r,a.parentNode.insertBefore(k,a)})
   (window, document, "script", "https://mc.yandex.ru/metrika/tag.js", "ym");

   ym(68934574, "init", {
        clickmap:true,
        trackLinks:true,
        accurateTrackBounce:true,
        webvisor:true
   });
</script>
<noscript><div><img src="https://mc.yandex.ru/watch/68934574" style="position:absolute; left:-9999px;" alt="" /></div></noscript>

<?php } ?>

  <link rel="shortcut icon" href="images/logo-xs.png">

<title>Ödeme - BookMeal</title>

  <style type="text/css">
    @import url(https://fonts.googleapis.com/css?family=Lato:400,300,700);
body,html {
  height:100%;
  margin:0;
  font-family:lato;
}

h2 {
  margin-bottom:0px;
  margin-top:25px;
  text-align:center;
  font-weight:200;
  font-size:19px;
  font-size:1.2rem;
  
}
.container {
  height:100%;
  -webkit-box-pack:center;
  -webkit-justify-content:center;
      -ms-flex-pack:center;
          justify-content:center;
  -webkit-box-align:center;
  -webkit-align-items:center;
      -ms-flex-align:center;
          align-items:center;
  display:-webkit-box;
  display:-webkit-flex;
  display:-ms-flexbox;
  display:flex;
  background:rgba(4, 61, 117,0.2);
}
.dropdown-select.visible {
  display:block;
}
.dropdown {
  position:relative;
}
ul {
  margin:0;
  padding:0;
}
ul li {
  list-style:none;
  padding-left:10px;
  cursor:pointer;
}
ul li:hover {
  background:rgba(255,255,255,0.1);
}
.dropdown-select {
  position:absolute;
  background:#77aaee;
  text-align:left;
  box-shadow:0px 3px 5px 0px rgba(0,0,0,0.1);
  border-bottom-right-radius:5px;
  border-bottom-left-radius:5px;
  width:90%;
  left:2px;
  line-height:2em;
  margin-top:2px;
  box-sizing:border-box;
}
.thin {
  font-weight:400;
}
.small {
  font-size:12px;
  font-size:.8rem;
}
.half-input-table {
  border-collapse:collapse;
  width:100%;
}
.half-input-table td:first-of-type {
  border-right:10px solid #4488dd;
  width:50%;
}
.window {
  height:540px;
  width:800px;
  background:#fff;
  display:-webkit-box;
  display:-webkit-flex;
  display:-ms-flexbox;
  display:flex;
  box-shadow: 0px 15px 50px 10px rgba(0, 0, 0, 0.2);
  border-radius:30px;
  z-index:10;
}
.order-info {
  height:100%;
  width:50%;
  padding-left:25px;
  padding-right:25px;
  box-sizing:border-box;
  display:-webkit-box;
  display:-webkit-flex;
  display:-ms-flexbox;
  display:flex;
  -webkit-box-pack:center;
  -webkit-justify-content:center;
      -ms-flex-pack:center;
          justify-content:center;
  position:relative;
}
.price {
  bottom:0px;
  position:absolute;
  right:0px;
  color:#4488dd;
}
.order-table td:first-of-type {
  width:25%;
}
.order-table {
    position:relative;
}
.line {
  height:1px;
  width:100%;
  margin-top:10px;
  margin-bottom:10px;
  background:#ddd;
}
.order-table td:last-of-type {
  vertical-align:top;
  padding-left:25px;
}
.order-info-content {
  table-layout:fixed;

}

.full-width {
  width:100%;
}
.pay-btn {
  border:none;
  background:#22b877;
  line-height:2em;
  border-radius:10px;
  font-size:19px;
  font-size:1.2rem;
  color:#fff;
  cursor:pointer;
  position:absolute;
  bottom:25px;
  width:calc(100% - 50px);
  -webkit-transition:all .2s ease;
          transition:all .2s ease;
}
.pay-btn:hover {
  background:#22a877;
    color:#eee;
  -webkit-transition:all .2s ease;
          transition:all .2s ease;
}

.total {
  margin-top:25px;
  font-size:20px;
  font-size:1.3rem;
  position:absolute;
  bottom:30px;
  right:27px;
  left:35px;
}
.dense {
  line-height:1.2em;
  font-size:16px;
  font-size:1rem;
}
.input-field {
  background:rgba(255,255,255,0.1);
  margin-bottom:10px;
  margin-top:3px;
  line-height:1.5em;
  font-size:20px;
  font-size:1.3rem;
  border:none;
  padding:5px 10px 5px 10px;
  color:#fff;
  box-sizing:border-box;
  width:100%;
  margin-left:auto;
  margin-right:auto;
}
.credit-info {
  background:#4488dd;
  height:100%;
  width:50%;
  color:#eee;
  -webkit-box-pack:center;
  -webkit-justify-content:center;
      -ms-flex-pack:center;
          justify-content:center;
  font-size:14px;
  font-size:.9rem;
  display:-webkit-box;
  display:-webkit-flex;
  display:-ms-flexbox;
  display:flex;
  box-sizing:border-box;
  padding-left:25px;
  padding-right:25px;
  border-top-right-radius:30px;
  border-bottom-right-radius:30px;
  position:relative;
}
.dropdown-btn {
  background:rgba(255,255,255,0.1);
  width:100%;
  border-radius:5px;
  text-align:center;
  line-height:1.5em;
  cursor:pointer;
  position:relative;
  -webkit-transition:background .2s ease;
          transition:background .2s ease;
}
.dropdown-btn:after {
  content: '\25BE';
  right:8px;
  position:absolute;
}
.dropdown-btn:hover {
  background:rgba(255,255,255,0.2);
  -webkit-transition:background .2s ease;
          transition:background .2s ease;
}
.dropdown-select {
  display:none;
}
.credit-card-image {
  display:block;
  max-height:80px;
  margin-left:auto;
  margin-right:auto;
  margin-top:35px;
  margin-bottom:15px;
}
.credit-info-content {
  margin-top:25px;
  -webkit-flex-flow:column;
      -ms-flex-flow:column;
          flex-flow:column;
  display:-webkit-box;
  display:-webkit-flex;
  display:-ms-flexbox;
  display:flex;
  width:100%;
}
@media (max-width: 600px) {
  .window {
    width: 100%;
    height: 100%;
    display:block;
    border-radius:0px;
  }
  .order-info {
    width:100%;
    height:auto;
    padding-bottom:100px;
    border-radius:0px;
  }
  .credit-info {
    width:100%;
    height:auto;
    padding-bottom:100px;
    border-radius:0px;
  }
  .pay-btn {
    border-radius:0px;
  }
}
  </style>
</head>

<body>



<div class='container'>
  <div class='window'>
    <div class='order-info'>
      <div align="center" class='order-info-content'>
        <a href='/'><img style="margin-top:40px;" src="images/logo.png"></a>
        <h2>Üyelik Modeli</h2>
                
       
        
       
        <div class='line'></div>
        <table class='order-table'>
          <tbody>
            <tr>
              
              <td>
                <br> <span style="text-align: center;" class='thin'><?php switch ($uyelik_turu) {
                  case '1':
                    echo "QR Menü";
                    break;
                  
                  case '2':
                    echo "Ön Sipariş Sistemi";
                    break;

                    case '3':
                    echo "QR Menü Sipariş Sistemi";
                    break;

                    case '4':
                    echo "QR Menü Sipariş + Ön Sipariş Sistemi";
                    break;
                } ?> (1 Yıllık)</span>
                
              </td>

            </tr>
            
          </tbody>
        </table>
       
        <div class='total'>
          <span style='float:left;'>
            
            TOPLAM
          </span>
          <span style='float:right; text-align:right;'>
            
           <?php switch ($uyelik_turu) {
             case '1':
               echo "168 TL <br><span style='font-size: 15px;color: #043D75;'>(14 x 12)</span>";
               break;

                case '2':
               echo "1.188 TL <br><span style='font-size: 15px;color: #043D75;'>(99 x 12)</span>";
               break;

                case '3':
               echo "2388 TL <br><span style='font-size: 15px;color: #043D75;'>(199 x 12)</span>";
               break;

                case '4':
               echo "2868 TL <br><span style='font-size: 15px;color: #043D75;'>(239 x 12)</span>";
               break;
             
             
           } ?>
          </span>
        </div>
</div>
</div>

        <div class='credit-info'>
          <div class='credit-info-content'>

            <form id="checkoutform">
            
           
            Kart Numarası
            <input name='pan' maxlength="22" class='input-field'></input>
            Kart Sahibi
            <input maxlength="100" name="cardOwner" class='input-field'></input>
            <table class='half-input-table'>
              <tr>
                <td style="color:white;"> Son Kullanım Ayı
                  <select name="expiryMonth" class="input-field">
                    <option value="0" selected=""></option>
                    <option style='color: black;'>01</option>
                    <option style='color: black;'>02</option>
                    <option style='color: black;'>03</option>
                    <option style='color: black;'>04</option>
                    <option style='color: black;'>05</option>
                    <option style='color: black;'>06</option>
                    <option style='color: black;'>07</option>
                    <option style='color: black;'>08</option>
                    <option style='color: black;'>09</option>
                    <option style='color: black;'>10</option>
                    <option style='color: black;'>11</option>
                    <option style='color: black;'>12</option>
                  </select>
                </td>
                <td style="color:white;"> Son Kullanım Yılı
                  <select name="expiryYear" class="input-field">
                    <option value="0" selected=""></option>
                    <option style='color: black;'>2020</option>
                    <option style='color: black;'>2021</option>
                    <option style='color: black;'>2022</option>
                    <option style='color: black;'>2023</option>
                    <option style='color: black;'>2024</option>
                    <option style='color: black;'>2025</option>
                    <option style='color: black;'>2026</option>
                    <option style='color: black;'>2027</option>
                    <option style='color: black;'>2028</option>
                    <option style='color: black;'>2029</option>
                    <option style='color: black;'>2030</option>
                    <option style='color: black;'>2031</option>
                    <option style='color: black;'>2032</option>
                  </select>
                </td>
                </tr>

                <tr>
                
                </tr>
                <tr>
                <td style="color:white;">CVC
                  <input name="cvv" maxlength="3" class='input-field'></input>
                </td>
              </tr>

              <input type="hidden" name="odemeyap">
              <input type="hidden" value="<?php echo $uyelik_turu; ?>" name="uyelik_turu">
              <input type="hidden" value="<?php echo $_COOKIE['kullanicioturum']; ?>" name="kullanici_mail">
              <input type="hidden" value="<?php switch ($uyelik_turu) {
             case '1':
               echo "168";
               break;

                case '2':
               echo "1188";
               break;

                case '3':
               echo "2388";
               break;

                case '4':
               echo "2868";
               break;
             
             
           } ?>" name="amount">
            </table>

            <button class='pay-btn'>ÖDE</button>

            <a href="pricing">Fiyatlandırmaya Dön</a>

            </form>


          </div>


        </div>
      </div>
</div>


<script type="text/javascript" src="js/jquery-2.2.4.min.js"></script>
<script type="text/javascript" src="js/jquery-migrate-1.4.1.min.js"></script>
<script type="text/javascript" src="js/sweetalert.min.js"></script>

<script type="text/javascript">
  $('#checkoutform').submit(function(){

    
    var pan=$.trim($('[name="pan"]').val());
    var cardOwner=$.trim($('[name="cardOwner"]').val());
    var expiryMonth=$('[name="expiryMonth"]').val();
    var expiryYear=$('[name="expiryYear"]').val();
    var cvv=$.trim($('[name="cvv"]').val());


$('.pay-btn').prop('disabled',true);
$('.pay-btn').html("<img style='width:30px;height:30px;' src='images/ajax-loader.gif'>");
event.preventDefault();

if (pan.length<16) {

swal({
  title: "Uyarı",
  text: "Kredi kartı numarası 16 haneden az olamaz.",
  icon: "info",
  button: "OK", 
});
$('.pay-btn').prop('disabled',false);
$('.pay-btn').html("ÖDE");

} else if(cardOwner.length<1){

swal({
  title: "Uyarı",
  text: "Lütfen kart sahibini girin.",
  icon: "info",
  button: "OK", 
});
$('.pay-btn').prop('disabled',false);
$('.pay-btn').html("ÖDE");

} else if(expiryMonth=="0"){

swal({
  title: "Uyarı",
  text: "Lütfen kartınızın son kullanım ayını girin.",
  icon: "info",
  button: "OK", 
});
$('.pay-btn').prop('disabled',false);
$('.pay-btn').html("ÖDE");

} else if(expiryYear=='0'){

swal({
  title: "Uyarı",
  text: "Lütfen kartınızın son kullanım yılını girin.",
  icon: "info",
  button: "OK", 
});
$('.pay-btn').prop('disabled',false);
$('.pay-btn').html("ÖDE");

} else if (cvv.length!=3) {

swal({
  title: "Uyarı",
  text: "CVC 3 karakterden oluşmalıdır.",
  icon: "info",
  button: "OK", 
});
$('.pay-btn').prop('disabled',false);
$('.pay-btn').html("ÖDE");

} else {


$.ajax({
            type : 'POST',
            url : 'ajax.php',
            data : $('#checkoutform').serialize(),
            success : function(sonuc){
                
                sonuc=$.trim(sonuc);
              
              if (sonuc=='basarili') {

swal({
  title: "Ödeme Başarılı",
  icon: "success",
});

window.location='membership';

              } else {
               
$('.pay-btn').prop('disabled',false);
$('.pay-btn').html("ÖDE");
swal({
  title: "Uyarı",
  text: "Lütfen kredi kartı bilgilerinizi kontrol edip tekrar deneyin.",
  icon: "warning",
  button: "OK",
})
              }

               }

             });


}

  })
</script>


<!--  TMX Profiling --->

<script type="text/javascript"
src='https://h.online-metrix.net/fp/tags.js?org_id=6bmm5c3v&amp&session_id={SESSIONTOKEN}&pageid=1'>
</script>

<noscript>
  <iframe style='width: 100px;height: 100px;border:0;position: absolute;top:-5000px;' src="https://h.online-metrix.net/fp/tags.js?org_id=6bmm5c3v&amp&session_id=B7F76IDEPLPQPXT3HLKLL2DOR2LVT564F4YJBLKIUOQPVGOC&pageid=1"></iframe>
</noscript>

</body>