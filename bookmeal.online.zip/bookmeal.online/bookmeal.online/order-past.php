
<?php require_once 'header.php'; 

if ($kullanicioturumcek['kullanici_yetki']!=1) {
	
	header("Location:/");
	exit;
};





$sayfa=@$_GET['p'];
    if (empty($_GET['p'])) {
      $sayfa=1;
    };
    $siparistestsec=$db->prepare("SELECT * from onsiparisler where kullanici_id=:id and siparis_bildirim=:bildirim and siparis_turu=:turu");
    $siparistestsec->execute(array(
      "id" => $_COOKIE['kullanici_id'],
      "bildirim" => 0,
      "turu" => 1
    ));
    $kacar=20;
    $siparistestsay=$siparistestsec->rowCount();
    $sayfasayisi=ceil($siparistestsay/$kacar);
    $baslangic=($kacar*$sayfa)-$kacar;

	

?>

<title>Geçmiş Siparişler</title>


		
		<!-- start Main Wrapper -->
		<div  class="main-wrapper scrollspy-container">
		
			

			
			<!-- end hero-header -->

			<div  class="container pt-10 pb-30">
			
				
				
				<div class="row mb-10">
				
					<div class="col-md-8">
					
						<div style="margin-top: 30px;" class="section-title-02">

							

							<h3><span>GEÇMİŞ SİPARİŞLER</span></h3>
					
						</div>
					
					</div>
					
				</div>

				
	
				<div class="row">
				
					
					
					<div style="min-height: 260px;" class="col-sm-12 col-md-12 col-xs-12">
						
						

						<div class="restaurant-list-item-wrapper no-last-bb">
							
     <?php $siparissec=$db->prepare("SELECT * from onsiparisler where kullanici_id=:id and siparis_turu=:turu and siparis_bildirim=:bildirim order by siparis_zaman DESC limit $baslangic,$kacar");

     $siparissec->execute(array(
"id" => $_COOKIE['kullanici_id'],
"turu" => 1,
"bildirim" => 0
     ));

$siparissay=$siparissec->rowCount();

if ($siparistestsay==0) { ?>
	
<h4 align="center">Sipariş kaydı bulunamadı.</h4>

<?php } else { ?>

<?php while($sipariscek=$siparissec->fetch(PDO::FETCH_ASSOC)){ 

$restoransec=$db->prepare("SELECT * from restoranlar where restoran_id=:id");
								$restoransec->execute(array(

									"id" => $sipariscek['restoran_id']
								));

								$restorancek=$restoransec->fetch(PDO::FETCH_ASSOC);

								$restoran_currency=$restorancek['restoran_currency'];
								 ?>

								

								<div class="restaurant-list-item clearfix">
							
								<div class="GridLex-grid-noGutter-equalHeight">
								
									
									
									<div class="GridLex-col-12_sm-12_xss-12">
									
										<div class="GridLex-grid-noGutter-equalHeight">
										
											<div class="GridLex-col-9_sm-12 content-wrapper">
											
												<div class="content">

													<p style="font-weight: bold; color: #043D75;">Sipariş No: #<?php echo $sipariscek['siparis_id']; ?></p>

													<h5><a  href="preorder?sef=<?php echo $restorancek['restoran_seo']; ?>"><?php echo $restorancek['restoran_ad']; ?> <i class="fas fa-angle-right"></i></a></h5>
													
													

													<p style="font-weight: bold;"><i class="fas fa-calendar"></i> Sipariş Tarihi: <?php switch (substr($sipariscek['siparis_zaman'],5,2)) {

														case '01':
															echo substr($sipariscek['siparis_zaman'],8,2)." Ocak ".substr($sipariscek['siparis_zaman'],0,4);
															break;

														case '02':
															echo substr($sipariscek['siparis_zaman'],8,2)." Şubat ".substr($sipariscek['siparis_zaman'],0,4);
															break;

															case '03':
															echo substr($sipariscek['siparis_zaman'],8,2)." Mart ".substr($sipariscek['siparis_zaman'],0,4);
															break;

															case '04':
															echo substr($sipariscek['siparis_zaman'],8,2)." Nisan ".substr($sipariscek['siparis_zaman'],0,4);
															break;

															case '05':
															echo substr($sipariscek['siparis_zaman'],8,2)." Mayıs ".substr($sipariscek['siparis_zaman'],0,4);
															break;

															case '06':
															echo substr($sipariscek['siparis_zaman'],8,2)." Haziran ".substr($sipariscek['siparis_zaman'],0,4);
															break;

															case '07':
															echo substr($sipariscek['siparis_zaman'],8,2)." Temmuz ".substr($sipariscek['siparis_zaman'],0,4);
															break;

															case '08':
															echo substr($sipariscek['siparis_zaman'],8,2)." Ağustos ".substr($sipariscek['siparis_zaman'],0,4);
															break;

															case '09':
															echo substr($sipariscek['siparis_zaman'],8,2)." Eylül ".substr($sipariscek['siparis_zaman'],0,4);
															break;

															case '10':
															echo substr($sipariscek['siparis_zaman'],8,2)." Ekim ".substr($sipariscek['siparis_zaman'],0,4);
															break;

															case '11':
															echo substr($sipariscek['siparis_zaman'],8,2)." Kasım ".substr($sipariscek['siparis_zaman'],0,4);
															break;


															case '12':
															echo substr($sipariscek['siparis_zaman'],8,2)." Aralık ".substr($sipariscek['siparis_zaman'],0,4);
															break;
														
													} ?></p>

													<?php if (!empty($sipariscek['siparis_ozeltalep'])) { ?>

 														<p style="font-weight: bold;"><i class="fas fa-edit"></i> <?php echo $sipariscek['siparis_ozeltalep']; ?></p>

													<?php } ?>

													
													
													<p class="cuisine"><b>Siparişim:</b> <?php $siparisyemeksec=$db->prepare("SELECT * from onsiparisyemek where siparis_id=:id and siparisyemek_turu=:turu");
													$siparisyemeksec->execute(array(

														"id" => $sipariscek['siparis_id'],
														"turu" => 1

													));  while ($siparisyemekcek=$siparisyemeksec->fetch(PDO::FETCH_ASSOC)) { 

														$yemeksec=$db->prepare("SELECT * from yemekler where yemek_id=:id");
														$yemeksec->execute(array(

															"id" => $siparisyemekcek['yemek_id']
														));

														$yemekcek=$yemeksec->fetch(PDO::FETCH_ASSOC); ?>
															<span><?php echo $yemekcek['yemek_ad']."<b> x ".$siparisyemekcek['yemek_adet']."</b>"; ?></span>
														<?php } ?> </p>
												</div>
											
											</div>
											
											<div class="GridLex-col-3_sm-12 meta-wrapper">
											
												<div class="meta">
													
													<div class="right-bottom">
														<div class="price">Sipariş Tutarı: <span><?php echo $restoran_currency."".$sipariscek['siparis_tutar']; ?></span></div>
														<div class="clear"></div>
														
													</div>
												</div>
											
											</div>
										
										</div>
										
									</div>
									
								</div>
							
							</div>
 
							<?php } ?>

<?php }  ?>


 

      

						</div>

						<?php if ($siparistestsay>20) { ?>

							<div  class="pagination-wrapper">
						
							<div  class="GridLex-grid-middle GridLex-grid-noGutter">
								
								<div class="GridLex-col-12_sm-12_xs-12">
									<nav>
										<ul class="pagination pagination-text-center-sm mb-5-xs">
											<?php $p=0; if ($sayfa!=1) { ?>
												<li>
												<a href="order-past?s=<?php echo $sayfa-1; ?>" aria-label="Previous">
													<span aria-hidden="true">&laquo;</span>
												</a>
											</li>
											<?php } ?>
											
											<?php while ($p<$sayfasayisi) { $p++; ?>
												
												<li <?php if ($p==$sayfa) { ?>
													class="active"
												<?php } ?>><a href="order-past?p=<?php echo $p; ?>"><?php echo $p; ?></a></li>

											<?php } ?>

											<?php if ($sayfa!=$sayfasayisi) { ?>

												<li>
												<a href="order-past?p=<?php echo $sayfa+1; ?>" aria-label="Next">
													<span aria-hidden="true">&raquo;</span>
												</a>
											</li>
												
											<?php } ?>
											
											
										</ul>
									</nav>

								</div>
							</div>

						</div>
							
						<?php } ?>

						

						
						
					</div>


				</div>
				
			</div>

		
			
		</div>
		<!-- end Main Wrapper -->

		<?php require_once 'footer.php';?>
			
			