<?php 	require_once 'baglann.php';
require_once 'fonksiyon.php'; 
require_once 'phpqrcode/qrlib.php';
include('SimpleImage.php');
$ip_adresi=$_SERVER['REMOTE_ADDR'];
date_default_timezone_set('Europe/Istanbul');
/*$query=@unserialize(file_get_contents('http://ip-api.com/php/'.$ip_adresi));

 
if($query && $query['status']=='success'){
    
     $timezone=$query['timezone'];
      date_default_timezone_set($timezone);
      
      
} else {
    
    date_default_timezone_set('America/Los_Angeles');
} */?>




<?php if (empty($_POST)) {

	header("Location:/");
	
}  else if(isset($_POST['uyekayit'])){

$kullanici_mail=$_POST['kullanici_mail'];
$kullanici_sifre=$_POST['kullanici_sifre'];
$kullanici_sifretekrar=$_POST['kullanici_sifretekrar'];

$mailsor=$db->prepare("SELECT * from kullanici where kullanici_mail=:mail");
$mailsor->execute(array(
"mail" => trim($kullanici_mail)
));

$mailsay=$mailsor->rowCount();


if (mb_strlen(trim($kullanici_mail))<6) {
	
	echo "yanlismail";


} else if ($mailsay!=0){

	echo "mevcutmail";

} else if(mb_strlen($kullanici_sifre)<8){

	echo "eksiksifre";

} else if($kullanici_sifre!=$kullanici_sifretekrar){

echo "sifreleruyusmuyor";

} else {

	  $rand = strtoupper(substr(md5(microtime()),rand(0,26),5)); 

	$hazirla=$db->prepare("INSERT into kullanici set

kullanici_mail=:kullanici_mail,
kullanici_sifre=:kullanici_sifre,
kullanici_yetki=:kullanici_yetki,
kullanici_aktivasyonkod=:kullanici_aktivasyonkod,
kullanici_adminonay=:kullanici_adminonay,
kullanici_asama=:kullanici_asama
		");

	$derle=$hazirla->execute(array(

"kullanici_mail" => htmlspecialchars(trim($kullanici_mail)),
"kullanici_sifre" => md5(htmlspecialchars($kullanici_sifre)),
"kullanici_yetki" => 1,
"kullanici_aktivasyonkod" => $rand,
"kullanici_adminonay" => "yes",
"kullanici_asama" => 2
	));


	if ($derle) {

//Maile aktivasyon kodu gönderme

		require("phpmailer/class/class.phpmailer.php");

	$mail = new PHPMailer(); // Sinifimizi $mail degiskenine atadik
 $mail->CharSet  ="utf-8";
 $mail->Encoding="base64";
$mail->IsSMTP();  // Mailimizin SMTP ile gönderilecegini belirtiyoruz
$mail->Host     = "smtpout.secureserver.net";//"localhost"; //SMTP server adresi
$mail->Port     = '80'; 
$mail->SMTPAuth = true; //SMTP server'a kullanici adi ile baglanilcagini belirtiyoruz.
$mail->Username = "help@bookmeal.online";//"admin@localhost"; //SMTP kullanici adi
$mail->Password = "386Emirhan.";//""; //SMTP mailinizin sifresi
$mail->SMTPSecure = 'SSL';
$mail->From     = 'help@bookmeal.online';//"admin@localhost"; //Gönderen kisminda yer alacak e-mail adresi
$mail->FromName = 'Bookmeal';//"PHP Mailer";//gönderenin ismi
$mail->AddAddress($kullanici_mail); // Mail gönderilecek adresleri ekliyoruz.
$mail->IsHTML(true); //Mailimizin HTML formatinda hazirlanacagini bildiriyoruz.
$mail->Subject  = 'Aktivasyon Kodu';//"Deneme Maili"; // Mailin Konusu Konu


	$mail->Body = '<div align="center" style="width:100%;height:100px;">
	<h3 style="underline:1px" align="center">Aktivasyon Kodu</h3><h4 align="center" style="">'.$rand.'<h4></div>';
	
 



 


 

if ($mail->Send()) {
	
	setcookie('kullanicioturum',trim($kullanici_mail),time()+31556926);
	echo "ok";
};


	//--------------------

		
		
		
	} else {

		echo "hata";
	}
}

} else if(isset($_POST['uyelogin'])){


 $kullanici_mail=$_POST['kullanici_mail'];
 $kullanici_sifre=$_POST['kullanici_sifre'];

$loginsor=$db->prepare("SELECT * from kullanici where  kullanici_mail=:mail and kullanici_sifre=:sifre");
 	$loginsor->execute(array(


"mail" => trim($kullanici_mail),
"sifre" => md5($kullanici_sifre)


 	));

 	$loginsay=$loginsor->rowCount();


 	if ($loginsay==1) {

 		$logincek=$loginsor->fetch(PDO::FETCH_ASSOC);
 		$kullanici_yetki=$logincek['kullanici_yetki'];
 		setcookie('kullanicioturum',$kullanici_mail,time()+31556926);

 		if ($kullanici_yetki==1) {

 			

 		echo "kullaniciok";

 		} else if($kullanici_yetki==5){

 			
 		echo "adminok";
 		};
 		

 	} else {

 		echo "bilgileryanlis";
 	}

} else if(isset($_POST['gecmissipariscek'])){ ?>






							<?php

							$ay=$_POST['ay_post'];
							$yil=$_POST['yil'];

							$restoran_id=$_POST['restoran_id'];

							if ($ay=='buay') {

								 $kayitlisiparissec=$db->prepare("SELECT * from siparisler where restoran_id=:id and siparis_turu=:turu and siparis_bildirim=:bildirim and MONTH(siparis_zaman) = MONTH(CURDATE()) and YEAR(siparis_zaman) = $yil order by siparis_zaman ASC");
							$kayitlisiparissec->execute(array(
"turu" => 5,
"id" => $restoran_id,
"bildirim" => 0
							));

							$kayitlisiparissay=$kayitlisiparissec->rowCount();

							} else if($ay=='gecenay'){

 $kayitlisiparissec=$db->prepare("SELECT * from siparisler where restoran_id=:id and siparis_turu=:turu and siparis_bildirim=:bildirim and MONTH(siparis_zaman) = MONTH(CURDATE()-INTERVAL 1 MONTH) and YEAR(siparis_zaman) = $yil order by siparis_zaman ASC");
							$kayitlisiparissec->execute(array(
"turu" => 5,
"id" => $restoran_id,
"bildirim" => 0
							));



							}


							

							$kayitlisiparissay=$kayitlisiparissec->rowCount();

							if ($kayitlisiparissay==0) { ?>

								<h4 align="center">Sipariş kaydı bulunamadı.</h4>
								

						<?php	}  
					 



							 while($kayitlisipariscek=$kayitlisiparissec->fetch(PDO::FETCH_ASSOC)){  ?>

								

								<div class="restaurant-list-item clearfix">
							
								<div class="GridLex-grid-noGutter-equalHeight">
								
									
									
									<div class="GridLex-col-12_sm-12_xss-12">
									
										<div class="GridLex-grid-noGutter-equalHeight">
										
											<div class="GridLex-col-9_sm-12 content-wrapper">
											
												<div class="content">

													<p style="font-weight: bold; color: #043D75;">Sipariş No: #<?php echo $kayitlisipariscek['siparis_no']; ?></p>
													
													<p style="font-weight: bold;" class="location"><i class="fa fa-user"></i> <?php echo $kayitlisipariscek['siparis_kisisayisi']." Kişi"; ?> </p>

													<p style="font-weight: bold;"><i class="fas fa-calendar"></i> Sipariş Tarihi: <?php switch (substr($kayitlisipariscek['siparis_zaman'],5,2)) {

														case '01':
															echo substr($kayitlisipariscek['siparis_zaman'],8,2)." Ocak ".substr($kayitlisipariscek['siparis_zaman'],0,4);
															break;

														case '02':
															echo substr($kayitlisipariscek['siparis_zaman'],8,2)." Şubat ".substr($kayitlisipariscek['siparis_zaman'],0,4);
															break;

															case '03':
															echo substr($kayitlisipariscek['siparis_zaman'],8,2)." Mart ".substr($kayitlisipariscek['siparis_zaman'],0,4);
															break;

															case '04':
															echo substr($kayitlisipariscek['siparis_zaman'],8,2)." Nisan ".substr($kayitlisipariscek['siparis_zaman'],0,4);
															break;

															case '05':
															echo substr($kayitlisipariscek['siparis_zaman'],8,2)." Mayıs ".substr($kayitlisipariscek['siparis_zaman'],0,4);
															break;

															case '06':
															echo substr($kayitlisipariscek['siparis_zaman'],8,2)." Haziran ".substr($kayitlisipariscek['siparis_zaman'],0,4);
															break;

															case '07':
															echo substr($kayitlisipariscek['siparis_zaman'],8,2)." Temmuz ".substr($kayitlisipariscek['siparis_zaman'],0,4);
															break;

															case '08':
															echo substr($kayitlisipariscek['siparis_zaman'],8,2)." Ağustos ".substr($kayitlisipariscek['siparis_zaman'],0,4);
															break;

															case '09':
															echo substr($kayitlisipariscek['siparis_zaman'],8,2)." Eylül ".substr($kayitlisipariscek['siparis_zaman'],0,4);
															break;

															case '10':
															echo substr($kayitlisipariscek['siparis_zaman'],8,2)." Ekim ".substr($kayitlisipariscek['siparis_zaman'],0,4);
															break;

															case '11':
															echo substr($kayitlisipariscek['siparis_zaman'],8,2)." Kasım ".substr($kayitlisipariscek['siparis_zaman'],0,4);
															break;


															case '12':
															echo substr($kayitlisipariscek['siparis_zaman'],8,2)." Aralık ".substr($kayitlisipariscek['siparis_zaman'],0,4);
															break;
														
													} ?></p>

													<?php if (!empty($kayitlisipariscek['ozeltalep'])) { ?>

 														<p style="font-weight: bold;"><i class="fas fa-edit"></i> <?php echo $kayitlisipariscek['siparis_ozeltalep']; ?></p>

													<?php } ?>

													
													
													<p class="cuisine"><b>Sipariş:</b> <?php $siparisyemeksec=$db->prepare("SELECT * from siparisyemek where siparis_id=:id and siparisyemek_turu=:turu");
													$siparisyemeksec->execute(array(

														"id" => $kayitlisipariscek['siparis_id'],
														"turu" => 5

													));  while ($siparisyemekcek=$siparisyemeksec->fetch(PDO::FETCH_ASSOC)) { 

														$yemeksec=$db->prepare("SELECT * from yemekler where yemek_id=:id");
														$yemeksec->execute(array(

															"id" => $siparisyemekcek['yemek_id']
														));

														$yemekcek=$yemeksec->fetch(PDO::FETCH_ASSOC); ?>
															<span><?php echo $yemekcek['yemek_ad']."<b> x ".$siparisyemekcek['yemek_adet']."</b>"; ?></span>
														<?php } ?> </p>
												</div>
											
											</div>
											
											<div class="GridLex-col-3_sm-12 meta-wrapper">
											
												<div class="meta">
													
													<div class="right-bottom">
														<div class="price">Ödenen Tutar: <span>$<?php echo $kayitlisipariscek['siparis_tutar']; ?></span></div>
														<div class="clear"></div>
														
													</div>
												</div>
											
											</div>
										
										</div>
										
									</div>
									
								</div>
							
							</div>
 
							<?php } ?>

							

							

						
							
							
						

<?php }  else if(isset($_POST['search'])){ 



$deger=$_POST['deger']; 


$aramasonucusec=$db->prepare("SELECT * from restoranlar where restoran_ad LIKE '%$deger%' ");
$aramasonucusec->execute();



$aramasonucusay=$aramasonucusec->rowCount();

if ($aramasonucusay>0) { 

$say=0;

while ($aramasonucucek=$aramasonucusec->fetch(PDO::FETCH_ASSOC)) { $say++; ?>

	<h4 align="left"><a href="r-<?php echo $aramasonucucek['restoran_seo']; ?>"><?php echo $aramasonucucek['restoran_ad']; ?> <br><small><i class="fas fa-map-marker-alt"></i> <?php echo $aramasonucucek['restoran_adres']; ?></small></a></h4>

	<?php if ($say!=$aramasonucusay) { ?>
		<hr>
	<?php } ?>
	
<?php } ?>
	

	

<?php } else { ?>

<h4 align="center">Böyle bir restoran mevcut değil.</h4>

<?php } ?>






 

<?php } else if(isset($_POST['siparisver'])){

 $yemekler=$_POST['yemekler'];
 $siparis_tutar=0;
 $siparis_kisisayisi=$_POST['siparis_kisisayisi'];
 $siparis_ozeltalep=htmlspecialchars(trim($_POST['siparis_ozeltalep']));
 $restoran_id=$_POST['restoran_id'];
 $siparis_masano=$_POST['siparis_masano'];

 $restoransec=$db->prepare("SELECT * from restoranlar where restoran_id=:id");
 $restoransec->execute(array(
"id" => $restoran_id
 ));

 $restorancek=$restoransec->fetch(PDO::FETCH_ASSOC);





	foreach ($yemekler as $yemek) {

	if ($_POST['yemekadet_'.$yemek]!=0) {
		
		$yemeksec=$db->prepare("SELECT * from yemekler where yemek_id=:id");
	$yemeksec->execute(array(
"id" => $yemek
	));

	$yemekcek=$yemeksec->fetch(PDO::FETCH_ASSOC);

	$yemekfiyat=$yemekcek['yemek_fiyat']*$_POST['yemekadet_'.$yemek];

	$siparis_tutar+=$yemekfiyat;



	}



};

$hazirla=$db->prepare("INSERT into siparisler set


siparis_ozeltalep=:siparis_ozeltalep,
restoran_id=:restoran_id,
kullanici_ip=:kullanici_ip,
siparis_tutar=:siparis_tutar,
siparis_zaman=:siparis_zaman,
siparis_masano=:siparis_masano,
siparis_turu=:siparis_turu

	");

$derle=$hazirla->execute(array(

"siparis_ozeltalep" => $siparis_ozeltalep,
"restoran_id" => $restoran_id,
"kullanici_ip" => $ip_adresi,
"siparis_tutar" => $siparis_tutar,
"siparis_zaman" => date('Y-m-d H:i:s'),
"siparis_masano" => $siparis_masano,
"siparis_turu" => 1

));

$sonkayit=$db->lastInsertId();

foreach ($yemekler as $yemek) {
	
	if ($_POST['yemekadet_'.$yemek]!=0) {
		
		$hazirla2=$db->prepare("INSERT into siparisyemek set

siparis_id=:siparis_id,
yemek_id=:yemek_id,
yemek_adet=:yemek_adet,
siparisyemek_turu=:siparisyemek_turu
		");


	$derle2=$hazirla2->execute(array(

"siparis_id" => $sonkayit,
"yemek_id" => $yemek,
"yemek_adet" => $_POST['yemekadet_'.$yemek],
"siparisyemek_turu" => 1

	));
	}

}


$hazirla3=$db->prepare("INSERT into siparisler set

kullanici_ip=:kullanici_ip,
siparis_ozeltalep=:siparis_ozeltalep,
siparis_tutar=:siparis_tutar,
restoran_id=:restoran_id,
siparis_turu=:siparis_turu,
siparis_zaman=:siparis_zaman,
siparis_masano=:siparis_masano,
siparis_no=:siparis_no

	");

$derle3=$hazirla3->execute(array(

"kullanici_ip" => $ip_adresi,
"siparis_ozeltalep" => htmlspecialchars(trim($siparis_ozeltalep)),
"siparis_tutar" => $siparis_tutar,
"restoran_id" => $restoran_id,
"siparis_turu" => 5,
"siparis_zaman" => date('Y-m-d H:i:s'),
"siparis_masano" => $siparis_masano,
"siparis_no" => $sonkayit
));


$sonkayit2=$db->lastInsertId();




foreach ($yemekler as $yemek) {
	
	if ($_POST['yemekadet_'.$yemek]!=0) {
		
		$hazirla2=$db->prepare("INSERT into siparisyemek set

siparis_id=:siparis_id,
yemek_id=:yemek_id,
yemek_adet=:yemek_adet,
siparisyemek_turu=:siparisyemek_turu
		");


	$derle2=$hazirla2->execute(array(

"siparis_id" => $sonkayit2,
"yemek_id" => $yemek,
"yemek_adet" => $_POST['yemekadet_'.$yemek],
"siparisyemek_turu" => 5

	));
	}

}





echo "odemesayfasi";





 

} else if (isset($_POST['ownerregister'])){

 $kullanici_mail=htmlspecialchars(trim($_POST['kullanici_mail']));
 $kullanici_sifre=htmlspecialchars($_POST['kullanici_sifre']);

 $mailsor=$db->prepare("SELECT * from kullanici where kullanici_mail=:mail");
   $mailsor->execute(array(
"mail" => $kullanici_mail
   ));


$mailsay=$mailsor->rowCount();

if ($mailsay>0) {
   
   echo "mevcutmail";

   } else {


//Admin i kaydedelim.

		
		
		

        $hazirlaadmin=$db->prepare("INSERT into kullanici set

kullanici_mail=:kullanici_mail,
kullanici_sifre=:kullanici_sifre,
kullanici_yetki=:kullanici_yetki,
kullanici_asama=:kullanici_asama
        	");

        $derleadmin=$hazirlaadmin->execute(array(
"kullanici_mail" => $kullanici_mail,
"kullanici_sifre" => md5($kullanici_sifre),
"kullanici_yetki" => 5,
"kullanici_asama" => 1
        ));

        if ($derleadmin) {
        	

    setcookie('kullanicioturum',trim($kullanici_mail),time()+31556926);
	echo "ok";


        } else {

        	echo "hata";
        }


  

        

 
   	

   }


} else if (isset($_POST['restaurantsubmit'])){


  
	

      
         $restoran_pazartesiacilis=$_POST['restoran_pazartesiacilis'];
$restoran_pazartesikapanis=$_POST['restoran_pazartesikapanis'];
$restoran_saliacilis=$_POST['restoran_saliacilis'];
 $restoran_salikapanis=$_POST['restoran_salikapanis'];
 $restoran_carsambaacilis=$_POST['restoran_carsambaacilis'];
$restoran_carsambakapanis=$_POST['restoran_carsambakapanis'];
 $restoran_persembeacilis=$_POST['restoran_persembeacilis'];
 $restoran_persembekapanis=$_POST['restoran_persembekapanis'];
 $restoran_cumaacilis=$_POST['restoran_cumaacilis'];
 $restoran_cumakapanis=$_POST['restoran_cumakapanis'];
 $restoran_cumartesiacilis=$_POST['restoran_cumartesiacilis'];
 $restoran_cumartesikapanis=$_POST['restoran_cumartesikapanis'];
 $restoran_pazaracilis=$_POST['restoran_pazaracilis'];
  $restoran_pazarkapanis=$_POST['restoran_pazarkapanis'];
        
 $restoran_ad=htmlspecialchars(trim($_POST['restoran_ad']));
 $restoran_masasayisi=$_POST['restoran_masasayisi'];
 $restoran_currency=$_POST['restoran_currency'];
 $restoran_seo=seo(tum_bosluk_sil($_POST['restoran_subdomain']));
 $uzanti2=ext($_FILES['restoran_logo']['name']);
   

$subsor=$db->prepare("SELECT * from restoranlar where restoran_seo=:seo");
   $subsor->execute(array(
"seo" => $restoran_seo
   ));


$subsay=$subsor->rowCount();
 

     if($subsay>0){

   	echo "mevcutsubdomain";

   } else {

   	$rand = strtoupper(substr(md5(microtime()),rand(0,26),5));
 			

 			
   	$depodosya2 = 'dimg/restoranlogo';

 				
                 $tmp_name2 = $_FILES['restoran_logo']["tmp_name"];
 				 
 				 	 $name2= $_FILES['restoran_logo']["name"];


	

    
	$uniq=uniqid(); //Benzersiz sayı oluşturur.
	if (!empty($_FILES['restoran_logo']['name'])) {
		
		$refimgyol2=$depodosya2."/".$uniq.".".$uzanti2;
	}
	 //Klasörü kaydederken aynı zamanda klasörün ismini veritabanına istediğimiz şekilde gönderiyoruz. Daha sonra istediğimiz yerden istediğimiz şekilde sessionlarla veya normal şekilde bu resmi çekebiliriz.

	
	@move_uploaded_file($tmp_name2, "$depodosya2/$uniq.$uzanti2"); //burada dosyayı al, belirttiğimiz klasöre kaydet diyoruz.	 	
    
	

	$hazirla=$db->prepare("INSERT into restoranlar set 

restoran_ad=:restoran_ad,
restoran_seo=:restoran_seo,
restoran_masasayisi=:restoran_masasayisi,
restoran_currency=:restoran_currency,
restoran_logo=:restoran_logo,
restoran_pazartesiacilis=:restoran_pazartesiacilis,
restoran_pazartesikapanis=:restoran_pazartesikapanis,
restoran_saliacilis=:restoran_saliacilis,
restoran_salikapanis=:restoran_salikapanis,
restoran_carsambaacilis=:restoran_carsambaacilis,
restoran_carsambakapanis=:restoran_carsambakapanis,
restoran_persembeacilis=:restoran_persembeacilis,
restoran_persembekapanis=:restoran_persembekapanis,
restoran_cumaacilis=:restoran_cumaacilis,
restoran_cumakapanis=:restoran_pazartesikapanis,
restoran_cumartesiacilis=:restoran_cumartesiacilis,
restoran_cumartesikapanis=:restoran_cumartesikapanis,
restoran_pazaracilis=:restoran_pazaracilis,
restoran_pazarkapanis=:restoran_pazarkapanis
		");

	$derle=$hazirla->execute(array(
"restoran_ad" => $restoran_ad,
"restoran_seo" => $restoran_seo,
"restoran_masasayisi" => $restoran_masasayisi,
"restoran_currency" => $restoran_currency,
"restoran_logo" => $refimgyol2,
"restoran_pazartesiacilis" => $restoran_pazartesiacilis,
"restoran_pazartesikapanis" => $restoran_pazartesikapanis,
"restoran_saliacilis" => $restoran_saliacilis,
"restoran_salikapanis" => $restoran_salikapanis,
"restoran_carsambaacilis" => $restoran_carsambaacilis,
"restoran_carsambakapanis" => $restoran_carsambakapanis,
"restoran_persembeacilis" => $restoran_persembeacilis,
"restoran_persembekapanis" => $restoran_persembekapanis,
"restoran_cumaacilis" => $restoran_cumaacilis,
"restoran_cumakapanis" => $restoran_cumakapanis,
"restoran_cumartesiacilis" => $restoran_cumartesiacilis,
"restoran_cumartesikapanis" => $restoran_cumartesikapanis,
"restoran_pazaracilis" => $restoran_pazaracilis,
"restoran_pazarkapanis" => $restoran_pazarkapanis
	));


	if ($derle) {


$sonkayit=$db->lastInsertId();

$restoranidguncelle=$db->prepare("UPDATE kullanici set

restoran_id=:restoran_id,
kullanici_asama=:kullanici_asama,
kullanici_aktivasyonkod=:kullanici_aktivasyonkod

where kullanici_id = {$_COOKIE['kullanici_id']}
	");

$restoranidguncelle->execute(array(

"restoran_id" => $sonkayit,
"kullanici_asama" => 2,
"kullanici_aktivasyonkod" => $rand

));


 $say=0;

        while ($say<$restoran_masasayisi) {
        	$say++;

        	$path='dimg/qrkodlar';
        	$file=$sonkayit."_masa-".$say.".png";
        	$text="bookmeal.online/r-".$restoran_seo."-".$say;
        	QRcode::png($text,$path."/".$file);





        	$hazirla=$db->prepare("INSERT into qrkodlar set

restoran_id=:restoran_id,
qr_masano=:qr_masano,
qr_url=:qr_url,
qr_foto=:qr_foto
        		");

        	$derle=$hazirla->execute(array(
"restoran_id" => $sonkayit,
"qr_masano" => $say,
"qr_url" => "r-".$restoran_seo."-".$say,
"qr_foto" => $path."/".$file
        	));
        }
        

       


       //---------------

        $kullanicisecmail=$db->prepare("SELECT * from kullanici where kullanici_id=:id");
        $kullanicisecmail->execute(array(

"id" => $_COOKIE['kullanici_id']
        ));

        $kullanicicekmail=$kullanicisecmail->fetch(PDO::FETCH_ASSOC);


        $kullanici_mail=$kullanicicekmail['kullanici_mail'];

        // Maille aktivasyon kodu gönderme

        require("phpmailer/class/class.phpmailer.php");

	$mail = new PHPMailer(); // Sinifimizi $mail degiskenine atadik
 $mail->CharSet  ="utf-8";
 $mail->Encoding="base64";
$mail->IsSMTP();  // Mailimizin SMTP ile gönderilecegini belirtiyoruz
$mail->Host     = "smtpout.secureserver.net";//"localhost"; //SMTP server adresi
$mail->Port     = '80'; 
$mail->SMTPAuth = true; //SMTP server'a kullanici adi ile baglanilcagini belirtiyoruz.
$mail->Username = "help@bookmeal.online";//"admin@localhost"; //SMTP kullanici adi
$mail->Password = "386Emirhan.";//""; //SMTP mailinizin sifresi
$mail->SMTPSecure = 'SSL';
$mail->From     = 'help@bookmeal.online';//"admin@localhost"; //Gönderen kisminda yer alacak e-mail adresi
$mail->FromName = 'Bookmeal';//"PHP Mailer";//gönderenin ismi
$mail->AddAddress($kullanici_mail); // Mail gönderilecek adresleri ekliyoruz.
$mail->AddEmbeddedImage('images\logo.png', 'logo', 'logo.png');
$mail->IsHTML(true); //Mailimizin HTML formatinda hazirlanacagini bildiriyoruz.
$mail->Subject  = 'Aktivasyon Kodu';//"Deneme Maili"; // Mailin Konusu Konu


	$mail->Body = "<div align='center' style='width:100%;height:350px;background-color:#EFEEEA;padding-top:50px;padding-bottom:50px;'>
	
	<div style='width:50%;background-color:#ffffff;height:250px;padding:19px;'>
<a href='https://bookmeal.online'><img src='cid:logo'></a>
	<h1>Sadece siz olduğunuzu kontrol etmek için.</h1><p style='font-size:19px;'>Lütfen kodu kopyalayıp Aktivasyon Kodu kısmına yapıştırın.</p><h2>".$rand."<h2></div>

	<p style='margin-top:30px;color:#707070;'>© 2021 Bookmeal®, Tüm hakları saklıdır.<br>

	Kolektif House - Levent / İstanbul<br></p>
	<span><a href='https://bookmeal.online/contact' style:color:#DB3947;text-decoration:none;>İletişim</a></span>

	</div>";
	



$mail->Send();

echo "ok";

		



	} else {

		echo "hata";
	}

   }

  


		




  


} else if(isset($_POST['sifredegistir'])){

	$kullanicisec=$db->prepare("SELECT * from kullanici where kullanici_id=:id");
	$kullanicisec->execute(array(
"id" => $_COOKIE['kullanici_id']
	));

	$kullanicicek=$kullanicisec->fetch(PDO::FETCH_ASSOC);

	$kullanici_id=$_COOKIE['kullanici_id'];

$mevcut_sifre=$_POST['mevcut_sifre'];
$yeni_sifre=$_POST['yeni_sifre'];
$yeni_sifre_tekrar=$_POST['yeni_sifre_tekrar'];

if ($kullanicicek['kullanici_sifre']!=md5($mevcut_sifre)) {
	
	echo "sifreyanlis";

} else if(strlen($yeni_sifre)<8){

echo "kisasifre";

} else if($yeni_sifre!=$yeni_sifre_tekrar){

	echo "uyusmayansifre";

} else {

	$hazirla=$db->prepare("UPDATE kullanici set

kullanici_sifre=:kullanici_sifre

where kullanici_id='$kullanici_id'
		");

	$derle=$hazirla->execute(array(

"kullanici_sifre" => htmlspecialchars(md5($yeni_sifre))
	));

	if ($derle) {

		echo "ok";

	} else {

echo "hata";
	}

	
}



} else if(isset($_POST['openinghoursupdate'])){

	$restoran_id=$_POST['restoran_id'];

$hazirla=$db->prepare("UPDATE restoranlar set

restoran_pazartesiacilis=:restoran_pazartesiacilis,
restoran_pazartesikapanis=:restoran_pazartesikapanis,
restoran_saliacilis=:restoran_saliacilis,
restoran_salikapanis=:restoran_salikapanis,
restoran_carsambaacilis=:restoran_carsambaacilis,
restoran_carsambakapanis=:restoran_carsambakapanis,
restoran_persembeacilis=:restoran_persembeacilis,
restoran_persembekapanis=:restoran_persembekapanis,
restoran_cumaacilis=:restoran_cumaacilis,
restoran_cumakapanis=:restoran_cumakapanis,
restoran_cumartesiacilis=:restoran_cumartesiacilis,
restoran_cumartesikapanis=:restoran_cumartesikapanis,
restoran_pazaracilis=:restoran_pazaracilis,
restoran_pazarkapanis=:restoran_pazarkapanis

where restoran_id = '$restoran_id'
	");


$derle=$hazirla->execute(array(
"restoran_pazartesiacilis" => $_POST['restoran_pazartesiacilis'],
"restoran_pazartesikapanis" => $_POST['restoran_pazartesikapanis'],
"restoran_saliacilis" => $_POST['restoran_saliacilis'],
"restoran_salikapanis" => $_POST['restoran_salikapanis'],
"restoran_carsambaacilis" => $_POST['restoran_carsambaacilis'],
"restoran_carsambakapanis" => $_POST['restoran_carsambakapanis'],
"restoran_persembeacilis" => $_POST['restoran_persembeacilis'],
"restoran_persembekapanis" => $_POST['restoran_persembekapanis'],
"restoran_cumaacilis" => $_POST['restoran_cumaacilis'],
"restoran_cumakapanis" => $_POST['restoran_cumakapanis'],
"restoran_cumartesiacilis" => $_POST['restoran_cumartesiacilis'],
"restoran_cumartesikapanis" => $_POST['restoran_cumartesikapanis'],
"restoran_pazaracilis" => $_POST['restoran_pazaracilis'],
"restoran_pazarkapanis" => $_POST['restoran_pazarkapanis']
));


if ($derle) {
	
	echo "ok";

} else {

    echo "hata";
}


} else if (isset($_POST['menusil'])){

$cesit_id=$_POST['cesit_id'];


$menusil=$db->prepare("DELETE from restoranmenucesit where cesit_id=:id");
$silmenu=$menusil->execute(array(
"id" => $cesit_id
));

if ($silmenu) {
	
	$yemeksil=$db->prepare("DELETE from yemekler where yemek_cesit=:cesit");
	$yemeksil->execute(array(
"cesit" => $cesit_id
	));

	echo "ok";

} else {

	echo "hata";
}


} else if(isset($_POST['menuupdate'])){



$kullanici_id=$_COOKIE['kullanici_id'];

$kullanicisec=$db->prepare("SELECT * from kullanici where kullanici_id=:id");
$kullanicisec->execute(array(
"id" => $kullanici_id
));

$kullanicicek=$kullanicisec->fetch(PDO::FETCH_ASSOC);

 $restoran_id=$kullanicicek['restoran_id'];


$yemeksec=$db->prepare("SELECT * from yemekler where restoran_id=:id");
$yemeksec->execute(array(
"id" => $restoran_id
));



while ($yemekcek=$yemeksec->fetch(PDO::FETCH_ASSOC)) {
	
	$yemek_id=$yemekcek['yemek_id'];
	$cesit_id=$yemekcek['yemek_cesit'];

	
	



		
		

	







// Önce menü başlıklarını güncelleyelim.

$hazirla=$db->prepare("UPDATE restoranmenucesit set

cesit_ad=:cesit_ad

where cesit_id='$cesit_id'
		");

	$derle=$hazirla->execute(array(
"cesit_ad" => htmlspecialchars(trim($_POST['cesit_ad_'.$cesit_id]))
	));


// Şimdi yemekleri güncelleyelim.


	$hazirla2=$db->prepare("UPDATE yemekler set

yemek_ad=:yemek_ad,
yemek_fiyat=:yemek_fiyat,
yemek_aciklama=:yemek_aciklama

where yemek_id='$yemek_id'
		");


	$derle2=$hazirla2->execute(array(
"yemek_ad" => htmlspecialchars(trim($_POST['menu_yemekad_'.$yemek_id])),
"yemek_fiyat" => htmlspecialchars(trim($_POST['menu_yemekfiyat_'.$yemek_id])),
"yemek_aciklama" => htmlspecialchars(trim($_POST['menu_yemekaciklama_'.$yemek_id]))
	));






	

};


$menucesitsec=$db->prepare("SELECT * from restoranmenucesit where restoran_id=:id");
$menucesitsec->execute(array(
"id" => $restoran_id
));

$ii=0;

while ($menucesitcek=$menucesitsec->fetch(PDO::FETCH_ASSOC)) {

	$ii++;

	$cesitid=$menucesitcek['cesit_id'];

	
		

	
	
	$i=0;

	while ($i<20) {


		
		$i++;

		if (!empty(trim($_POST['menu_yemekad_'.$ii."_".$i]))>0) {

			
				
				$hazirlax=$db->prepare("INSERT into yemekler set

yemek_ad=:yemek_ad,
yemek_aciklama=:yemek_aciklama,
yemek_fiyat=:yemek_fiyat,
yemek_cesit=:yemek_cesit,
restoran_id=:restoran_id

			");


      $derlex=$hazirlax->execute(array(

"yemek_ad" => htmlspecialchars(trim($_POST['menu_yemekad_'.$ii."_".$i])),
"yemek_aciklama" => htmlspecialchars(trim($_POST['menu_yemekaciklama_'.$ii."_".$i])),
"yemek_fiyat" => htmlspecialchars(trim($_POST['menu_yemekfiyat_'.$ii."_".$i])),
"yemek_cesit" => $cesitid,
"restoran_id" => $restoran_id

      ));

			


			
			

			

		

     

	}

	}
}




echo "ok";

} else if (isset($_POST['addmenu'])){

$restoran_id=$_POST['restoran_id'];

$say=0;


        

        while ($say<10) {
        	
        	$say++;

        	$say2=0;

        	if (!empty($_POST['menu_cesit_'.$say])) {

        		$hazirlamenucesit=$db->prepare("INSERT into restoranmenucesit set

cesit_ad=:cesit_ad,
restoran_id=:restoran_id

        			");

        		$derlemenucesit=$hazirlamenucesit->execute(array(
"cesit_ad" => htmlspecialchars(trim($_POST['menu_cesit_'.$say])),
"restoran_id" => $restoran_id
        		));

        		$soncesitkayit=$db->lastInsertId();


while ($say2<20) {
      	
      	$say2++;


      	if (!empty($_POST['menu_yemekad_'.$say."_".$say2])) {

      		
      		

      			$hazirlayemek=$db->prepare("INSERT into yemekler set

yemek_ad=:yemek_ad,
yemek_fiyat=:yemek_fiyat,
yemek_aciklama=:yemek_aciklama,
restoran_id=:restoran_id,
yemek_cesit=:yemek_cesit
      		");

      	$derleyemek=$hazirlayemek->execute(array(
"yemek_ad" => htmlspecialchars(trim($_POST['menu_yemekad_'.$say."_".$say2])),
"yemek_fiyat" => htmlspecialchars(trim($_POST['menu_yemekfiyat_'.$say."_".$say2])),
"yemek_aciklama" => htmlspecialchars(trim($_POST['menu_yemekaciklama_'.$say."_".$say2])),
"restoran_id" => $restoran_id,
"yemek_cesit" => $soncesitkayit
      	));
      			
      		

      			

      		

      			
      		
      		
      		
      	}


      	
      	

      }      

        		
        	 }

        	
        

        }; 


        echo "ok";


} else if(isset($_POST['uyelikaktivasyon'])){

 $girilenkod=$_POST['kullanici_aktivasyonkod'];
 $tamsuan=date('Y-m-d H:i:s');

$kullanicisec=$db->prepare("SELECT * from kullanici where kullanici_id=:id");
$kullanicisec->execute(array(
"id" => $_COOKIE['kullanici_id']
));

$kullanicicek=$kullanicisec->fetch(PDO::FETCH_ASSOC);
$restoran_id=$kullanicicek['restoran_id'];

$gercekkod=$kullanicicek['kullanici_aktivasyonkod'];

if ($gercekkod==strtoupper(trim($girilenkod))) {

	
	if ($kullanicicek['kullanici_yetki']==1) {

		$hazirla=$db->prepare("UPDATE kullanici set

kullanici_mailonay=:kullanici_mailonay

where kullanici_id='{$_COOKIE["kullanici_id"]}'
		");

	$derle=$hazirla->execute(array(
"kullanici_mailonay" => "yes"
	));
		
		echo "kullaniciok";

	} else if ($kullanicicek['kullanici_yetki']==5) {

         $hazirla=$db->prepare("UPDATE kullanici set

kullanici_mailonay=:kullanici_mailonay,
uyelik_turu=:uyelik_turu,
uyelik_baslangic=:uyelik_baslangic,
uyelik_bitis=:uyelik_bitis

where kullanici_id='{$_COOKIE["kullanici_id"]}'
		");

	$derle=$hazirla->execute(array(
"kullanici_mailonay" => "yes",
"uyelik_turu" => 4,
"uyelik_baslangic" => $tamsuan,
"uyelik_bitis" => date("Y-m-d H:i:s",strtotime('+14 days',strtotime($tamsuan)))
	));

	

         echo "adminok";
	}

} else {

echo "yanliskod";

}


} else if(isset($_POST['yenikodgonder'])){

	$rand = strtoupper(substr(md5(microtime()),rand(0,26),5));

	$kullanici_id=$_COOKIE['kullanici_id'];

$hazirla=$db->prepare("UPDATE kullanici set

kullanici_aktivasyonkod=:kullanici_aktivasyonkod

where kullanici_id='$kullanici_id'
	");

$derle=$hazirla->execute(array(

"kullanici_aktivasyonkod" => $rand

));

if ($derle) {
	

require("phpmailer/class/class.phpmailer.php");

	$mail = new PHPMailer(); // Sinifimizi $mail degiskenine atadik
 $mail->CharSet  ="utf-8";
 $mail->Encoding="base64";
$mail->IsSMTP();  // Mailimizin SMTP ile gönderilecegini belirtiyoruz
$mail->Host     = "smtpout.secureserver.net";//"localhost"; //SMTP server adresi
$mail->Port     = '80'; 
$mail->SMTPAuth = true; //SMTP server'a kullanici adi ile baglanilcagini belirtiyoruz.
$mail->Username = "help@bookmeal.online";//"admin@localhost"; //SMTP kullanici adi
$mail->Password = "386Emirhan.";//""; //SMTP mailinizin sifresi
$mail->SMTPSecure = 'SSL';
$mail->From     = 'help@bookmeal.online';//"admin@localhost"; //Gönderen kisminda yer alacak e-mail adresi
$mail->FromName = 'Bookmeal';//"PHP Mailer";//gönderenin ismi
$mail->AddEmbeddedImage('images\logo.png', 'logo', 'logo.png');
$mail->AddAddress($_COOKIE['kullanicioturum']); // Mail gönderilecek adresleri ekliyoruz.
$mail->IsHTML(true); //Mailimizin HTML formatinda hazirlanacagini bildiriyoruz.
$mail->Subject  = 'Aktivasyon Kodu';//"Deneme Maili"; // Mailin Konusu Konu


	$mail->Body = "<div align='center' style='width:100%;height:350px;background-color:#EFEEEA;padding-top:50px;padding-bottom:50px;'>
	
	<div style='width:50%;background-color:#ffffff;height:250px;padding:19px;'>
<a href='https://bookmeal.online'><img src='cid:logo'></a>
	<h1>Sadece siz olduğunuzu kontrol etmek için.</h1><p style='font-size:19px;'>Lütfen kodu kopyalayıp Aktivasyon Kodu kısmına yapıştırın.</p><h2>".$rand."<h2></div>

	<p style='margin-top:30px;color:#707070;'>© 2021 Bookmeal®, Tüm hakları saklıdır.<br>

	Kolektif House - Levent / İstanbul<br></p>
	<span><a href='https://bookmeal.online/contact' style:color:#DB3947;text-decoration:none;>İletişim</a></span>

	</div>";
	
 



 


 

if ($mail->Send()) {
	
	echo "ok";
};

}





} else if(isset($_POST['changemail'])){


	
$rand = strtoupper(substr(md5(microtime()),rand(0,26),5));
$kullanici_mailcurrent=$_COOKIE['kullanicioturum'];
$kullanici_mail=trim($_POST['kullanici_mail']);

$kullanicisec=$db->prepare("SELECT * from kullanici where kullanici_mail=:mail");
$kullanicisec->execute(array(
"mail" => $kullanici_mail
));

$kullanicisay=$kullanicisec->rowCount();

if ($kullanici_mail==$_COOKIE['kullanicioturum']) {
	
	echo "aynimail";

} else if ($kullanicisay>0){



echo "mevcutmail";


} else {

    $hazirla=$db->prepare("UPDATE kullanici set

kullanici_mail=:kullanici_mail,
kullanici_aktivasyonkod=:kullanici_aktivasyonkod

where kullanici_mail='$kullanici_mailcurrent'

    	");


    $derle=$hazirla->execute(array(
"kullanici_mail" => htmlspecialchars($kullanici_mail),
"kullanici_aktivasyonkod" => $rand
    ));

    if ($derle) {
    	

    	setcookie('kullanicioturum',"",time()-31556926);
    	setcookie('kullanicioturum',trim($kullanici_mail),time()+31556926);

    	
require("phpmailer/class/class.phpmailer.php");

	$mail = new PHPMailer(); // Sinifimizi $mail degiskenine atadik
 $mail->CharSet  ="utf-8";
 $mail->Encoding="base64";
$mail->IsSMTP();  // Mailimizin SMTP ile gönderilecegini belirtiyoruz
$mail->Host     = "smtpout.secureserver.net";//"localhost"; //SMTP server adresi
$mail->Port     = '80'; 
$mail->SMTPAuth = true; //SMTP server'a kullanici adi ile baglanilcagini belirtiyoruz.
$mail->Username = "help@bookmeal.online";//"admin@localhost"; //SMTP kullanici adi
$mail->Password = "386Emirhan.";//""; //SMTP mailinizin sifresi
$mail->SMTPSecure = 'SSL';
$mail->From     = 'help@bookmeal.online';//"admin@localhost"; //Gönderen kisminda yer alacak e-mail adresi
$mail->FromName = 'Bookmeal';//"PHP Mailer";//gönderenin ismi
$mail->AddAddress($kullanici_mail); // Mail gönderilecek adresleri ekliyoruz.
$mail->IsHTML(true); //Mailimizin HTML formatinda hazirlanacagini bildiriyoruz.
$mail->Subject  = 'Aktivasyon Kodu';//"Deneme Maili"; // Mailin Konusu Konu


	$mail->Body = '<div align="center" style="width:100%;height:100px;">
	<h3 style="underline:1px" align="center">Aktivasyon Kodu</h3><h4 align="center" style="">'.$rand.'<h4></div>';
	
 



 


 

$mail->Send();

	echo "ok";

 
    }



	
}

} else if(isset($_POST['yenimasaekle'])){

$restoran_id=$_POST['restoran_id'];

$restoransec=$db->prepare("SELECT * from restoranlar where restoran_id=:id");
$restoransec->execute(array(
"id" => $restoran_id
));

$restorancek=$restoransec->fetch(PDO::FETCH_ASSOC);

$restoran_masasayisi=$restorancek['restoran_masasayisi'];
$restoran_masasayisiyeni=$restorancek['restoran_masasayisi']+1;
$restoran_seo=$restorancek['restoran_seo'];
$restoran_ad=$restorancek['restoran_ad'];
$restoran_logo=$restorancek['restoran_logo'];
$restoran_renk=$restorancek['restoran_renk'];


$hazirla=$db->prepare("UPDATE restoranlar set

restoran_masasayisi=:restoran_masasayisi

where restoran_id='$restoran_id'
	");

$derle=$hazirla->execute(array(
"restoran_masasayisi" => $restoran_masasayisiyeni
));

if ($derle) {

	$path='dimg/qrkodlar';
        	$file=$restoran_id."_masa-".$restoran_masasayisiyeni.".png";
        	$text="bookmeal.online/r-".$restoran_seo."-".$restoran_masasayisiyeni;
        	QRcode::png($text,$path."/".$file);

        	$hazirla2=$db->prepare("INSERT into qrkodlar set

restoran_id=:restoran_id,
qr_url=:qr_url,
qr_foto=:qr_foto,
qr_masano=:qr_masano
        		");

        	$derle2=$hazirla2->execute(array(
"restoran_id" => $restoran_id,
"qr_masano" => $restoran_masasayisiyeni,
"qr_foto" => $path."/".$file,
"qr_url" => "r-".$restoran_seo."-".$restoran_masasayisiyeni
        	)); ?>


        	
	<div style="height: 604px;width: 430px;" class="col-md-4 qritem">



											<div class="card_<?php echo $restoran_masasayisiyeni; ?>" align="center" style="height: 155mm;width:420px;background: white;position: relative;border: 1px solid <?php echo $restorancek['restoran_renk']; ?>">


												<div align="center" class="col-md-12 col-xs-12 col-sm-12" style="height: 130px;margin-top:30px;">
													
													<?php if (empty($restorancek['restoran_logo'])) { ?>
													<h4 style='color: <?php echo $restorancek['restoran_renk']; ?>'>Hoşgeldiniz!</h4>
													<?php } else { ?>

         <img style="max-height: 100px;max-width: 150px;" src="<?php echo $restorancek['restoran_logo']; ?>">

													<?php } ?>
												</div>

												<div class="col-xs-12 col-sm-12 col-md-12">
												
												<div  style="height: 190px;width: 105px;">

													<h5 align="center">QR MENÜ</h5>
						
										<div class="restaurant-grid-item">
											
												
													<img src="<?php echo $path."/".$file; ?>" alt="Image" />
												
												<div class="content">
													<h5 align="center">Masa <?php echo $restoran_masasayisiyeni; ?></h5>
													
													
												</div>
											
										</div>
							
									</div>

									</div>



									<?php

                                   $kullanicisec=$db->prepare("SELECT * from kullanici where restoran_id=:id");
                                   $kullanicisec->execute(array(

                                   	"id" => $restorancek['restoran_id']

                                   ));

                                   $kullanicicek=$kullanicisec->fetch(PDO::FETCH_ASSOC);

                                   $uyelik_turu=$kullanicicek['uyelik_turu'];
                                   
									 if ($uyelik_turu==2 or $uyelik_turu==4) { ?>

									<div style="margin-top:30px; <?php if ($restorancek['kart_preorder']=='no') { ?>
										display: none;
								<?php	} ?> " class="col-xs-12 col-sm-12 col-md-12 forpreorder">
										<b style='font-size:15px;'>Ön Sipariş İçin <i class="fas fa-angle-down"></i></b><br>
										<a style="font-weight: bold;font-size: 15px;color: <?php echo $restorancek['restoran_renk']; ?>" href="preorder?sef=<?php echo $restorancek['restoran_seo']; ?>"><?php echo $restorancek['restoran_seo']; ?>.bookmeal.online</a>
									</div>

									<?php } ?>

									<div class="col-xs-12 col-sm-12 col-md-12" style="height: 50px;background: <?php echo $restorancek['restoran_renk']; ?>;position: absolute;left:0;bottom: 0;">

										<h6 style="color: white;margin-top:13px;" align="center">QR Kodu Telefonunuzla Tarayın</h6>
										
									</div>

									

											</div>

											


						
										
							
									</div>
	

<?php } else {

echo "hata";

}




} else if(isset($_POST['sonmasasil'])){

$restoran_id=$_POST['restoran_id'];

$restoransec=$db->prepare("SELECT * from restoranlar where restoran_id=:id");
$restoransec->execute(array(
"id" => $restoran_id
));

$restorancek=$restoransec->fetch(PDO::FETCH_ASSOC);

$restoran_masasayisi=$restorancek['restoran_masasayisi'];
$restoran_masasayisiyeni=$restorancek['restoran_masasayisi']-1;

if ($restoran_masasayisi==1) {
	
	echo "masasayisi1";

} else {

	$masasil=$db->prepare("DELETE from qrkodlar where qr_masano=:masano and restoran_id=:id");
$silmasa=$masasil->execute(array(
"masano" => $restoran_masasayisi,
"id" => $restoran_id
));

if ($silmasa) {
	
	unlink('dimg/qrkodlar/'.$restoran_id."_masa-".$restoran_masasayisi.".png");

	$hazirla=$db->prepare("UPDATE restoranlar set

restoran_masasayisi=:restoran_masasayisi

where restoran_id='$restoran_id'
		");

	$derle=$hazirla->execute(array(
"restoran_masasayisi" => $restoran_masasayisiyeni
	));

	echo "islemtamam";

} else {

	echo "hata";
}
}


} else if(isset($_POST['panelsiparissil'])){

$siparis_id=$_POST['siparis_id'];

$hazirla=$db->prepare("UPDATE siparisler set

siparis_bildirim=:siparis_bildirim

where siparis_id='$siparis_id'
	");
$hazirla->execute(array(
"siparis_bildirim" => 0
));





echo "islemtamam";

} else if(isset($_POST['panelonsiparissil'])){

$siparis_id=$_POST['siparis_id'];

$hazirla=$db->prepare("UPDATE onsiparisler set

siparis_bildirim=:siparis_bildirim

where siparis_id='$siparis_id'
	");
$hazirla->execute(array(
"siparis_bildirim" => 0
));





echo "islemtamam";

} else if(isset($_POST['logoupdate'])){

	$restoran_id=$_POST['restoran_id'];


	$uzanti=ext($_FILES['restoran_logo']['name']);

	$restoransec=$db->prepare("SELECT * from restoranlar where restoran_id=:id");
	$restoransec->execute(array(
"id" => $restoran_id
	));

	$restorancek=$restoransec->fetch(PDO::FETCH_ASSOC);

	$restoran_logo=$restorancek['restoran_logo'];

	if (!empty($restoran_logo)) {
		unlink($restoran_logo);
	};

	

$depodosya = 'dimg/restoranlogo';
   	

 				$tmp_name = $_FILES['restoran_logo']["tmp_name"];
                
 				 	$name = $_FILES['restoran_logo']["name"];



$uniq=uniqid();
	$refimgyol=$depodosya."/".$uniq.".".$uzanti;
	

	@move_uploaded_file($tmp_name, "$depodosya/$uniq.$uzanti");


	$hazirla=$db->prepare("UPDATE restoranlar set

restoran_logo=:restoran_logo

where restoran_id='$restoran_id'
		");

	$derle=$hazirla->execute(array(
"restoran_logo" => $refimgyol
	));




	if ($derle) { 
		$restoransec2=$db->prepare("SELECT * from restoranlar where restoran_id=:id");
	$restoransec2->execute(array(
"id" => $restoran_id
	));

	$restorancek2=$restoransec2->fetch(PDO::FETCH_ASSOC); ?>

<img src="<?php echo $restorancek2['restoran_logo']; ?>" alt="author image">
<br>
<a id="logosil" href='javascript:void(0);'><i style="color: #043D75;" class="far fa-trash-alt"></i></a>
		
	<?php } else {

		echo "hata";
	}
    

 				 	 



}  else if(isset($_POST['logosil'])){

$restoran_id=$_POST['restoran_id'];

$restoransec=$db->prepare("SELECT * from restoranlar where restoran_id=:id");
$restoransec->execute(array(
"id" => $restoran_id
));

$restorancek=$restoransec->fetch(PDO::FETCH_ASSOC);

$restoran_logo=$restorancek['restoran_logo'];

unlink($restoran_logo);

$hazirla=$db->prepare("UPDATE restoranlar set

restoran_logo=:restoran_logo

where restoran_id='$restoran_id'
	");

$derle=$hazirla->execute(array(
"restoran_logo" => NULL
));

if ($derle) {
	
	echo "islemtamam";
}


} else if (isset($_POST['panelsipariscek'])){

 $restoran_id=$_POST['restoran_id'];
 $restoran_currency=$_POST['restoran_currency'];

 $tamsuan = date('Y-m-d H:i:s');
   $dakika1once = date("Y-m-d H:i:s",strtotime('-11 seconds',strtotime($tamsuan)));
   $saat1once = date("Y-m-d H:i:s",strtotime('-60 minutes',strtotime($tamsuan)));



 $yenisiparissec=$db->prepare("SELECT * from siparisler where restoran_id='$restoran_id' and siparis_turu=1 and siparis_zaman between '$dakika1once' and '$tamsuan'");
 $yenisiparissec->execute();
  $yenisiparissay=$yenisiparissec->rowCount();

  $yenionsiparissec=$db->prepare("SELECT * from onsiparisler where restoran_id='$restoran_id' and siparis_turu=1 and siparis_zaman between '$dakika1once' and '$tamsuan'");
 $yenionsiparissec->execute();
  $yenionsiparissay=$yenionsiparissec->rowCount();

 if ($yenisiparissay>0 or $yenionsiparissay>0) {

$hazirla=$db->prepare("UPDATE siparisler set

siparis_bildirim=:siparis_bildirim

where siparis_turu='5' and siparis_bildirim='1' and restoran_id='$restoran_id' and siparis_zaman <= '$saat1once'
	");

$derle=$hazirla->execute(array(

"siparis_bildirim" => 0

));

  ?>
 	
 	

			<div class="container pt-10 pb-30">
			
				
				
				<div class="row mb-10">
				
					<div class="col-md-8">
					
						<div style="margin-top: 30px;" class="section-title-02">



							<?php 



							$kayitlisiparissec=$db->prepare("SELECT * from siparisler where siparis_turu=:turu and restoran_id=:id and siparis_bildirim=:bildirim order by siparis_zaman ASC");
							$kayitlisiparissec->execute(array(

"id" => $restoran_id,
"turu" => 5,
"bildirim" => 1
							));

							 $kayitlisiparissay=$kayitlisiparissec->rowCount();

							 $kayitlionsiparissec=$db->prepare("SELECT * from onsiparisler where siparis_turu=:turu and restoran_id=:id and siparis_bildirim=:bildirim order by siparis_zaman ASC");
							$kayitlionsiparissec->execute(array(

"id" => $restoran_id,
"turu" => 5,
"bildirim" => 1
							));

							 $kayitlionsiparissay=$kayitlionsiparissec->rowCount();
					 ?>

							<h3><span>DEVAM EDEN SİPARİŞLER<small class="ml-10 siparissayisi">/ <?php echo $kayitlisiparissay." SİPARİŞ"; ?></small></span></h3><a href="past-orders"><button class="mt-15 btn btn-primary btn-sm"><i class="fas fa-history"></i> Geçmiş Siparişler</button></a> <a target="_blank" href="preorders"><button style="background: #043D75;border-color: #043D75;" class="mt-15 btn btn-primary btn-sm"><?php echo $kayitlionsiparissay; ?> Ön Sipariş</button></a>
					
						</div>
					
					</div>
					
				</div>
						
				<div class="row">
				
					
					
					<div style="min-height: 345px;" class="col-sm-12 col-md-12 col-xs-12">
						
						

						<div class="restaurant-list-item-wrapper no-last-bb">

							<?php 


if ($kayitlisiparissay==0) { ?>

<h4 align="center">Devam eden bir sipariş yok.</h4>	

<?php } ?> <?php
							while($kayitlisipariscek=$kayitlisiparissec->fetch(PDO::FETCH_ASSOC)){ 

								$restoransec=$db->prepare("SELECT * from restoranlar where restoran_id=:id");
								$restoransec->execute(array(

									"id" => $kayitlisipariscek['restoran_id']
								));

								$restorancek=$restoransec->fetch(PDO::FETCH_ASSOC); ?>

								<div class="restaurant-list-item clearfix <?php echo $kayitlisipariscek['siparis_id']; ?>">
							
								<div class="GridLex-grid-noGutter-equalHeight">
								
									
									
									<div class="GridLex-col-12_sm-12_xss-12">
									
										<div class="GridLex-grid-noGutter-equalHeight">
										
											<div class="GridLex-col-9_sm-12 content-wrapper">
											
												<div class="content">

													<p style="font-weight: bold;color: #043D75;"> Sipariş No: #<?php echo $kayitlisipariscek['siparis_no']; ?></p>

													<p style="font-weight: bold; "><i class="fas fa-clock"></i> Sipariş Zamanı: <?php echo substr($kayitlisipariscek['siparis_zaman'],11,5); ?></p>
													
													

													<p style="font-weight: bold;" class="location"><i class="fas fa-chair"></i> <?php echo "Masa No: ".$kayitlisipariscek['siparis_masano']; ?> </p>

													<?php if (!empty($kayitlisipariscek['siparis_ozeltalep'])) { ?>

 														<p style="font-weight: bold;"><i class="fas fa-edit"></i> <?php echo $kayitlisipariscek['siparis_ozeltalep']; ?></p>

													<?php } ?>

													
													
													<p class="cuisine"><b>Sipariş:</b> <?php $siparisyemeksec=$db->prepare("SELECT * from siparisyemek where siparis_id=:id");
													$siparisyemeksec->execute(array(

														"id" => $kayitlisipariscek['siparis_id']

													));  while ($siparisyemekcek=$siparisyemeksec->fetch(PDO::FETCH_ASSOC)) { 

														$yemeksec=$db->prepare("SELECT * from yemekler where yemek_id=:id");
														$yemeksec->execute(array(

															"id" => $siparisyemekcek['yemek_id']
														));

														$yemekcek=$yemeksec->fetch(PDO::FETCH_ASSOC); ?>
															<span><?php echo $yemekcek['yemek_ad']."<b> x ".$siparisyemekcek['yemek_adet']."</b>"; ?></span>
														<?php } ?> </p>
												</div>
											
											</div>
											
											<div class="GridLex-col-3_sm-12 meta-wrapper">

												
											
												<div class="meta">

													<a href='javascript:void(0);' name="name_<?php echo $kayitlisipariscek['siparis_id']; ?>" class="siparissil"><i style="color: #043D75;" class="far fa-trash-alt"></i></a>
													
													<div class="right-bottom">
														<div class="price">Sipariş Tutarı:<span><?php echo $restoran_currency."".$kayitlisipariscek['siparis_tutar']; ?></span></div>
														<div class="clear"></div>
														
													</div>
												</div>
											
											</div>
										
										</div>
										
									</div>
									
								</div>
							
							</div>
 
							<?php } ?>

							

							

						</div>

						
						
					</div>


				</div>
				
			</div>
			

 <?php } else {

 	echo "dur";
 }



} else if (isset($_POST['renkdegistir'])){

$restoran_id=$_POST['restoran_id'];
$renkkodu=$_POST['renkkodu'];

$hazirla=$db->prepare("UPDATE restoranlar set

restoran_renk=:restoran_renk 

where restoran_id='$restoran_id'
	");

$derle=$hazirla->execute(array(
"restoran_renk" => "#".$renkkodu
));

echo "islemtamam";

} else if(isset($_POST['yemeksil'])){

$yemek_id=$_POST['yemek_id'];
$yemeksil=$db->prepare("DELETE from yemekler where yemek_id=:id");
$silyemek=$yemeksil->execute(array(
"id" => $yemek_id
));

if ($silyemek) {
	
	echo "ok";

} else {

	echo "hata";
}


} else if (isset($_POST['onsiparisver'])){


$yemekler=$_POST['yemekler'];
 $siparis_tutar=0;
 $siparis_kisisayisi=$_POST['siparis_kisisayisi'];
 $siparis_ozeltalep=htmlspecialchars(trim($_POST['siparis_ozeltalep']));
 $restoran_id=$_POST['restoran_id'];
 $siparis_variszaman=date('Y-m-d '.$_POST['siparis_variszaman'].":s")." ";
 $siparis_kaybolmazaman=date("Y-m-d H:i:s",strtotime('+60 minutes',strtotime($siparis_variszaman)));

 $restoransec=$db->prepare("SELECT * from restoranlar where restoran_id=:id");
 $restoransec->execute(array(
"id" => $restoran_id
 ));

 $restorancek=$restoransec->fetch(PDO::FETCH_ASSOC);

 $gun=date('w');

switch ($gun) {

	case '0':
	   $acilis=$restorancek['restoran_pazaracilis'];
	   $kapanis=$restorancek['restoran_pazarkapanis'];
		break;

		case '1':
	   $acilis=$restorancek['restoran_pazartesiacilis'];
	   $kapanis=$restorancek['restoran_pazartesikapanis'];
		break;

		case '2':
	   $acilis=$restorancek['restoran_saliacilis'];
	   $kapanis=$restorancek['restoran_salikapanis'];
		break;

		case '3':
	   $acilis=$restorancek['restoran_carsambaacilis'];
	   $kapanis=$restorancek['restoran_carsambakapanis'];
		break;

		case '4':
	   $acilis=$restorancek['restoran_persembeacilis'];
	   $kapanis=$restorancek['restoran_persembekapanis'];
		break;

		case '5':
	   $acilis=$restorancek['restoran_cumaacilis'];
	   $kapanis=$restorancek['restoran_cumakapanis'];
		break;

		case '6':
	   $acilis=$restorancek['restoran_cumartesiacilis'];
	   $kapanis=$restorancek['restoran_cumartesikapanis'];
		break;
	
	
};

$suansaat=date("Y-m-d H:i:s");
$suansaat2=date('H:i');
$siparisvariszamansaat=substr($siparis_variszaman,11,5);

if ($acilis=="" or $kapanis=="") {
	
	echo "mekankapali";

} else if($acilis>$siparisvariszamansaat) {

echo "mekanacilmadi";

}  else if($suansaat2>$kapanis){

	echo "mekankapandi";

} else if ($siparis_variszaman<=$suansaat) {
	
	echo "zamanyanlis";

} else if($siparisvariszamansaat>$kapanis){

	echo "mekankapanacak";

} else {

	foreach ($yemekler as $yemek) {

	if ($_POST['yemekadet_'.$yemek]!=0) {
		
		$yemeksec=$db->prepare("SELECT * from yemekler where yemek_id=:id");
	$yemeksec->execute(array(
"id" => $yemek
	));

	$yemekcek=$yemeksec->fetch(PDO::FETCH_ASSOC);

	$yemekfiyat=$yemekcek['yemek_fiyat']*$_POST['yemekadet_'.$yemek];

	$siparis_tutar+=$yemekfiyat;



	}



};

$hazirla=$db->prepare("INSERT into onsiparisler set

siparis_kisisayisi=:siparis_kisisayisi,
siparis_ozeltalep=:siparis_ozeltalep,
restoran_id=:restoran_id,
kullanici_id=:kullanici_id,
siparis_turu=:siparis_turu,
siparis_tutar=:siparis_tutar,
siparis_variszaman=:siparis_variszaman,
siparis_kaybolmazaman=:siparis_kaybolmazaman,
siparis_zaman=:siparis_zaman

	");

$derle=$hazirla->execute(array(
"siparis_kisisayisi" => $siparis_kisisayisi,
"siparis_ozeltalep" => $siparis_ozeltalep,
"restoran_id" => $restoran_id,
"kullanici_id" => $_COOKIE['kullanici_id'],
"siparis_turu" => 1,
"siparis_tutar" => $siparis_tutar,
"siparis_variszaman" => $siparis_variszaman,
"siparis_kaybolmazaman" => $siparis_kaybolmazaman,
"siparis_zaman" => date('Y-m-d H:i:s')

));

$sonkayit=$db->lastInsertId();

foreach ($yemekler as $yemek) {
	
	if ($_POST['yemekadet_'.$yemek]!=0) {
		
		$hazirla2=$db->prepare("INSERT into onsiparisyemek set

siparis_id=:siparis_id,
yemek_id=:yemek_id,
yemek_adet=:yemek_adet,
siparisyemek_turu=:siparisyemek_turu
		");


	$derle2=$hazirla2->execute(array(

"siparis_id" => $sonkayit,
"yemek_id" => $yemek,
"yemek_adet" => $_POST['yemekadet_'.$yemek],
"siparisyemek_turu" => 1

	));
	}

}


$hazirla3=$db->prepare("INSERT into onsiparisler set

kullanici_id=:kullanici_id,
siparis_ozeltalep=:siparis_ozeltalep,
siparis_kisisayisi=:siparis_kisisayisi,
siparis_tutar=:siparis_tutar,
restoran_id=:restoran_id,
siparis_turu=:siparis_turu,
siparis_variszaman=:siparis_variszaman,
siparis_kaybolmazaman=:siparis_kaybolmazaman,
siparis_no=:siparis_no,
siparis_zaman=:siparis_zaman

	");

$derle3=$hazirla3->execute(array(

"kullanici_id" => $_COOKIE['kullanici_id'],
"siparis_ozeltalep" => htmlspecialchars(trim($siparis_ozeltalep)),
"siparis_kisisayisi" => $siparis_kisisayisi,
"siparis_tutar" => $siparis_tutar,
"restoran_id" => $restoran_id,
"siparis_turu" => 5,
"siparis_variszaman" => $siparis_variszaman,
"siparis_kaybolmazaman" => $siparis_kaybolmazaman,
"siparis_no" => $sonkayit,
"siparis_zaman" => date('Y-m-d H:i:s')
));

$sonkayit2=$db->lastInsertId();

foreach ($yemekler as $yemek) {
	
	if ($_POST['yemekadet_'.$yemek]!=0) {
		
		$hazirla2=$db->prepare("INSERT into onsiparisyemek set

siparis_id=:siparis_id,
yemek_id=:yemek_id,
yemek_adet=:yemek_adet,
siparisyemek_turu=:siparisyemek_turu
		");


	$derle2=$hazirla2->execute(array(

"siparis_id" => $sonkayit2,
"yemek_id" => $yemek,
"yemek_adet" => $_POST['yemekadet_'.$yemek],
"siparisyemek_turu" => 5

	));
	}

}



}

} else if (isset($_POST['panelonsipariscek'])){

$restoran_id=$_POST['restoran_id'];
$restoran_currency=$_POST['restoran_currency'];

 $tamsuan = date('Y-m-d H:i:s');
   $dakika1once = date("Y-m-d H:i:s",strtotime('-11 seconds',strtotime($tamsuan)));
     $saat1once = date("Y-m-d H:i:s",strtotime('-60 minutes',strtotime($tamsuan)));




 $yenisiparissec=$db->prepare("SELECT * from onsiparisler where restoran_id='$restoran_id' and siparis_turu=1 and siparis_zaman between '$dakika1once' and '$tamsuan'");
 $yenisiparissec->execute();
  $yenisiparissay=$yenisiparissec->rowCount();

 if ($yenisiparissay>0) { 


$hazirla=$db->prepare("UPDATE onsiparisler set

siparis_bildirim=:siparis_bildirim,
siparis_variszaman=:siparis_variszaman,
siparis_kaybolmazaman=:siparis_kaybolmazaman

where siparis_turu='5' and siparis_bildirim='1' and kullanici_id={$_COOKIE['kullanici_id']} and siparis_kaybolmazaman <= '$tamsuan'
	");

$derle=$hazirla->execute(array(

"siparis_bildirim" => 0,
"siparis_variszaman" => NULL,
"siparis_kaybolmazaman" => NULL

));

 	?>
 	
 	

			<div class="container pt-10 pb-30">
			
				
				
				<div class="row mb-10">
				
					<div class="col-md-8">
					
						<div style="margin-top: 30px;" class="section-title-02">



							<?php 



							$kayitlisiparissec=$db->prepare("SELECT * from onsiparisler where siparis_turu=:turu and restoran_id=:id and siparis_bildirim=:bildirim order by siparis_variszaman ASC");
							$kayitlisiparissec->execute(array(

"id" => $restoran_id,
"turu" => 5,
"bildirim" => 1
							));

							 $kayitlisiparissay=$kayitlisiparissec->rowCount();
					 ?>

							<h3><span>DEVAM EDEN ÖN SİPARİŞLER<small class="ml-10 siparissayisi">/ <?php echo $kayitlisiparissay." SİPARİŞ"; ?></small></span></h3><a href="past-pre-orders"><button class="mt-15 btn btn-primary btn-sm"><i class="fas fa-history"></i> Geçmiş Ön Siparişler</button></a>
					
						</div>
					
					</div>
					
				</div>
						
				<div class="row">
				
					
					
					<div style="min-height: 345px;" class="col-sm-12 col-md-12 col-xs-12">
						
						

						<div class="restaurant-list-item-wrapper no-last-bb">

							<?php 


if ($kayitlisiparissay==0) { ?>

<h4 align="center">Devam eden bir sipariş yok.</h4>	

<?php } ?> <?php
							while($kayitlisipariscek=$kayitlisiparissec->fetch(PDO::FETCH_ASSOC)){ 

								$restoransec=$db->prepare("SELECT * from restoranlar where restoran_id=:id");
								$restoransec->execute(array(

									"id" => $kayitlisipariscek['restoran_id']
								));

								$restorancek=$restoransec->fetch(PDO::FETCH_ASSOC); ?>

								<div class="restaurant-list-item clearfix <?php echo $kayitlisipariscek['siparis_id']; ?>">
							
								<div class="GridLex-grid-noGutter-equalHeight">
								
									
									
									<div class="GridLex-col-12_sm-12_xss-12">
									
										<div class="GridLex-grid-noGutter-equalHeight">
										
											<div class="GridLex-col-9_sm-12 content-wrapper">
											
												<div class="content">

													<p style="font-weight: bold; color: #043D75;"> Sipariş No: #<?php echo $kayitlisipariscek['siparis_no']; ?></p>
													
													
                                                    <p style="font-weight: bold;"><i class="fas fa-user"></i> <?php echo $kayitlisipariscek['siparis_kisisayisi']." Misafir"; ?></p>

                                                    <p style="font-weight: bold;"><i class="fas fa-clock"></i> Varış Zamanı: <?php echo substr($kayitlisipariscek['siparis_variszaman'],11,5); ?></p>
													

													<?php if (!empty($kayitlisipariscek['siparis_ozeltalep'])) { ?>

 														<p style="font-weight: bold;"><i class="fas fa-edit"></i> <?php echo $kayitlisipariscek['siparis_ozeltalep']; ?></p>

													<?php } ?>

													
													
													<p class="cuisine"><b>Sipariş:</b> <?php $siparisyemeksec=$db->prepare("SELECT * from onsiparisyemek where siparis_id=:id");
													$siparisyemeksec->execute(array(

														"id" => $kayitlisipariscek['siparis_id']

													));  while ($siparisyemekcek=$siparisyemeksec->fetch(PDO::FETCH_ASSOC)) { 

														$yemeksec=$db->prepare("SELECT * from yemekler where yemek_id=:id");
														$yemeksec->execute(array(

															"id" => $siparisyemekcek['yemek_id']
														));

														$yemekcek=$yemeksec->fetch(PDO::FETCH_ASSOC); ?>
															<span><?php echo $yemekcek['yemek_ad']."<b> x ".$siparisyemekcek['yemek_adet']."</b>"; ?></span>
														<?php } ?> </p>
												</div>
											
											</div>
											
											<div class="GridLex-col-3_sm-12 meta-wrapper">

												
											
												<div class="meta">

													<a href='javascript:void(0);' name="name_<?php echo $kayitlisipariscek['siparis_id']; ?>" class="siparissil"><i style="color: #043D75;" class="far fa-trash-alt"></i></a>
													
													<div class="right-bottom">
														<div class="price">Sipariş Tutarı: <span><?php echo $restoran_currency."".$kayitlisipariscek['siparis_tutar']; ?></span></div>
														<div class="clear"></div>
														
													</div>
												</div>
											
											</div>
										
										</div>
										
									</div>
									
								</div>
							
							</div>
 
							<?php } ?>

							

							

						</div>

						
						
					</div>


				</div>
				
			</div>
			

 <?php } else {

 	echo "dur";
 }


} else if (isset($_POST['kartpreorder'])){

$restoran_id=$_POST['restoran_id'];
$checkboxdeger=$_POST['checkboxdeger'];

$hazirla=$db->prepare("UPDATE restoranlar set

kart_preorder=:kart_preorder

where restoran_id='$restoran_id'
	");

$derle=$hazirla->execute(array(
"kart_preorder" => $checkboxdeger
));


} else if (isset($_POST['odemeyap'])){

	 $uyelik_turu=$_POST['uyelik_turu'];
     $kartnumarasi=trim(tum_bosluk_sil(str_replace("-","",$_POST['pan'])));
     $kart_ay=$_POST['expiryMonth'];
     $kart_yil=$_POST['expiryYear'];
      $kartsahibi=ucwords(strtolower(trim($_POST['cardOwner'])));
       $cvv=trim($_POST['cvv']);
       $kullanici_mail=$_POST['kullanici_mail'];
      $kullanici_id=$_COOKIE['kullanici_id'];
       $amount=floatval($_POST['amount']);
       $url = 'https://entegrasyon.paratika.com.tr/paratika/api/v2';
       $str_RANDOMNUMBER=uniqid(); 



       $data = array('ACTION' => 'RECURRINGPLANADD',
             'INSTANTPAYMENT' => 'YES',
        'MERCHANTUSER' => 'emrhnynr1@gmail.com',
        'MERCHANTPASSWORD' => '386Emirhan.',
        'MERCHANT' => '10001081',
        'CARDPAN' => $kartnumarasi,
        "CARDEXPIRY" => $kart_ay.".".$kart_yil,
        'RECURRINGAMOUNT' => '10',
        'CURRENCY' => 'TRY',       
        'NAMEONCARD' => $kartsahibi,
        'CUSTOMER' => 'CUSTOMER',
        'CUSTOMEREMAIL' => $kullanici_mail,
        'RECURRINGPLANCODE' => $str_RANDOMNUMBER,
        'RECURRENCECOUNT' => '10',
        'FREQUENCY' => '1Y',
        "STARTDATE" => date('d-m-Y')


         );



//you should add your parameters to $data array
//if you get https exception pls enable php_openssl.dll http://stackoverflow.com/questions/5444249/unable-to-find-the-wrapper-https-did-you-forget-to-enable-it-when-you-config
//use key 'http' even if you send the request to https://...

$options = array(
    'http' => array(
        'header' => "Content-type: application/x-www-form-urlencoded\r\n",
        'method' => 'POST',
        'content' => http_build_query($data)
    )
);
$context = stream_context_create($options);
$result = file_get_contents($url, false, $context);


$resultObject = json_decode($result);

if ($resultObject->{'responseCode'}=="00") {

	$tamsuan=date('Y-m-d');
  
  $hazirla=$db->prepare("UPDATE kullanici set

uyelik_baslangic=:uyelik_baslangic,
uyelik_bitis=:uyelik_bitis,
uyelik_turu=:uyelik_turu

where kullanici_id='$kullanici_id'

 ");

$derle=$hazirla->execute(array(
"uyelik_baslangic" => $tamsuan,
"uyelik_bitis" => date("Y-m-d",strtotime('+10 years',strtotime($tamsuan))),
"uyelik_turu" => $uyelik_turu
));

  echo "basarili";

} else {

  echo "basarisiz";
}


} else if (isset($_POST['sifremiunuttum'])){

$kullanici_mail=$_POST['kullanici_mail'];

$kullanicisec=$db->prepare("SELECT * from kullanici where kullanici_mail=:mail");
$kullanicisec->execute(array(
"mail" => $kullanici_mail
));

$kullanicicek=$kullanicisec->fetch(PDO::FETCH_ASSOC);

$kullanicisay=$kullanicisec->rowCount();

if ($kullanicisay==0) {
	
	echo "kullanicibulunamadi";

} else {

	

	if (!empty($kullanicicek['kullanici_uniq'])) {

		echo "mailgonderilmis";

	} else {

		$kullanici_id=$kullanicicek['kullanici_id'];

	$uniq=uniqid();

	$hazirla=$db->prepare("UPDATE kullanici set

kullanici_uniq=:kullanici_uniq

where kullanici_id='$kullanici_id'
		");

	$derle=$hazirla->execute(array(

"kullanici_uniq" =>  $uniq
	));

	if ($derle) {
		
		require("phpmailer/class/class.phpmailer.php");

	$mail = new PHPMailer(); // Sinifimizi $mail degiskenine atadik
 $mail->CharSet  ="utf-8";
 $mail->Encoding="base64";
$mail->IsSMTP();  // Mailimizin SMTP ile gönderilecegini belirtiyoruz
$mail->Host     = "smtpout.secureserver.net";//"localhost"; //SMTP server adresi
$mail->Port     = '80'; 
$mail->SMTPAuth = true; //SMTP server'a kullanici adi ile baglanilcagini belirtiyoruz.
$mail->Username = "help@bookmeal.online";//"admin@localhost"; //SMTP kullanici adi
$mail->Password = "386Emirhan.";//""; //SMTP mailinizin sifresi
$mail->SMTPSecure = 'SSL';
$mail->From     = 'help@bookmeal.online';//"admin@localhost"; //Gönderen kisminda yer alacak e-mail adresi
$mail->FromName = 'Bookmeal';//"PHP Mailer";//gönderenin ismi
$mail->AddAddress($kullanici_mail); // Mail gönderilecek adresleri ekliyoruz.
$mail->IsHTML(true); //Mailimizin HTML formatinda hazirlanacagini bildiriyoruz.
$mail->Subject  = 'Şifrenizi Yenileyin';//"Deneme Maili"; // Mailin Konusu Konu


	$mail->Body = '<div class="col-xs-12 col-sm-12 col-md-12" style="padding-top:40px;" align="center"><h3 style="text-align:center;">Aşağıdaki butona tıklayın ve şifrenizi yenileyin.</h3><a href="bookmeal.online/resetpassword?u='.$uniq.'&id='.$kullanici_id.'"><button style="height:35px;border:1px solid #043D75;background:#043D75;color:white;font-size:20px;">Şifrenizi Yenileyin</button></a>';
	
 



 


 

$mail->Send();

echo "ok";
	}
}
	}

} else if(isset($_POST['sifreyenile'])){

$kullanici_id=$_POST['kullanici_id'];

$kullanicisec=$db->prepare("SELECT * from kullanici where kullanici_id=:id");
	$kullanicisec->execute(array(
"id" => $kullanici_id
	));

	$kullanicicek=$kullanicisec->fetch(PDO::FETCH_ASSOC);

	$kullanici_mail=$kullanicicek['kullanici_mail'];

	$yeni_sifre=$_POST['yeni_sifre'];
$yeni_sifre_tekrar=$_POST['yeni_sifre_tekrar'];

 if(strlen($yeni_sifre)<8){

echo "kisasifre";

} else if($yeni_sifre!=$yeni_sifre_tekrar){

	echo "uyusmayansifre";

} else {

	$hazirla=$db->prepare("UPDATE kullanici set

kullanici_sifre=:kullanici_sifre

where kullanici_id='$kullanici_id'
		");

	$derle=$hazirla->execute(array(

"kullanici_sifre" => htmlspecialchars(md5($yeni_sifre))
	));

	if ($derle) {

setcookie('kullanicioturum',$kullanici_mail,time()+31556926);
		echo "ok";

	} else {

echo "hata";
	}

	
}


} else if (isset($_POST['renkkoduisle'])){


$renk_kodu=$_POST['renkkodu'];
$restoran_id=$_POST['restoran_id'];

$hazirla=$db->prepare("UPDATE restoranlar set

restoran_renk=:restoran_renk

where restoran_id='$restoran_id'
	");


$derle=$hazirla->execute(array(

"restoran_renk" => htmlspecialchars($renk_kodu)

));

if ($derle) {
	
	echo "kodisletamam";
}


} else if (isset($_POST['yemekfotoekle'])){


 $yemek_id=$_POST['yemekidhidden'];
 $name=$_FILES['file']['name'];
$uzanti=ext($_FILES['file']['name']);
$tmp_name=$_FILES['file']['tmp_name'];
$depodosya = 'dimg/yemekfoto';

$image = new SimpleImage();
	$image->load($tmp_name);
	$image->resize(150,150);
	$image->save($tmp_name);

$uniq=uniqid();
$refimgyol=$depodosya."/".$uniq.".".$uzanti;

	$mevcutfotosorgula=$db->prepare("SELECT * from yemekler where yemek_id=:id");
	$mevcutfotosorgula->execute(array(
"id" => $yemek_id
	));

	$mevcutfotocek=$mevcutfotosorgula->fetch(PDO::FETCH_ASSOC);

	$yemek_foto=$mevcutfotocek['yemek_foto'];

	if (!empty($yemek_foto)) {
		
		unlink($yemek_foto);
	}
	

	@move_uploaded_file($tmp_name, "$depodosya/$uniq.$uzanti");

	$hazirla=$db->prepare("UPDATE yemekler set

yemek_foto=:yemek_foto

where yemek_id='$yemek_id'
		");

	$derle=$hazirla->execute(array(
"yemek_foto" => $refimgyol
	));








	 ?>

	                	<div style="position: relative;">

               <a class="yemekfotokaldir" href="javascript:void(0);" name="fotokaldir_<?php echo $yemek_id; ?>"><div style="position: absolute;right: 7px;top:-15px;"><i style="color:#DB3947;font-size: 18px;" class="fas fa-trash-alt"></i></div></a>


<img style="height: 125px;width: 125px;" src="<?php echo $refimgyol; ?>">

</div>
	

<?php 


} else if (isset($_POST['yemekfotokaldir'])){


$yemek_id=$_POST['yemek_id'];

$yemeksec=$db->prepare("SELECT * from yemekler where yemek_id=:id");
$yemeksec->execute(array(
"id" => $yemek_id
));


$yemekcek=$yemeksec->fetch(PDO::FETCH_ASSOC);

$yemek_foto=$yemekcek['yemek_foto'];

$hazirla=$db->prepare("UPDATE yemekler set

yemek_foto=:yemek_foto

where yemek_id='$yemek_id'

	");


$derle=$hazirla->execute(array(

"yemek_foto" => NULL
));


if ($derle) {
	
	unlink($yemek_foto);

	echo "ok";
}

} else if(isset($_POST['generalupdate'])) {

$restoran_ad = htmlspecialchars(trim($_POST['restoran_ad']));
$restoran_seo = seo(tum_bosluk_sil($_POST['restoran_subdomain']));
$restoran_currency=$_POST['restoran_currency'];
$restoran_id=$_POST['restoran_id'];

$subsor=$db->prepare("SELECT * from restoranlar where restoran_seo=:seo");
   $subsor->execute(array(
"seo" => $restoran_seo
   ));

   $restoransec=$db->prepare("SELECT * from restoranlar where restoran_id=:id");
   $restoransec->execute(array(
"id" => $restoran_id
   ));

   $restorancek=$restoransec->fetch(PDO::FETCH_ASSOC);

   $mevcutseo = $restorancek['restoran_seo'];


$subsay=$subsor->rowCount();
 

     if($subsay>0 and ($mevcutseo!=seo(tum_bosluk_sil($restoran_seo)))){

   	echo "mevcutsubdomain";

   } else {

  $hazirla=$db->prepare("UPDATE restoranlar set

restoran_ad=:restoran_ad,
restoran_seo=:restoran_seo,
restoran_currency=:restoran_currency

where restoran_id='$restoran_id'
  	");

  $derle=$hazirla->execute(array(

"restoran_ad" => $restoran_ad,
"restoran_seo" => $restoran_seo,
"restoran_currency" => $restoran_currency
  ));

  if ($derle) {
  	
  	echo "ok";

  } else {

  	echo "hata";
  }

}

 } else if (isset($_POST['menuaciklamagir'])){

$restoran_id=$_POST['restoran_id'];
$menuaciklama=htmlspecialchars(trim($_POST['menuaciklama']));

$hazirla=$db->prepare("UPDATE restoranlar set

restoran_menuaciklama=:restoran_menuaciklama

where restoran_id='$restoran_id'
	");

$derle=$hazirla->execute(array(

"restoran_menuaciklama" => $menuaciklama
));


if ($derle) {
	
	echo "menuaciklamatamam";
}


 } else if(isset($_POST['gecmissipariszamandilimidegistir'])){ ?>

<div style="min-height: 260px;" class="col-sm-12 col-md-12 col-xs-12">

	
<div class="restaurant-list-item-wrapper no-last-bb">

<?php 

$restoran_currency=$_POST['restoran_currency'];
$restoran_id=$_POST['restoran_id'];
$zamandilimi=$_POST['zamandilimi'];
$sayfa=1;  ?>
							
     <?php switch ($zamandilimi) {

     	case 'tumzamanlar':

     	$siparistestsec=$db->prepare("SELECT * from siparisler where restoran_id=:id and siparis_turu=:turu and siparis_bildirim=:bildirim");
    $siparistestsec->execute(array(
      "id" => $restoran_id,
      "bildirim" => 0,
      "turu" => 5
    ));
    $kacar=20;
    $siparistestsay=$siparistestsec->rowCount();
    $sayfasayisi=ceil($siparistestsay/$kacar);
    $baslangic=($kacar*$sayfa)-$kacar;

     		$siparissec=$db->prepare("SELECT * from siparisler where restoran_id=:id and siparis_turu=:turu and siparis_bildirim=:bildirim order by siparis_zaman DESC limit $baslangic,$kacar");

     $siparissec->execute(array(
"id" => $restoran_id,
"turu" => 5,
"bildirim" => 0
     ));

     		break;

     		case 'dun':

     		$duntarih = date('Y-m-d',strtotime("-1 days"));
     		$buguntarih = date("Y-m-d");

     		$siparistestsec=$db->prepare("SELECT * from siparisler where restoran_id=:id and siparis_turu=:turu and siparis_bildirim=:bildirim and siparis_zaman BETWEEN '$duntarih' AND '$buguntarih'");
    $siparistestsec->execute(array(
      "id" => $restoran_id,
      "bildirim" => 0,
      "turu" => 5
    ));
    $kacar=20;
    $siparistestsay=$siparistestsec->rowCount();
    $sayfasayisi=ceil($siparistestsay/$kacar);
    $baslangic=($kacar*$sayfa)-$kacar;

     		$siparissec=$db->prepare("SELECT * from siparisler where restoran_id=:id and siparis_turu=:turu and siparis_bildirim=:bildirim and siparis_zaman BETWEEN '$duntarih' AND '$buguntarih' order by siparis_zaman DESC limit $baslangic,$kacar");

     $siparissec->execute(array(
"id" => $restoran_id,
"turu" => 5,
"bildirim" => 0
     ));

     		break;

     		case 'bugun':

     		$buguntarih = date("Y-m-d");

     		$siparistestsec=$db->prepare("SELECT * from siparisler where restoran_id=:id and siparis_turu=:turu and siparis_bildirim=:bildirim and DATE(siparis_zaman) = '$buguntarih'");
    $siparistestsec->execute(array(
      "id" => $restoran_id,
      "bildirim" => 0,
      "turu" => 5
    ));
    $kacar=20;
    $siparistestsay=$siparistestsec->rowCount();
    $sayfasayisi=ceil($siparistestsay/$kacar);
    $baslangic=($kacar*$sayfa)-$kacar;

     		$siparissec=$db->prepare("SELECT * from siparisler where restoran_id=:id and siparis_turu=:turu and siparis_bildirim=:bildirim and DATE(siparis_zaman) = '$buguntarih' order by siparis_zaman DESC limit $baslangic,$kacar");

     $siparissec->execute(array(
"id" => $restoran_id,
"turu" => 5,
"bildirim" => 0
     ));

     		break;

     		case 'buay':

     		 
     		 $buguntarihay = date("Y-m-01");
     		 $ay1sonra = date("Y-m-01",strtotime("+1 months"));


     	$siparistestsec=$db->prepare("SELECT * from siparisler where restoran_id=:id and siparis_turu=:turu and siparis_bildirim=:bildirim and siparis_zaman BETWEEN '$buguntarihay' AND '$ay1sonra'");

    $siparistestsec->execute(array(
      "id" => $restoran_id,
      "bildirim" => 0,
      "turu" => 5
    ));
    $kacar=20;
    $siparistestsay=$siparistestsec->rowCount();
    $sayfasayisi=ceil($siparistestsay/$kacar);
    $baslangic=($kacar*$sayfa)-$kacar;

     		$siparissec=$db->prepare("SELECT * from siparisler where restoran_id=:id and siparis_turu=:turu and siparis_bildirim=:bildirim and siparis_zaman BETWEEN '$buguntarihay' AND '$ay1sonra' order by siparis_zaman DESC limit $baslangic,$kacar");

     $siparissec->execute(array(
"id" => $restoran_id,
"turu" => 5,
"bildirim" => 0
     ));

     		break;

     		case 'gecenay':

     		 $buguntarihay = date("Y-m-01");
     		 $ay1once = date("Y-m-01",strtotime("-1 months"));

     	$siparistestsec=$db->prepare("SELECT * from siparisler where restoran_id=:id and siparis_turu=:turu and siparis_bildirim=:bildirim and siparis_zaman BETWEEN '$ay1once' and '$buguntarihay'");

    $siparistestsec->execute(array(
      "id" => $restoran_id,
      "bildirim" => 0,
      "turu" => 5
    ));
    $kacar=20;
    $siparistestsay=$siparistestsec->rowCount();
    $sayfasayisi=ceil($siparistestsay/$kacar);
    $baslangic=($kacar*$sayfa)-$kacar;

     		$siparissec=$db->prepare("SELECT * from siparisler where restoran_id=:id and siparis_turu=:turu and siparis_bildirim=:bildirim and siparis_zaman BETWEEN '$ay1once' and '$buguntarihay' order by siparis_zaman DESC limit $baslangic,$kacar");

     $siparissec->execute(array(
"id" => $restoran_id,
"turu" => 5,
"bildirim" => 0
     ));

     		break;

     		case 'buhafta':

     		
     		 $gun7once = date("Y-m-d",strtotime("-7 days"));
     		 $buguntarih = date("Y-m-d");

     	$siparistestsec=$db->prepare("SELECT * from siparisler where restoran_id=:id and siparis_turu=:turu and siparis_bildirim=:bildirim and siparis_zaman BETWEEN '$gun7once' and '$buguntarih'");

    $siparistestsec->execute(array(
      "id" => $restoran_id,
      "bildirim" => 0,
      "turu" => 5
    ));
    $kacar=20;
    $siparistestsay=$siparistestsec->rowCount();
    $sayfasayisi=ceil($siparistestsay/$kacar);
    $baslangic=($kacar*$sayfa)-$kacar;

     		$siparissec=$db->prepare("SELECT * from siparisler where restoran_id=:id and siparis_turu=:turu and siparis_bildirim=:bildirim and siparis_zaman BETWEEN '$gun7once' and '$buguntarih' order by siparis_zaman DESC limit $baslangic,$kacar");

     $siparissec->execute(array(
"id" => $restoran_id,
"turu" => 5,
"bildirim" => 0
     ));

     		break;
     	
     	
     }

$siparissay=$siparissec->rowCount();



if ($siparissay==0) { ?>
	
<h4 align="center">Sipariş bulunamadı.</h4>

<?php } else { ?>

	<h5 align="right"><span style="color:#043d75;"><?php echo $siparistestsay; ?></span> Kayıt Mevcut<hr></h5>

<?php while ($sipariscek=$siparissec->fetch(PDO::FETCH_ASSOC)){  ?>

								

								<div class="restaurant-list-item clearfix">
							
								<div class="GridLex-grid-noGutter-equalHeight">
								
									
									
									<div class="GridLex-col-12_sm-12_xss-12">
									
										<div class="GridLex-grid-noGutter-equalHeight">
										
											<div class="GridLex-col-9_sm-12 content-wrapper">
											
												<div class="content">

													<p style="font-weight: bold; color: #043D75;">Sipariş No: #<?php echo $sipariscek['siparis_no']; ?></p>

													<p style="font-weight: bold; "><i class="fas fa-clock"></i> Sipariş Zamanı: <?php echo substr($sipariscek['siparis_zaman'],11,5); ?></p>
													
													<p style="font-weight: bold;" class="location"><i class="fas fa-chair"></i> <?php echo "Masa No: ".$sipariscek['siparis_masano']; ?> </p>

													<p style="font-weight: bold;"><i class="fas fa-calendar"></i> Sipariş Tarihi: <?php switch (substr($sipariscek['siparis_zaman'],5,2)) {

														case '01':
															echo substr($sipariscek['siparis_zaman'],8,2)." Ocak ".substr($sipariscek['siparis_zaman'],0,4);
															break;

														case '02':
															echo substr($sipariscek['siparis_zaman'],8,2)." Şubat ".substr($sipariscek['siparis_zaman'],0,4);
															break;

															case '03':
															echo substr($sipariscek['siparis_zaman'],8,2)." Mart ".substr($sipariscek['siparis_zaman'],0,4);
															break;

															case '04':
															echo substr($sipariscek['siparis_zaman'],8,2)." Nisan ".substr($sipariscek['siparis_zaman'],0,4);
															break;

															case '05':
															echo substr($sipariscek['siparis_zaman'],8,2)." Mayıs ".substr($sipariscek['siparis_zaman'],0,4);
															break;

															case '06':
															echo substr($sipariscek['siparis_zaman'],8,2)." Haziran ".substr($sipariscek['siparis_zaman'],0,4);
															break;

															case '07':
															echo substr($sipariscek['siparis_zaman'],8,2)." Temmuz ".substr($sipariscek['siparis_zaman'],0,4);
															break;

															case '08':
															echo substr($sipariscek['siparis_zaman'],8,2)." Ağustos ".substr($sipariscek['siparis_zaman'],0,4);
															break;

															case '09':
															echo substr($sipariscek['siparis_zaman'],8,2)." Eylül ".substr($sipariscek['siparis_zaman'],0,4);
															break;

															case '10':
															echo substr($sipariscek['siparis_zaman'],8,2)." Ekim ".substr($sipariscek['siparis_zaman'],0,4);
															break;

															case '11':
															echo substr($sipariscek['siparis_zaman'],8,2)." Kasım ".substr($sipariscek['siparis_zaman'],0,4);
															break;


															case '12':
															echo substr($sipariscek['siparis_zaman'],8,2)." Aralık ".substr($sipariscek['siparis_zaman'],0,4);
															break;
														
													} ?></p>

													<?php if (!empty($sipariscek['ozeltalep'])) { ?>

 														<p style="font-weight: bold;"><i class="fas fa-edit"></i> <?php echo $sipariscek['siparis_ozeltalep']; ?></p>

													<?php } ?>

													
													
													<p class="cuisine"><b>Sipariş:</b> <?php $siparisyemeksec=$db->prepare("SELECT * from siparisyemek where siparis_id=:id and siparisyemek_turu=:turu");
													$siparisyemeksec->execute(array(

														"id" => $sipariscek['siparis_id'],
														"turu" => 5

													));  while ($siparisyemekcek=$siparisyemeksec->fetch(PDO::FETCH_ASSOC)) { 

														$yemeksec=$db->prepare("SELECT * from yemekler where yemek_id=:id");
														$yemeksec->execute(array(

															"id" => $siparisyemekcek['yemek_id']
														));

														$yemekcek=$yemeksec->fetch(PDO::FETCH_ASSOC); ?>
															<span><?php echo $yemekcek['yemek_ad']."<b> x ".$siparisyemekcek['yemek_adet']."</b>"; ?></span>
														<?php } ?> </p>
												</div>
											
											</div>
											
											<div class="GridLex-col-3_sm-12 meta-wrapper">
											
												<div class="meta">
													
													<div class="right-bottom">
														<div class="price">Sipariş Tutarı: <span><?php echo $restoran_currency."".$sipariscek['siparis_tutar']; ?></span></div>
														<div class="clear"></div>
														
													</div>
												</div>
											
											</div>
										
										</div>
										
									</div>
									
								</div>
							
							</div>
 
							<?php } ?>

<?php }  ?>


 

      

						</div>


						<?php if ($siparistestsay>$kacar) { ?>

							<div  class="pagination-wrapper">
						
							<div  class="GridLex-grid-middle GridLex-grid-noGutter">
								
								<div class="GridLex-col-12_sm-12_xs-12">
									<nav>
										<ul class="pagination pagination-text-center-sm mb-5-xs">
											<?php $p=0; if ($sayfa!=1) { ?>
												<li>
												<a href="javascript:void(0);" name='page_<?php echo $sayfa-1; ?>' aria-label="Previous">
													<span aria-hidden="true">&laquo;</span>
												</a>
											</li>
											<?php } ?>
											
											<?php while ($p<$sayfasayisi) { $p++; ?>
												
												<li <?php if ($p==$sayfa) { ?>
													class="active"
												<?php } ?>><a href="javascript:void(0);" name="page_<?php echo $p; ?>"><?php echo $p; ?></a></li>

											<?php } ?>

											<?php if ($sayfa!=$sayfasayisi) { ?>

												<li>
												<a href="javascript:void(0);" name="page_<?php echo $sayfa+1; ?>" aria-label="Next">
													<span aria-hidden="true">&raquo;</span>
												</a>
											</li>
												
											<?php } ?>
											
											
										</ul>
									</nav>

								</div>
							</div>

						</div>
							
						<?php } ?>


						
						

						

						

						
						
					</div>

					<script type="text/javascript">
							$('.pagination li a').click(function(){

var restoran_id = $('#restoran_id').val();
var restoran_currency = $('#restoran_currency').val();
var id1=$(this).attr("name");
 var page=id1.substring(5);
var zamandilimi=$('.zamandegistir').val();
 $('.gecmissiparisler').html('<h3 align="center">Yükleniyor...</h3>');

 $.ajax({
            type : 'POST',
            url : 'ajax.php',
            data : {'restoran_id':restoran_id,'gecmissiparispaginationdegistir':'ok',"restoran_currency":restoran_currency,"zamandilimi":zamandilimi,"page":page},
            success : function(sonuc){

            	sonuc=$.trim(sonuc);
            	 $('.gecmissiparisler').html(sonuc);

            	 }

            	});
							})
						</script>


<?php } else if (isset($_POST['gecmissiparispaginationdegistir'])){ ?>




 
<div style="min-height: 260px;" class="col-sm-12 col-md-12 col-xs-12">

	
<div class="restaurant-list-item-wrapper no-last-bb">

<?php $restoran_currency=$_POST['restoran_currency'];
$restoran_id=$_POST['restoran_id'];
$zamandilimi=$_POST['zamandilimi'];
$sayfa=$_POST['page'];  ?>
							
     <?php switch ($zamandilimi) {

     	case 'tumzamanlar':

     	$siparistestsec=$db->prepare("SELECT * from siparisler where restoran_id=:id and siparis_turu=:turu and siparis_bildirim=:bildirim");
    $siparistestsec->execute(array(
      "id" => $restoran_id,
      "bildirim" => 0,
      "turu" => 5
    ));
    $kacar=20;
    $siparistestsay=$siparistestsec->rowCount();
    $sayfasayisi=ceil($siparistestsay/$kacar);
    $baslangic=($kacar*$sayfa)-$kacar;

     		$siparissec=$db->prepare("SELECT * from siparisler where restoran_id=:id and siparis_turu=:turu and siparis_bildirim=:bildirim order by siparis_zaman DESC limit $baslangic,$kacar");

     $siparissec->execute(array(
"id" => $restoran_id,
"turu" => 5,
"bildirim" => 0
     ));

     		break;

     		case 'dun':

     		$duntarih = date('Y-m-d',strtotime("-1 days"));
     		$buguntarih = date("Y-m-d");

     		$siparistestsec=$db->prepare("SELECT * from siparisler where restoran_id=:id and siparis_turu=:turu and siparis_bildirim=:bildirim and siparis_zaman BETWEEN '$duntarih' AND '$buguntarih'");
    $siparistestsec->execute(array(
      "id" => $restoran_id,
      "bildirim" => 0,
      "turu" => 5
    ));
    $kacar=20;
    $siparistestsay=$siparistestsec->rowCount();
    $sayfasayisi=ceil($siparistestsay/$kacar);
    $baslangic=($kacar*$sayfa)-$kacar;

     		$siparissec=$db->prepare("SELECT * from siparisler where restoran_id=:id and siparis_turu=:turu and siparis_bildirim=:bildirim and siparis_zaman BETWEEN '$duntarih' AND '$buguntarih' order by siparis_zaman DESC limit $baslangic,$kacar");

     $siparissec->execute(array(
"id" => $restoran_id,
"turu" => 5,
"bildirim" => 0
     ));

     		break;

     		case 'bugun':

     		$buguntarih = date("Y-m-d");

     		$siparistestsec=$db->prepare("SELECT * from siparisler where restoran_id=:id and siparis_turu=:turu and siparis_bildirim=:bildirim and DATE(siparis_zaman) = '$buguntarih'");
    $siparistestsec->execute(array(
      "id" => $restoran_id,
      "bildirim" => 0,
      "turu" => 5
    ));
    $kacar=20;
    $siparistestsay=$siparistestsec->rowCount();
    $sayfasayisi=ceil($siparistestsay/$kacar);
    $baslangic=($kacar*$sayfa)-$kacar;

     		$siparissec=$db->prepare("SELECT * from siparisler where restoran_id=:id and siparis_turu=:turu and siparis_bildirim=:bildirim and DATE(siparis_zaman) = '$buguntarih' order by siparis_zaman DESC limit $baslangic,$kacar");

     $siparissec->execute(array(
"id" => $restoran_id,
"turu" => 5,
"bildirim" => 0
     ));

     		break;

     		case 'buay':

     		 
     		 $buguntarihay = date("Y-m-01");
     		 $ay1sonra = date("Y-m-01",strtotime("+1 months"));


     	$siparistestsec=$db->prepare("SELECT * from siparisler where restoran_id=:id and siparis_turu=:turu and siparis_bildirim=:bildirim and siparis_zaman BETWEEN '$buguntarihay' AND '$ay1sonra'");

    $siparistestsec->execute(array(
      "id" => $restoran_id,
      "bildirim" => 0,
      "turu" => 5
    ));
    $kacar=20;
    $siparistestsay=$siparistestsec->rowCount();
    $sayfasayisi=ceil($siparistestsay/$kacar);
    $baslangic=($kacar*$sayfa)-$kacar;

     		$siparissec=$db->prepare("SELECT * from siparisler where restoran_id=:id and siparis_turu=:turu and siparis_bildirim=:bildirim and siparis_zaman BETWEEN '$buguntarihay' AND '$ay1sonra' order by siparis_zaman DESC limit $baslangic,$kacar");

     $siparissec->execute(array(
"id" => $restoran_id,
"turu" => 5,
"bildirim" => 0
     ));

     		break;

     		case 'gecenay':

     		 $buguntarihay = date("Y-m-01");
     		 $ay1once = date("Y-m-01",strtotime("-1 months"));

     	$siparistestsec=$db->prepare("SELECT * from siparisler where restoran_id=:id and siparis_turu=:turu and siparis_bildirim=:bildirim and siparis_zaman BETWEEN '$ay1once' and '$buguntarihay'");

    $siparistestsec->execute(array(
      "id" => $restoran_id,
      "bildirim" => 0,
      "turu" => 5
    ));
    $kacar=20;
    $siparistestsay=$siparistestsec->rowCount();
    $sayfasayisi=ceil($siparistestsay/$kacar);
    $baslangic=($kacar*$sayfa)-$kacar;

     		$siparissec=$db->prepare("SELECT * from siparisler where restoran_id=:id and siparis_turu=:turu and siparis_bildirim=:bildirim and siparis_zaman BETWEEN '$ay1once' and '$buguntarihay' order by siparis_zaman DESC limit $baslangic,$kacar");

     $siparissec->execute(array(
"id" => $restoran_id,
"turu" => 5,
"bildirim" => 0
     ));

     		break;

     		case 'buhafta':

     		
     		 $gun7once = date("Y-m-d",strtotime("-7 days"));
     		 $buguntarih = date("Y-m-d");

     	$siparistestsec=$db->prepare("SELECT * from siparisler where restoran_id=:id and siparis_turu=:turu and siparis_bildirim=:bildirim and siparis_zaman BETWEEN '$gun7once' and '$buguntarih'");

    $siparistestsec->execute(array(
      "id" => $restoran_id,
      "bildirim" => 0,
      "turu" => 5
    ));
    $kacar=20;
    $siparistestsay=$siparistestsec->rowCount();
    $sayfasayisi=ceil($siparistestsay/$kacar);
    $baslangic=($kacar*$sayfa)-$kacar;

     		$siparissec=$db->prepare("SELECT * from siparisler where restoran_id=:id and siparis_turu=:turu and siparis_bildirim=:bildirim and siparis_zaman BETWEEN '$gun7once' and '$buguntarih' order by siparis_zaman DESC limit $baslangic,$kacar");

     $siparissec->execute(array(
"id" => $restoran_id,
"turu" => 5,
"bildirim" => 0
     ));

     		break;
     	
     	
     }

$siparissay=$siparissec->rowCount();



if ($siparissay==0) { ?>
	
<h4 align="center">Sipariş bulunamadı.</h4>

<?php } else { ?>

	<h5 align="right"><span style="color:#043d75;"><?php echo $siparistestsay; ?></span> Kayıt Mevcut<hr></h5>

<?php while ($sipariscek=$siparissec->fetch(PDO::FETCH_ASSOC)){  ?>

								

								<div class="restaurant-list-item clearfix">
							
								<div class="GridLex-grid-noGutter-equalHeight">
								
									
									
									<div class="GridLex-col-12_sm-12_xss-12">
									
										<div class="GridLex-grid-noGutter-equalHeight">
										
											<div class="GridLex-col-9_sm-12 content-wrapper">
											
												<div class="content">

													<p style="font-weight: bold; color: #043D75;">Sipariş No: #<?php echo $sipariscek['siparis_no']; ?></p>

													<p style="font-weight: bold; "><i class="fas fa-clock"></i> Sipariş Zamanı: <?php echo substr($sipariscek['siparis_zaman'],11,5); ?></p>
													
													<p style="font-weight: bold;" class="location"><i class="fas fa-chair"></i> <?php echo "Masa No: ".$sipariscek['siparis_masano']; ?> </p>

													<p style="font-weight: bold;"><i class="fas fa-calendar"></i> Sipariş Tarihi: <?php switch (substr($sipariscek['siparis_zaman'],5,2)) {

														case '01':
															echo substr($sipariscek['siparis_zaman'],8,2)." Ocak ".substr($sipariscek['siparis_zaman'],0,4);
															break;

														case '02':
															echo substr($sipariscek['siparis_zaman'],8,2)." Şubat ".substr($sipariscek['siparis_zaman'],0,4);
															break;

															case '03':
															echo substr($sipariscek['siparis_zaman'],8,2)." Mart ".substr($sipariscek['siparis_zaman'],0,4);
															break;

															case '04':
															echo substr($sipariscek['siparis_zaman'],8,2)." Nisan ".substr($sipariscek['siparis_zaman'],0,4);
															break;

															case '05':
															echo substr($sipariscek['siparis_zaman'],8,2)." Mayıs ".substr($sipariscek['siparis_zaman'],0,4);
															break;

															case '06':
															echo substr($sipariscek['siparis_zaman'],8,2)." Haziran ".substr($sipariscek['siparis_zaman'],0,4);
															break;

															case '07':
															echo substr($sipariscek['siparis_zaman'],8,2)." Temmuz ".substr($sipariscek['siparis_zaman'],0,4);
															break;

															case '08':
															echo substr($sipariscek['siparis_zaman'],8,2)." Ağustos ".substr($sipariscek['siparis_zaman'],0,4);
															break;

															case '09':
															echo substr($sipariscek['siparis_zaman'],8,2)." Eylül ".substr($sipariscek['siparis_zaman'],0,4);
															break;

															case '10':
															echo substr($sipariscek['siparis_zaman'],8,2)." Ekim ".substr($sipariscek['siparis_zaman'],0,4);
															break;

															case '11':
															echo substr($sipariscek['siparis_zaman'],8,2)." Kasım ".substr($sipariscek['siparis_zaman'],0,4);
															break;


															case '12':
															echo substr($sipariscek['siparis_zaman'],8,2)." Aralık ".substr($sipariscek['siparis_zaman'],0,4);
															break;
														
													} ?></p>

													<?php if (!empty($sipariscek['ozeltalep'])) { ?>

 														<p style="font-weight: bold;"><i class="fas fa-edit"></i> <?php echo $sipariscek['siparis_ozeltalep']; ?></p>

													<?php } ?>

													
													
													<p class="cuisine"><b>Sipariş:</b> <?php $siparisyemeksec=$db->prepare("SELECT * from siparisyemek where siparis_id=:id and siparisyemek_turu=:turu");
													$siparisyemeksec->execute(array(

														"id" => $sipariscek['siparis_id'],
														"turu" => 5

													));  while ($siparisyemekcek=$siparisyemeksec->fetch(PDO::FETCH_ASSOC)) { 

														$yemeksec=$db->prepare("SELECT * from yemekler where yemek_id=:id");
														$yemeksec->execute(array(

															"id" => $siparisyemekcek['yemek_id']
														));

														$yemekcek=$yemeksec->fetch(PDO::FETCH_ASSOC); ?>
															<span><?php echo $yemekcek['yemek_ad']."<b> x ".$siparisyemekcek['yemek_adet']."</b>"; ?></span>
														<?php } ?> </p>
												</div>
											
											</div>
											
											<div class="GridLex-col-3_sm-12 meta-wrapper">
											
												<div class="meta">
													
													<div class="right-bottom">
														<div class="price">Sipariş Tutarı: <span><?php echo $restoran_currency."".$sipariscek['siparis_tutar']; ?></span></div>
														<div class="clear"></div>
														
													</div>
												</div>
											
											</div>
										
										</div>
										
									</div>
									
								</div>
							
							</div>
 
							<?php } ?>

<?php }  ?>


 

      

						</div>


						<?php if ($siparistestsay>20) { ?>

							<div  class="pagination-wrapper">
						
							<div  class="GridLex-grid-middle GridLex-grid-noGutter">
								
								<div class="GridLex-col-12_sm-12_xs-12">
									<nav>
										<ul class="pagination pagination-text-center-sm mb-5-xs">
											<?php $p=0; if ($sayfa!=1) { ?>
												<li>
												<a href="javascript:void(0);" name='page_<?php echo $sayfa-1; ?>' aria-label="Previous">
													<span aria-hidden="true">&laquo;</span>
												</a>
											</li>
											<?php } ?>
											
											<?php while ($p<$sayfasayisi) { $p++; ?>
												
												<li <?php if ($p==$sayfa) { ?>
													class="active"
												<?php } ?>><a href="javascript:void(0);" name="page_<?php echo $p; ?>"><?php echo $p; ?></a></li>

											<?php } ?>

											<?php if ($sayfa!=$sayfasayisi) { ?>

												<li>
												<a href="javascript:void(0);" name="page_<?php echo $sayfa+1; ?>" aria-label="Next">
													<span aria-hidden="true">&raquo;</span>
												</a>
											</li>
												
											<?php } ?>
											
											
										</ul>
									</nav>

								</div>
							</div>

						</div>
							
						<?php } ?>


						
						

						

						

						
						
					</div>

					<script type="text/javascript">
							$('.pagination li a').click(function(){

var restoran_id = $('#restoran_id').val();
var restoran_currency = $('#restoran_currency').val();
var id1=$(this).attr("name");
 var page=id1.substring(5);
var zamandilimi=$('.zamandegistir').val();
 $('.gecmissiparisler').html('<h3 align="center">Yükleniyor...</h3>');

 $.ajax({
            type : 'POST',
            url : 'ajax.php',
            data : {'restoran_id':restoran_id,'gecmissiparispaginationdegistir':'ok',"restoran_currency":restoran_currency,"zamandilimi":zamandilimi,"page":page},
            success : function(sonuc){

            	sonuc=$.trim(sonuc);
            	 $('.gecmissiparisler').html(sonuc);

            	 }

            	});
							})
						</script>
      

						



<?php } else if(isset($_POST['gecmisonsipariszamandilimidegistir'])){ ?>

<div style="min-height: 260px;" class="col-sm-12 col-md-12 col-xs-12">

	
<div class="restaurant-list-item-wrapper no-last-bb">

<?php 

$restoran_currency=$_POST['restoran_currency'];
$restoran_id=$_POST['restoran_id'];
$zamandilimi=$_POST['zamandilimi'];
$sayfa=1;  ?>
							
     <?php switch ($zamandilimi) {

     	case 'tumzamanlar':

     	$siparistestsec=$db->prepare("SELECT * from onsiparisler where restoran_id=:id and siparis_turu=:turu and siparis_bildirim=:bildirim");
    $siparistestsec->execute(array(
      "id" => $restoran_id,
      "bildirim" => 0,
      "turu" => 5
    ));
    $kacar=20;
    $siparistestsay=$siparistestsec->rowCount();
    $sayfasayisi=ceil($siparistestsay/$kacar);
    $baslangic=($kacar*$sayfa)-$kacar;

     		$siparissec=$db->prepare("SELECT * from onsiparisler where restoran_id=:id and siparis_turu=:turu and siparis_bildirim=:bildirim order by siparis_zaman DESC limit $baslangic,$kacar");

     $siparissec->execute(array(
"id" => $restoran_id,
"turu" => 5,
"bildirim" => 0
     ));

     		break;

     		case 'dun':

     		$duntarih = date('Y-m-d',strtotime("-1 days"));
     		$buguntarih = date("Y-m-d");

     		$siparistestsec=$db->prepare("SELECT * from onsiparisler where restoran_id=:id and siparis_turu=:turu and siparis_bildirim=:bildirim and siparis_zaman BETWEEN '$duntarih' AND '$buguntarih'");
    $siparistestsec->execute(array(
      "id" => $restoran_id,
      "bildirim" => 0,
      "turu" => 5
    ));
    $kacar=20;
    $siparistestsay=$siparistestsec->rowCount();
    $sayfasayisi=ceil($siparistestsay/$kacar);
    $baslangic=($kacar*$sayfa)-$kacar;

     		$siparissec=$db->prepare("SELECT * from onsiparisler where restoran_id=:id and siparis_turu=:turu and siparis_bildirim=:bildirim and siparis_zaman BETWEEN '$duntarih' AND '$buguntarih' order by siparis_zaman DESC limit $baslangic,$kacar");

     $siparissec->execute(array(
"id" => $restoran_id,
"turu" => 5,
"bildirim" => 0
     ));

     		break;

     		case 'bugun':

     		$buguntarih = date("Y-m-d");

     		$siparistestsec=$db->prepare("SELECT * from onsiparisler where restoran_id=:id and siparis_turu=:turu and siparis_bildirim=:bildirim and DATE(siparis_zaman) = '$buguntarih'");
    $siparistestsec->execute(array(
      "id" => $restoran_id,
      "bildirim" => 0,
      "turu" => 5
    ));
    $kacar=20;
    $siparistestsay=$siparistestsec->rowCount();
    $sayfasayisi=ceil($siparistestsay/$kacar);
    $baslangic=($kacar*$sayfa)-$kacar;

     		$siparissec=$db->prepare("SELECT * from onsiparisler where restoran_id=:id and siparis_turu=:turu and siparis_bildirim=:bildirim and DATE(siparis_zaman) = '$buguntarih' order by siparis_zaman DESC limit $baslangic,$kacar");

     $siparissec->execute(array(
"id" => $restoran_id,
"turu" => 5,
"bildirim" => 0
     ));

     		break;

     		case 'buay':

     		 
     		 $buguntarihay = date("Y-m-01");
     		 $ay1sonra = date("Y-m-01",strtotime("+1 months"));


     	$siparistestsec=$db->prepare("SELECT * from onsiparisler where restoran_id=:id and siparis_turu=:turu and siparis_bildirim=:bildirim and siparis_zaman BETWEEN '$buguntarihay' AND '$ay1sonra'");

    $siparistestsec->execute(array(
      "id" => $restoran_id,
      "bildirim" => 0,
      "turu" => 5
    ));
    $kacar=20;
    $siparistestsay=$siparistestsec->rowCount();
    $sayfasayisi=ceil($siparistestsay/$kacar);
    $baslangic=($kacar*$sayfa)-$kacar;

     		$siparissec=$db->prepare("SELECT * from onsiparisler where restoran_id=:id and siparis_turu=:turu and siparis_bildirim=:bildirim and siparis_zaman BETWEEN '$buguntarihay' AND '$ay1sonra' order by siparis_zaman DESC limit $baslangic,$kacar");

     $siparissec->execute(array(
"id" => $restoran_id,
"turu" => 5,
"bildirim" => 0
     ));

     		break;

     		case 'gecenay':

     		 $buguntarihay = date("Y-m-01");
     		 $ay1once = date("Y-m-01",strtotime("-1 months"));

     	$siparistestsec=$db->prepare("SELECT * from onsiparisler where restoran_id=:id and siparis_turu=:turu and siparis_bildirim=:bildirim and siparis_zaman BETWEEN '$ay1once' and '$buguntarihay'");

    $siparistestsec->execute(array(
      "id" => $restoran_id,
      "bildirim" => 0,
      "turu" => 5
    ));
    $kacar=20;
    $siparistestsay=$siparistestsec->rowCount();
    $sayfasayisi=ceil($siparistestsay/$kacar);
    $baslangic=($kacar*$sayfa)-$kacar;

     		$siparissec=$db->prepare("SELECT * from onsiparisler where restoran_id=:id and siparis_turu=:turu and siparis_bildirim=:bildirim and siparis_zaman BETWEEN '$ay1once' and '$buguntarihay' order by siparis_zaman DESC limit $baslangic,$kacar");

     $siparissec->execute(array(
"id" => $restoran_id,
"turu" => 5,
"bildirim" => 0
     ));

     		break;

     		case 'buhafta':

     		
     		 $gun7once = date("Y-m-d",strtotime("-7 days"));
     		 $buguntarih = date("Y-m-d");

     	$siparistestsec=$db->prepare("SELECT * from onsiparisler where restoran_id=:id and siparis_turu=:turu and siparis_bildirim=:bildirim and siparis_zaman BETWEEN '$gun7once' and '$buguntarih'");

    $siparistestsec->execute(array(
      "id" => $restoran_id,
      "bildirim" => 0,
      "turu" => 5
    ));
    $kacar=20;
    $siparistestsay=$siparistestsec->rowCount();
    $sayfasayisi=ceil($siparistestsay/$kacar);
    $baslangic=($kacar*$sayfa)-$kacar;

     		$siparissec=$db->prepare("SELECT * from onsiparisler where restoran_id=:id and siparis_turu=:turu and siparis_bildirim=:bildirim and siparis_zaman BETWEEN '$gun7once' and '$buguntarih' order by siparis_zaman DESC limit $baslangic,$kacar");

     $siparissec->execute(array(
"id" => $restoran_id,
"turu" => 5,
"bildirim" => 0
     ));

     		break;
     	
     	
     }

$siparissay=$siparissec->rowCount();



if ($siparissay==0) { ?>
	
<h4 align="center">Sipariş bulunamadı.</h4>

<?php } else { ?>

	<h5 align="right"><span style="color:#043d75;"><?php echo $siparistestsay; ?></span> Kayıt Mevcut<hr></h5>

<?php while ($sipariscek=$siparissec->fetch(PDO::FETCH_ASSOC)){  ?>

								

								<div class="restaurant-list-item clearfix">
							
								<div class="GridLex-grid-noGutter-equalHeight">
								
									
									
									<div class="GridLex-col-12_sm-12_xss-12">
									
										<div class="GridLex-grid-noGutter-equalHeight">
										
											<div class="GridLex-col-9_sm-12 content-wrapper">
											
												<div class="content">

													<p style="font-weight: bold; color: #043D75;">Sipariş No: #<?php echo $sipariscek['siparis_no']; ?></p>

													<p style="font-weight: bold; "><i class="fas fa-clock"></i> Sipariş Zamanı: <?php echo substr($sipariscek['siparis_zaman'],11,5); ?></p>
													
													<p style="font-weight: bold;" class="location"><i class="fas fa-chair"></i> <?php echo "Masa No: ".$sipariscek['siparis_masano']; ?> </p>

													<p style="font-weight: bold;"><i class="fas fa-calendar"></i> Sipariş Tarihi: <?php switch (substr($sipariscek['siparis_zaman'],5,2)) {

														case '01':
															echo substr($sipariscek['siparis_zaman'],8,2)." Ocak ".substr($sipariscek['siparis_zaman'],0,4);
															break;

														case '02':
															echo substr($sipariscek['siparis_zaman'],8,2)." Şubat ".substr($sipariscek['siparis_zaman'],0,4);
															break;

															case '03':
															echo substr($sipariscek['siparis_zaman'],8,2)." Mart ".substr($sipariscek['siparis_zaman'],0,4);
															break;

															case '04':
															echo substr($sipariscek['siparis_zaman'],8,2)." Nisan ".substr($sipariscek['siparis_zaman'],0,4);
															break;

															case '05':
															echo substr($sipariscek['siparis_zaman'],8,2)." Mayıs ".substr($sipariscek['siparis_zaman'],0,4);
															break;

															case '06':
															echo substr($sipariscek['siparis_zaman'],8,2)." Haziran ".substr($sipariscek['siparis_zaman'],0,4);
															break;

															case '07':
															echo substr($sipariscek['siparis_zaman'],8,2)." Temmuz ".substr($sipariscek['siparis_zaman'],0,4);
															break;

															case '08':
															echo substr($sipariscek['siparis_zaman'],8,2)." Ağustos ".substr($sipariscek['siparis_zaman'],0,4);
															break;

															case '09':
															echo substr($sipariscek['siparis_zaman'],8,2)." Eylül ".substr($sipariscek['siparis_zaman'],0,4);
															break;

															case '10':
															echo substr($sipariscek['siparis_zaman'],8,2)." Ekim ".substr($sipariscek['siparis_zaman'],0,4);
															break;

															case '11':
															echo substr($sipariscek['siparis_zaman'],8,2)." Kasım ".substr($sipariscek['siparis_zaman'],0,4);
															break;


															case '12':
															echo substr($sipariscek['siparis_zaman'],8,2)." Aralık ".substr($sipariscek['siparis_zaman'],0,4);
															break;
														
													} ?></p>

													<?php if (!empty($sipariscek['ozeltalep'])) { ?>

 														<p style="font-weight: bold;"><i class="fas fa-edit"></i> <?php echo $sipariscek['siparis_ozeltalep']; ?></p>

													<?php } ?>

													
													
													<p class="cuisine"><b>Sipariş:</b> <?php $siparisyemeksec=$db->prepare("SELECT * from onsiparisyemek where siparis_id=:id and siparisyemek_turu=:turu");
													$siparisyemeksec->execute(array(

														"id" => $sipariscek['siparis_id'],
														"turu" => 5

													));  while ($siparisyemekcek=$siparisyemeksec->fetch(PDO::FETCH_ASSOC)) { 

														$yemeksec=$db->prepare("SELECT * from yemekler where yemek_id=:id");
														$yemeksec->execute(array(

															"id" => $siparisyemekcek['yemek_id']
														));

														$yemekcek=$yemeksec->fetch(PDO::FETCH_ASSOC); ?>
															<span><?php echo $yemekcek['yemek_ad']."<b> x ".$siparisyemekcek['yemek_adet']."</b>"; ?></span>
														<?php } ?> </p>
												</div>
											
											</div>
											
											<div class="GridLex-col-3_sm-12 meta-wrapper">
											
												<div class="meta">
													
													<div class="right-bottom">
														<div class="price">Sipariş Tutarı: <span><?php echo $restoran_currency."".$sipariscek['siparis_tutar']; ?></span></div>
														<div class="clear"></div>
														
													</div>
												</div>
											
											</div>
										
										</div>
										
									</div>
									
								</div>
							
							</div>
 
							<?php } ?>

<?php }  ?>


 

      

						</div>


						<?php if ($siparistestsay>20) { ?>

							<div  class="pagination-wrapper">
						
							<div  class="GridLex-grid-middle GridLex-grid-noGutter">
								
								<div class="GridLex-col-12_sm-12_xs-12">
									<nav>
										<ul class="pagination pagination-text-center-sm mb-5-xs">
											<?php $p=0; if ($sayfa!=1) { ?>
												<li>
												<a href="javascript:void(0);" name='page_<?php echo $sayfa-1; ?>' aria-label="Previous">
													<span aria-hidden="true">&laquo;</span>
												</a>
											</li>
											<?php } ?>
											
											<?php while ($p<$sayfasayisi) { $p++; ?>
												
												<li <?php if ($p==$sayfa) { ?>
													class="active"
												<?php } ?>><a href="javascript:void(0);" name="page_<?php echo $p; ?>"><?php echo $p; ?></a></li>

											<?php } ?>

											<?php if ($sayfa!=$sayfasayisi) { ?>

												<li>
												<a href="javascript:void(0);" name="page_<?php echo $sayfa+1; ?>" aria-label="Next">
													<span aria-hidden="true">&raquo;</span>
												</a>
											</li>
												
											<?php } ?>
											
											
										</ul>
									</nav>

								</div>
							</div>

						</div>
							
						<?php } ?>


						
						

						

						

						
						
					</div>

					<script type="text/javascript">
							$('.pagination li a').click(function(){

var restoran_id = $('#restoran_id').val();
var restoran_currency = $('#restoran_currency').val();
var id1=$(this).attr("name");
 var page=id1.substring(5);
var zamandilimi=$('.zamandegistir').val();
 $('.gecmisonsiparisler').html('<h3 align="center">Yükleniyor...</h3>');

 $.ajax({
            type : 'POST',
            url : 'ajax.php',
            data : {'restoran_id':restoran_id,'gecmisonsiparispaginationdegistir':'ok',"restoran_currency":restoran_currency,"zamandilimi":zamandilimi,"page":page},
            success : function(sonuc){

            	sonuc=$.trim(sonuc);
            	 $('.gecmisonsiparisler').html(sonuc);

            	 }

            	});
							})
						</script>



<?php } else if (isset($_POST['gecmisonsiparispaginationdegistir'])){ ?>

<div style="min-height: 260px;" class="col-sm-12 col-md-12 col-xs-12">

	
<div class="restaurant-list-item-wrapper no-last-bb">

<?php $restoran_currency=$_POST['restoran_currency'];
$restoran_id=$_POST['restoran_id'];
$zamandilimi=$_POST['zamandilimi'];
$sayfa=$_POST['page'];  ?>
							
     <?php switch ($zamandilimi) {

     	case 'tumzamanlar':

     	$siparistestsec=$db->prepare("SELECT * from onsiparisler where restoran_id=:id and siparis_turu=:turu and siparis_bildirim=:bildirim");
    $siparistestsec->execute(array(
      "id" => $restoran_id,
      "bildirim" => 0,
      "turu" => 5
    ));
    $kacar=20;
    $siparistestsay=$siparistestsec->rowCount();
    $sayfasayisi=ceil($siparistestsay/$kacar);
    $baslangic=($kacar*$sayfa)-$kacar;

     		$siparissec=$db->prepare("SELECT * from onsiparisler where restoran_id=:id and siparis_turu=:turu and siparis_bildirim=:bildirim order by siparis_zaman DESC limit $baslangic,$kacar");

     $siparissec->execute(array(
"id" => $restoran_id,
"turu" => 5,
"bildirim" => 0
     ));

     		break;

     		case 'dun':

     		$duntarih = date('Y-m-d',strtotime("-1 days"));
     		$buguntarih = date("Y-m-d");

     		$siparistestsec=$db->prepare("SELECT * from onsiparisler where restoran_id=:id and siparis_turu=:turu and siparis_bildirim=:bildirim and siparis_zaman BETWEEN '$duntarih' AND '$buguntarih'");
    $siparistestsec->execute(array(
      "id" => $restoran_id,
      "bildirim" => 0,
      "turu" => 5
    ));
    $kacar=20;
    $siparistestsay=$siparistestsec->rowCount();
    $sayfasayisi=ceil($siparistestsay/$kacar);
    $baslangic=($kacar*$sayfa)-$kacar;

     		$siparissec=$db->prepare("SELECT * from onsiparisler where restoran_id=:id and siparis_turu=:turu and siparis_bildirim=:bildirim and siparis_zaman BETWEEN '$duntarih' AND '$buguntarih' order by siparis_zaman DESC limit $baslangic,$kacar");

     $siparissec->execute(array(
"id" => $restoran_id,
"turu" => 5,
"bildirim" => 0
     ));

     		break;

     		case 'bugun':

     		$buguntarih = date("Y-m-d");

     		$siparistestsec=$db->prepare("SELECT * from onsiparisler where restoran_id=:id and siparis_turu=:turu and siparis_bildirim=:bildirim and DATE(siparis_zaman) = '$buguntarih'");
    $siparistestsec->execute(array(
      "id" => $restoran_id,
      "bildirim" => 0,
      "turu" => 5
    ));
    $kacar=20;
    $siparistestsay=$siparistestsec->rowCount();
    $sayfasayisi=ceil($siparistestsay/$kacar);
    $baslangic=($kacar*$sayfa)-$kacar;

     		$siparissec=$db->prepare("SELECT * from onsiparisler where restoran_id=:id and siparis_turu=:turu and siparis_bildirim=:bildirim and DATE(siparis_zaman) = '$buguntarih' order by siparis_zaman DESC limit $baslangic,$kacar");

     $siparissec->execute(array(
"id" => $restoran_id,
"turu" => 5,
"bildirim" => 0
     ));

     		break;

     		case 'buay':

     		 
     		 $buguntarihay = date("Y-m-01");
     		 $ay1sonra = date("Y-m-01",strtotime("+1 months"));


     	$siparistestsec=$db->prepare("SELECT * from onsiparisler where restoran_id=:id and siparis_turu=:turu and siparis_bildirim=:bildirim and siparis_zaman BETWEEN '$buguntarihay' AND '$ay1sonra'");

    $siparistestsec->execute(array(
      "id" => $restoran_id,
      "bildirim" => 0,
      "turu" => 5
    ));
    $kacar=20;
    $siparistestsay=$siparistestsec->rowCount();
    $sayfasayisi=ceil($siparistestsay/$kacar);
    $baslangic=($kacar*$sayfa)-$kacar;

     		$siparissec=$db->prepare("SELECT * from onsiparisler where restoran_id=:id and siparis_turu=:turu and siparis_bildirim=:bildirim and siparis_zaman BETWEEN '$buguntarihay' AND '$ay1sonra' order by siparis_zaman DESC limit $baslangic,$kacar");

     $siparissec->execute(array(
"id" => $restoran_id,
"turu" => 5,
"bildirim" => 0
     ));

     		break;

     		case 'gecenay':

     		 $buguntarihay = date("Y-m-01");
     		 $ay1once = date("Y-m-01",strtotime("-1 months"));

     	$siparistestsec=$db->prepare("SELECT * from onsiparisler where restoran_id=:id and siparis_turu=:turu and siparis_bildirim=:bildirim and siparis_zaman BETWEEN '$ay1once' and '$buguntarihay'");

    $siparistestsec->execute(array(
      "id" => $restoran_id,
      "bildirim" => 0,
      "turu" => 5
    ));
    $kacar=20;
    $siparistestsay=$siparistestsec->rowCount();
    $sayfasayisi=ceil($siparistestsay/$kacar);
    $baslangic=($kacar*$sayfa)-$kacar;

     		$siparissec=$db->prepare("SELECT * from onsiparisler where restoran_id=:id and siparis_turu=:turu and siparis_bildirim=:bildirim and siparis_zaman BETWEEN '$ay1once' and '$buguntarihay' order by siparis_zaman DESC limit $baslangic,$kacar");

     $siparissec->execute(array(
"id" => $restoran_id,
"turu" => 5,
"bildirim" => 0
     ));

     		break;

     		case 'buhafta':

     		
     		 $gun7once = date("Y-m-d",strtotime("-7 days"));
     		 $buguntarih = date("Y-m-d");

     	$siparistestsec=$db->prepare("SELECT * from onsiparisler where restoran_id=:id and siparis_turu=:turu and siparis_bildirim=:bildirim and siparis_zaman BETWEEN '$gun7once' and '$buguntarih'");

    $siparistestsec->execute(array(
      "id" => $restoran_id,
      "bildirim" => 0,
      "turu" => 5
    ));
    $kacar=20;
    $siparistestsay=$siparistestsec->rowCount();
    $sayfasayisi=ceil($siparistestsay/$kacar);
    $baslangic=($kacar*$sayfa)-$kacar;

     		$siparissec=$db->prepare("SELECT * from onsiparisler where restoran_id=:id and siparis_turu=:turu and siparis_bildirim=:bildirim and siparis_zaman BETWEEN '$gun7once' and '$buguntarih' order by siparis_zaman DESC limit $baslangic,$kacar");

     $siparissec->execute(array(
"id" => $restoran_id,
"turu" => 5,
"bildirim" => 0
     ));

     		break;
     	
     	
     }

$siparissay=$siparissec->rowCount();



if ($siparissay==0) { ?>
	
<h4 align="center">Sipariş bulunamadı.</h4>

<?php } else { ?>

	<h5 align="right"><span style="color:#043d75;"><?php echo $siparistestsay; ?></span> Kayıt Mevcut<hr></h5>

<?php while ($sipariscek=$siparissec->fetch(PDO::FETCH_ASSOC)){  ?>

								

								<div class="restaurant-list-item clearfix">
							
								<div class="GridLex-grid-noGutter-equalHeight">
								
									
									
									<div class="GridLex-col-12_sm-12_xss-12">
									
										<div class="GridLex-grid-noGutter-equalHeight">
										
											<div class="GridLex-col-9_sm-12 content-wrapper">
											
												<div class="content">

													<p style="font-weight: bold; color: #043D75;">Sipariş No: #<?php echo $sipariscek['siparis_no']; ?></p>

													<p style="font-weight: bold; "><i class="fas fa-clock"></i> Sipariş Zamanı: <?php echo substr($sipariscek['siparis_zaman'],11,5); ?></p>
													
													<p style="font-weight: bold;" class="location"><i class="fas fa-chair"></i> <?php echo "Masa No: ".$sipariscek['siparis_masano']; ?> </p>

													<p style="font-weight: bold;"><i class="fas fa-calendar"></i> Sipariş Tarihi: <?php switch (substr($sipariscek['siparis_zaman'],5,2)) {

														case '01':
															echo substr($sipariscek['siparis_zaman'],8,2)." Ocak ".substr($sipariscek['siparis_zaman'],0,4);
															break;

														case '02':
															echo substr($sipariscek['siparis_zaman'],8,2)." Şubat ".substr($sipariscek['siparis_zaman'],0,4);
															break;

															case '03':
															echo substr($sipariscek['siparis_zaman'],8,2)." Mart ".substr($sipariscek['siparis_zaman'],0,4);
															break;

															case '04':
															echo substr($sipariscek['siparis_zaman'],8,2)." Nisan ".substr($sipariscek['siparis_zaman'],0,4);
															break;

															case '05':
															echo substr($sipariscek['siparis_zaman'],8,2)." Mayıs ".substr($sipariscek['siparis_zaman'],0,4);
															break;

															case '06':
															echo substr($sipariscek['siparis_zaman'],8,2)." Haziran ".substr($sipariscek['siparis_zaman'],0,4);
															break;

															case '07':
															echo substr($sipariscek['siparis_zaman'],8,2)." Temmuz ".substr($sipariscek['siparis_zaman'],0,4);
															break;

															case '08':
															echo substr($sipariscek['siparis_zaman'],8,2)." Ağustos ".substr($sipariscek['siparis_zaman'],0,4);
															break;

															case '09':
															echo substr($sipariscek['siparis_zaman'],8,2)." Eylül ".substr($sipariscek['siparis_zaman'],0,4);
															break;

															case '10':
															echo substr($sipariscek['siparis_zaman'],8,2)." Ekim ".substr($sipariscek['siparis_zaman'],0,4);
															break;

															case '11':
															echo substr($sipariscek['siparis_zaman'],8,2)." Kasım ".substr($sipariscek['siparis_zaman'],0,4);
															break;


															case '12':
															echo substr($sipariscek['siparis_zaman'],8,2)." Aralık ".substr($sipariscek['siparis_zaman'],0,4);
															break;
														
													} ?></p>

													<?php if (!empty($sipariscek['ozeltalep'])) { ?>

 														<p style="font-weight: bold;"><i class="fas fa-edit"></i> <?php echo $sipariscek['siparis_ozeltalep']; ?></p>

													<?php } ?>

													
													
													<p class="cuisine"><b>Sipariş:</b> <?php $siparisyemeksec=$db->prepare("SELECT * from siparisyemek where siparis_id=:id and siparisyemek_turu=:turu");
													$siparisyemeksec->execute(array(

														"id" => $sipariscek['siparis_id'],
														"turu" => 5

													));  while ($siparisyemekcek=$siparisyemeksec->fetch(PDO::FETCH_ASSOC)) { 

														$yemeksec=$db->prepare("SELECT * from yemekler where yemek_id=:id");
														$yemeksec->execute(array(

															"id" => $siparisyemekcek['yemek_id']
														));

														$yemekcek=$yemeksec->fetch(PDO::FETCH_ASSOC); ?>
															<span><?php echo $yemekcek['yemek_ad']."<b> x ".$siparisyemekcek['yemek_adet']."</b>"; ?></span>
														<?php } ?> </p>
												</div>
											
											</div>
											
											<div class="GridLex-col-3_sm-12 meta-wrapper">
											
												<div class="meta">
													
													<div class="right-bottom">
														<div class="price">Sipariş Tutarı: <span><?php echo $restoran_currency."".$sipariscek['siparis_tutar']; ?></span></div>
														<div class="clear"></div>
														
													</div>
												</div>
											
											</div>
										
										</div>
										
									</div>
									
								</div>
							
							</div>
 
							<?php } ?>

<?php }  ?>


 

      

						</div>


						<?php if ($siparistestsay>20) { ?>

							<div  class="pagination-wrapper">
						
							<div  class="GridLex-grid-middle GridLex-grid-noGutter">
								
								<div class="GridLex-col-12_sm-12_xs-12">
									<nav>
										<ul class="pagination pagination-text-center-sm mb-5-xs">
											<?php $p=0; if ($sayfa!=1) { ?>
												<li>
												<a href="javascript:void(0);" name='page_<?php echo $sayfa-1; ?>' aria-label="Previous">
													<span aria-hidden="true">&laquo;</span>
												</a>
											</li>
											<?php } ?>
											
											<?php while ($p<$sayfasayisi) { $p++; ?>
												
												<li <?php if ($p==$sayfa) { ?>
													class="active"
												<?php } ?>><a href="javascript:void(0);" name="page_<?php echo $p; ?>"><?php echo $p; ?></a></li>

											<?php } ?>

											<?php if ($sayfa!=$sayfasayisi) { ?>

												<li>
												<a href="javascript:void(0);" name="page_<?php echo $sayfa+1; ?>" aria-label="Next">
													<span aria-hidden="true">&raquo;</span>
												</a>
											</li>
												
											<?php } ?>
											
											
										</ul>
									</nav>

								</div>
							</div>

						</div>
							
						<?php } ?>


						
						

						

						

						
						
					</div>

					<script type="text/javascript">
							$('.pagination li a').click(function(){

var restoran_id = $('#restoran_id').val();
var restoran_currency = $('#restoran_currency').val();
var id1=$(this).attr("name");
 var page=id1.substring(5);
var zamandilimi=$('.zamandegistir').val();
 $('.gecmisonsiparisler').html('<h3 align="center">Yükleniyor...</h3>');

 $.ajax({
            type : 'POST',
            url : 'ajax.php',
            data : {'restoran_id':restoran_id,'gecmisonsiparispaginationdegistir':'ok',"restoran_currency":restoran_currency,"zamandilimi":zamandilimi,"page":page},
            success : function(sonuc){

            	sonuc=$.trim(sonuc);
            	 $('.gecmisonsiparisler').html(sonuc);

            	 }

            	});
							})
						</script>
      

<?php } ?>


 	


		
			


			
			

			
			
		



 

	
 