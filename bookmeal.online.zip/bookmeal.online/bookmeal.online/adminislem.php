<?php 

ob_start();
session_start();

if (empty($_POST) and empty($_GET)) {
	
	header("Location:/");
	exit;
}


require_once 'baglann.php';
include 'fonksiyon.php';
include('SimpleImage.php');

 $ip_adresi=$_SERVER['REMOTE_ADDR'];
 date_default_timezone_set('Europe/Istanbul');
/*$query=@unserialize(file_get_contents('http://ip-api.com/php/'.$ip_adresi));

 if($query && $query['status']=='success'){
    
     $timezone=$query['timezone'];
      date_default_timezone_set($timezone);
      
      
} else {
    
    date_default_timezone_set('America/Los_Angeles');
} */

 //Restoran onaylama----------- 

 if ($_GET['restoranonayla']=="ok") {
 	
 	engelle();
 	$restoran_id=$_GET['restoran_id'];

 	$kullanicisec=$db->prepare("SELECT * from kullanici where restoran_id=:id");
 	$kullanicisec->execute(array(
"id" => $restoran_id
 	));

 	$kullanicicek=$kullanicisec->fetch(PDO::FETCH_ASSOC);

 	$kullanici_id=$kullanicicek['kullanici_id'];
 	$kullanici_mail=$kullanicicek['kullanici_mail'];

 	$hazirla=$db->prepare("UPDATE restoranlar set

restoran_adminonay=:restoran_adminonay

where restoran_id='$restoran_id'
 		");

 	$derle=$hazirla->execute(array(
"restoran_adminonay" => "yes"
 	));

$hazirla=$db->prepare("UPDATE kullanici set

kullanici_adminonay=:kullanici_adminonay
where restoran_id='$restoran_id'
 		");

 	$derle=$hazirla->execute(array(
"kullanici_adminonay" => "yes"
 	));


 require("phpmailer/class/class.phpmailer.php");

	$mail = new PHPMailer(); // Sinifimizi $mail degiskenine atadik
 $mail->CharSet  ="utf-8";
 $mail->Encoding="base64";
$mail->IsSMTP();  // Mailimizin SMTP ile gönderilecegini belirtiyoruz
$mail->Host     = "smtpout.secureserver.net";//"localhost"; //SMTP server adresi
$mail->Port     = '80'; 
$mail->SMTPAuth = true; //SMTP server'a kullanici adi ile baglanilcagini belirtiyoruz.
$mail->Username = "help@bookmeal.online";//"admin@localhost"; //SMTP kullanici adi
$mail->Password = "386Emirhan.";//""; //SMTP mailinizin sifresi
$mail->SMTPSecure = 'SSL';
$mail->From     = 'help@bookmeal.online';//"admin@localhost"; //Gönderen kisminda yer alacak e-mail adresi
$mail->FromName = 'Bookmeal';//"PHP Mailer";//gönderenin ismi
$mail->AddAddress($kullanici_mail); // Mail gönderilecek adresleri ekliyoruz.
$mail->IsHTML(true); //Mailimizin HTML formatinda hazirlanacagini bildiriyoruz.
$mail->Subject  = 'You are ready to start!';//"Deneme Maili"; // Mailin Konusu Konu


	$mail->Body = '<div align="center" style="width:100%;height:100px;"><div  align="center" style="height:100px;width:100%;background-color:#043D75;padding-top:15px;padding-bottom:15px;"><h3>Welcome to Bookmeal!</h3><hr><h4>You are ready to talk about your new service to your customers. There are couple of way for it. Please read out guide that contain suggestions about how to manage your system!</h4><a href="www.bookmeal.online"><button class="btn" style="background-color:#3346FF;color:white;width:50%;height:30px;">Lets Start!</button></a></div></div>';
	
 $mail->Send();

 header('Location:nedmin/production/restoran-onay?islem=basarili');


 }

 //---Restoran Reddet------------------


 if ($_GET['restoranreddet']=="ok") {

 	engelle();
 	 $restoran_id=$_GET['restoran_id'];

 	 $kullanicisec=$db->prepare("SELECT * from kullanici where restoran_id=:id");
 	 $kullanicisec->execute(array(
"id" => $restoran_id
 	 ));

 	 $kullanicicek=$kullanicisec->fetch(PDO::FETCH_ASSOC);
 	 $kullanici_mail=$kullanicicek['kullanici_mail'];

 	 $restoransil=$db->prepare("DELETE from restoranlar where restoran_id=:id");
    $restoransil->execute(array(
"id" => $restoran_id
    ));

    $kullanicisil=$db->prepare("DELETE from kullanici where restoran_id=:id");
    $kullanicisil->execute(array(
"id" => $restoran_id
    ));


    $menucesitsil=$db->prepare("DELETE from restoranmenucesit where restoran_id=:id");
    $menucesitsil->execute(array(
"id" => $restoran_id
    ));

    $yemeksil=$db->prepare("DELETE from yemekler where restoran_id=:id");
    $yemeksil->execute(array(
"id" => $restoran_id

  ));

    require("phpmailer/class/class.phpmailer.php");

	$mail = new PHPMailer(); // Sinifimizi $mail degiskenine atadik
 $mail->CharSet  ="utf-8";
 $mail->Encoding="base64";
$mail->IsSMTP();  // Mailimizin SMTP ile gönderilecegini belirtiyoruz
$mail->Host     = "smtpout.secureserver.net";//"localhost"; //SMTP server adresi
$mail->Port     = '80'; 
$mail->SMTPAuth = true; //SMTP server'a kullanici adi ile baglanilcagini belirtiyoruz.
$mail->Username = "help@bookmeal.online";//"admin@localhost"; //SMTP kullanici adi
$mail->Password = "386Emirhan.";//""; //SMTP mailinizin sifresi
$mail->SMTPSecure = 'SSL';
$mail->From     = 'help@bookmeal.online';//"admin@localhost"; //Gönderen kisminda yer alacak e-mail adresi
$mail->FromName = 'Bookmeal';//"PHP Mailer";//gönderenin ismi
$mail->AddAddress($kullanici_mail); // Mail gönderilecek adresleri ekliyoruz.
$mail->IsHTML(true); //Mailimizin HTML formatinda hazirlanacagini bildiriyoruz.
$mail->Subject  = 'Application has denied.';//"Deneme Maili"; // Mailin Konusu Konu


	$mail->Body = '<div align="center" style="width:100%;height:100px;"><div  align="center" style="height:100px;width:100%;background-color:#043D75;padding-top:15px;padding-bottom:15px;"><h3>Application is denied</h3><hr><h4>We examine your application and we denied. Please try again. Thank you.</h4><a href="www.bookmeal.online/restaurant-submit"><button class="btn" style="background-color:#3346FF;color:white;width:50%;height:30px;">Try Again</button></a></div></div>';

	$mail->Send();

	header('Location:nedmin/production/restoran-onay?islem=basarili');


    


 	
 	

 }


 // Admin login işlemleri----------------------


if (isset($_POST['admingiris'])) {
	
	$admin_mail=$_POST['admin_mail'];
	$admin_sifre=$_POST['admin_sifre'];



 	$adminsec=$db->prepare("SELECT * from admin where admin_sifre=:sifre and admin_mail=:mail");
 	$adminsec->execute(array(


"mail" => $admin_mail,
"sifre" => md5($admin_sifre)

 	));

 	$kayitsay=$adminsec->rowCount();

 	if ($kayitsay==1) {
 		
$_SESSION['admin_oturum']=$admin_mail;
Header("Location:nedmin/production");
exit;

 	} else {


Header("Location:nedmin/production/login?girisdurum=no");
exit;


}

 }

 //Blog yazısı Ekleme İşlemleri------


 if (isset($_POST['blogekle'])) {
 	
 	$blog_baslik=$_POST['blog_baslik'];
 	$blog_text=$_POST['blog_text'];
 	$blog_seo=seo($blog_baslik);

 	$depodosya = 'dimg/blogfoto';

 	$uzanti= ext($_FILES['blog_foto']['name']);
		
	

		$tmp_name = $_FILES['blog_foto']["tmp_name"];
 				 
 				 	 $name= $_FILES['blog_foto']["name"];


	
	$image = new SimpleImage();
	$image->load($tmp_name);
	$image->resize(600,400);
	$image->save($tmp_name);

    
	$uniq=uniqid(); 
	$refimgyol=$depodosya."/".$uniq.".".$uzanti;

	
	@move_uploaded_file($tmp_name, "$depodosya/$uniq.$uzanti");	

 	
 	

 	$hazirla=$db->prepare("INSERT into bloglar set

blog_baslik=:blog_baslik,
blog_text=:blog_text,
blog_foto=:blog_foto,
blog_seo=:blog_seo


 		");

 	$derle=$hazirla->execute(array(

"blog_baslik" => htmlspecialchars($blog_baslik),
"blog_text" => $blog_text,
"blog_foto" => $refimgyol,
"blog_seo" => $blog_seo

 	));


	

 	
 }

 // Restoran ekleme işlemleri----------


 if (isset($_POST['restoranekle'])) {

 	//Önce genel özellikleri kaydedelim


										
  $restoran_ad=$_POST['restoran_ad'];
  $restoran_adres=$_POST['restoran_adres'];
 $restoran_seo=$_POST['restoran_seo'];
  $restoran_pazartesiacilis=$_POST['restoran_pazartesiacilis'];
 $restoran_pazartesikapanis=$_POST['restoran_pazartesikapanis'];
  $restoran_saliacilis=$_POST['restoran_saliacilis'];
 $restoran_salikapanis=$_POST['restoran_salikapanis'];
  $restoran_carsambaacilis=$_POST['restoran_carsambaacilis'];
 $restoran_carsambakapanis=$_POST['restoran_carsambakapanis'];
  $restoran_persembeacilis=$_POST['restoran_persembeacilis'];
 $restoran_persembekapanis=$_POST['restoran_persembekapanis'];
  $restoran_cumaacilis=$_POST['restoran_cumaacilis'];
 $restoran_cumakapanis=$_POST['restoran_cumakapanis'];
  $restoran_cumartesiacilis=$_POST['restoran_cumartesiacilis'];
 $restoran_cumartesikapanis=$_POST['restoran_cumartesikapanis'];
  $restoran_pazaracilis=$_POST['restoran_pazaracilis'];
 $restoran_pazarkapanis=$_POST['restoran_pazarkapanis'];
 $kullanici_mail=$_POST['kullanici_mail'];
 $kullanici_sifre=md5(htmlspecialchars(trim($_POST['kullanici_sifre'])));
 $kullanici_mail=htmlspecialchars(trim($_POST['kullanici_mail']));


 
 


  $uzanti=strtolower(substr($_FILES['restoran_kapakfoto']['name'],strpos($_FILES['restoran_kapakfoto']['name'],".")+1));

  $izinli_uzantilar=array('jpg','png','jpeg');

 			

 			if (in_array($uzanti,$izinli_uzantilar)) {




 				 $depodosya = 'dimg/restorankapak';

 				 $tmp_name = $_FILES['restoran_kapakfoto']["tmp_name"]; //Resim karşıdan yüklendiğinde önbelleğe kaydedilir.

 				 	 $name = $_FILES['restoran_kapakfoto']["name"]; //Bu da resmin ismidir. seo dan geçirererek türkçe karakterleri engelledik.


	include('SimpleImage.php');
	$image = new SimpleImage();
	$image->load($tmp_name);
	$image->resize(1920,780);
	$image->save($tmp_name);


	$uniq=uniqid(); //Benzersiz sayı oluşturur.
	$refimgyol=$depodosya."/".$uniq.".".$uzanti; //Klasörü kaydederken aynı zamanda klasörün ismini veritabanına istediğimiz şekilde gönderiyoruz. Daha sonra istediğimiz yerden istediğimiz şekilde sessionlarla veya normal şekilde bu resmi çekebiliriz.

	@move_uploaded_file($tmp_name, "$depodosya/$uniq.$uzanti"); //burada dosyayı al, belirttiğimiz klasöre kaydet diyoruz.

	$hazirla=$db->prepare("INSERT into restoranlar set 

restoran_ad=:restoran_ad,
restoran_seo=:restoran_seo,
restoran_adres=:restoran_adres,
restoran_kapakfoto=:restoran_kapakfoto,
restoran_wifi=:restoran_wifi,
restoran_vale=:restoran_vale,
restoran_sigaraicmealan=:restoran_sigaraicmealan,
restoran_icmekan=:restoran_icmekan,
restoran_dismekan=:restoran_dismekan,
restoran_pazartesiacilis=:restoran_pazartesiacilis,
restoran_pazartesikapanis=:restoran_pazartesikapanis,
restoran_saliacilis=:restoran_saliacilis,
restoran_salikapanis=:restoran_salikapanis,
restoran_carsambaacilis=:restoran_carsambaacilis,
restoran_carsambakapanis=:restoran_carsambakapanis,
restoran_persembeacilis=:restoran_persembeacilis,
restoran_persembekapanis=:restoran_persembekapanis,
restoran_cumaacilis=:restoran_cumaacilis,
restoran_cumakapanis=:restoran_pazartesikapanis,
restoran_cumartesiacilis=:restoran_cumartesiacilis,
restoran_cumartesikapanis=:restoran_cumartesikapanis,
restoran_pazaracilis=:restoran_pazaracilis,
restoran_pazarkapanis=:restoran_pazarkapanis
		");

	$derle=$hazirla->execute(array(
"restoran_ad" => htmlspecialchars($restoran_ad),
"restoran_seo" => htmlspecialchars($restoran_seo),
"restoran_adres" => htmlspecialchars($restoran_adres),
"restoran_kapakfoto" => $refimgyol,
"restoran_wifi" => $_POST['wifi'],
"restoran_vale" => $_POST['vale'],
"restoran_sigaraicmealan" => $_POST['sigaraicmealan'],
"restoran_icmekan" => $_POST['icmekan'],
"restoran_dismekan" => $_POST['dismekan'],
"restoran_pazartesiacilis" => $restoran_pazartesiacilis,
"restoran_pazartesikapanis" => $restoran_pazartesikapanis,
"restoran_saliacilis" => $restoran_saliacilis,
"restoran_salikapanis" => $restoran_salikapanis,
"restoran_carsambaacilis" => $restoran_carsambaacilis,
"restoran_carsambakapanis" => $restoran_carsambakapanis,
"restoran_persembeacilis" => $restoran_persembeacilis,
"restoran_persembekapanis" => $restoran_persembekapanis,
"restoran_cumaacilis" => $restoran_cumaacilis,
"restoran_cumakapanis" => $restoran_cumakapanis,
"restoran_cumartesiacilis" => $restoran_cumartesiacilis,
"restoran_cumartesikapanis" => $restoran_cumartesikapanis,
"restoran_pazaracilis" => $restoran_pazaracilis,
"restoran_pazarkapanis" => $restoran_pazarkapanis
	));


	
//------------------- Şimdi menüyü kaydedelim ------------

	

if ($derle) {

	$restoranidsec=$db->prepare("SELECT * from restoranlar where restoran_seo=:seo");
	$restoranidsec->execute(array(
"seo" => $restoran_seo
	));

	$restoranidcek=$restoranidsec->fetch(PDO::FETCH_ASSOC);

	 $restoran_id=$restoranidcek['restoran_id'];
	

	$x=0;

while ($x<40) {
	
	$x++;

	if (!empty($_POST['yemek_ad'.$x])) {



		$yemek_ad=$_POST['yemek_ad'.$x];
		$yemek_fiyat=$_POST['yemek_fiyat'.$x];
		$yemek_aciklama=$_POST['yemek_aciklama'.$x];
		 $yemek_cesit=$_POST['yemek_cesit'.$x];


         $restoranmenucesitsec=$db->prepare("SELECT * from restoranmenucesit where restoran_id=:restoranid and cesit_id=:cesitid");
		 $restoranmenucesitsec->execute(array(

      "restoranid" => $restoran_id,
      "cesitid" => $yemek_cesit
		));

		$restoranmenucesitsay=$restoranmenucesitsec->rowCount();

		if ($restoranmenucesitsay==0) {

			$cesitsec=$db->prepare("SELECT * from menucesit where cesit_id=:id");
			$cesitsec->execute(array(
"id" => $yemek_cesit
			));

			$cesitcek=$cesitsec->fetch(PDO::FETCH_ASSOC);

			 $cesit_ad=$cesitcek['cesit_ad']; 
			
			$hazirla2=$db->prepare("INSERT into restoranmenucesit set

restoran_id=:restoran_id,
cesit_id=:cesit_id,
cesit_ad=:cesit_ad
				");

			$derle2=$hazirla2->execute(array(

"restoran_id" => $restoran_id,
"cesit_id" => $yemek_cesit,
"cesit_ad" => $cesit_ad
			));
		}



	$hazirla=$db->prepare("INSERT into yemekler set

yemek_ad=:yemek_ad,
yemek_fiyat=:yemek_fiyat,
yemek_aciklama=:yemek_aciklama,
yemek_cesit=:yemek_cesit,
restoran_id=:restoran_id


			");

		$derle=$hazirla->execute(array(
"yemek_ad" => $yemek_ad,
"yemek_fiyat" => $yemek_fiyat,
"yemek_aciklama" => $yemek_aciklama,
"yemek_cesit" => $yemek_cesit,
"restoran_id" => $restoran_id
		));

		
		
	} 

}



	
	

}

//------- Şimdi de restoran admin i tanımlayalım-----------

$hazirladmin=$db->prepare("INSERT into kullanici set

kullanici_mail=:kullanici_mail,
kullanici_sifre=:kullanici_sifre,
kullanici_yetki=:kullanici_yetki,
restoran_id=:restoran_id
	");

$derleadmin=$hazirladmin->execute(array(
"kullanici_mail" => $kullanici_mail,
"kullanici_sifre" => $kullanici_sifre,
"kullanici_yetki" => 5,
"restoran_id" => $restoran_id
));


header("Location:nedmin/production/restoranekle");


	

 			} 

 			

 			

									}










 ?>