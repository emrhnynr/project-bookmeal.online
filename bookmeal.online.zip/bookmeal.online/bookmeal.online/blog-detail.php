<?php require_once 'header.php'; ?>

<style type="text/css">
	p,li {
		font-size:17px;
	}

	h1,h2,h3,h4,h5,h6 {

		color:#043D75;
	}
</style>

<?php  

$blogsec=$db->prepare("SELECT * from bloglar where blog_id=:id");
$blogsec->execute(array(
"id" => $_GET['blog_id']
));

$blogsay=$blogsec->rowCount();

if ($blogsay==0) {
	
	header("Location:/");
	exit;
}

$blogcek=$blogsec->fetch(PDO::FETCH_ASSOC);
?>

<title><?php echo $blogcek['blog_baslik']; ?></title>

		<div style='background-color:#fff;' class="main-wrapper scrollspy-container">
		
			<!-- start hero-header -->
			

			<div class="container pt-10 pb-60">
			
				<div class="breadcrumb-wrapper">
					<ol class="breadcrumb">
						<li><a href="/">Anasayfa</a></li>
						<li class="active">Blog</li>
						<li class="active"><?php echo $blogcek['blog_baslik']; ?></li>
					</ol>
				</div>
						
				<div class="mt-40">
				
					<div class="row">

						<div class="col-sm-8 col-md-9 col-xs-12 mb-50-xs">
				
							<div class="blog-single-wrapper">
							
								<div class="heading">
								
									<h3><?php echo $blogcek['blog_baslik']; ?></h3>
									
									
									
								</div>
								
								<div class="content blog-entry">
									
									<img src="<?php echo $blogcek['blog_foto']; ?>" alt="image" />
								
									<?php echo $blogcek['blog_text']; ?>
									
								</div>
								
								
								
							</div>
							
							
							
									
							
							
							

							
							

						</div>
						
						<div class="col-sm-4 col-md-3 col-xs-12">
						
							<aside class="sidebar-wrapper for-blog">
							
								
								<?php $latestblogsec=$db->prepare("SELECT * from bloglar order by blog_id DESC");
								$latestblogsec->execute();

								 ?>
								
								
								<div class="section-title-02">
									<h4><span>Son Gönderiler</span></h4>
								</div>
								
								<div class="sidebar-module clearfix">
									
									<ul class="sidebar-post">

										<?php while ($latestblogcek=$latestblogsec->fetch(PDO::FETCH_ASSOC)) { if ($latestblogcek['blog_id']!= $_GET['blog_id']) { ?>
											


										<li class="clearfix">
											<a href="blog-<?php echo $latestblogcek['blog_seo']."-".$latestblogcek['blog_id']; ?>">
												<div class="image">
													<img src="<?php echo $latestblogcek['blog_foto']; ?>" alt="Popular Post" />
												</div>
												<div class="content">
													<h6><?php echo $latestblogcek['blog_baslik']; ?></h6>
													
												</div>
											</a>
										</li>
											

										<?php } } ?>
										
										
									</ul>
								
									
								</div>
							
								

								
							</aside>

						</div>
						
					</div>

				</div>
				
			</div>
			
		</div>
		<!-- end Main Wrapper -->
		
		<?php require_once 'footer.php'; ?>