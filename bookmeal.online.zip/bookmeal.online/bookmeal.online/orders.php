
<?php require_once 'header.php'; 

if ($kullanicioturumcek['kullanici_yetki']!=1) {
	
	header("Location:/");
	exit;
};

 $sipariskontrolsec=$db->prepare("SELECT * from onsiparisler where kullanici_id=:id and siparis_bildirim=:bildirim and siparis_turu=:turu");
$sipariskontrolsec->execute(array(
"bildirim" => 1,
"id" => $_COOKIE['kullanici_id'],
"turu" => 1
));

  $sipariskontrolsay=$sipariskontrolsec->rowCount();

 if ($sipariskontrolsay!=0) {
 	
 	while ($sipariskontrolcek=$sipariskontrolsec->fetch(PDO::FETCH_ASSOC)) {

 		 $sipariskontrol_id=$sipariskontrolcek['siparis_id'];
 		
 		if (date('Y-m-d H:i:s')>$sipariskontrolcek['siparis_kaybolmazaman']) {
 			
 			$hazirlaupdate=$db->prepare("UPDATE onsiparisler set 

siparis_bildirim=:siparis_bildirim,
siparis_variszaman=:siparis_variszaman,
siparis_kaybolmazaman=:siparis_kaybolmazaman

where siparis_id='$sipariskontrol_id'
 				");

 			$derleupdate=$hazirlaupdate->execute(array(

"siparis_bildirim" => 0,
"siparis_variszaman" => NULL,
"siparis_kaybolmazaman" => NULL
 			));

 			//----------------------


$hazirla2update=$db->prepare("UPDATE onsiparisler set 

siparis_bildirim=:siparis_bildirim,
siparis_variszaman=:siparis_variszaman,
siparis_kaybolmazaman=:siparis_kaybolmazaman

where siparis_no='$sipariskontrol_id'
 				");

 			$derle2update=$hazirla2update->execute(array(

"siparis_bildirim" => 0,
"siparis_variszaman" => NULL,
"siparis_kaybolmazaman" => NULL
 			));

 		}
 	}
 } 

?>

<title>Siparişlerim</title>

<style type="text/css">
	

.hero::before {
    position: absolute;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    content: "";
    background: rgba(0, 0, 0, 0.4);
}

</style>




		
		<!-- start Main Wrapper -->
		<div class="main-wrapper scrollspy-container">
		
			<!-- start hero-header -->
			<div class="hero hero-sm" style="background-image:url('images/hero-header/girisfoto.jpg'); height: 200px;">
		
				
			</div>

			
			<!-- end hero-header -->

<div class="container pt-10 pb-30">
	

			
				<?php if ($_GET['saveorder']=='success') { ?>

							<div class="alert alert-success alert-icon">
						
							<i class="fa fa-check-circle"></i>
							
							<h4>Rezervasyon başarılı</h4>
						
						</div>

						<?php }  else if($_GET['siparissil']=="ok"){ ?>

<div class="alert alert-success alert-icon">
						
							<i class="fa fa-check-circle"></i>
							
							<h4>Sipariş silindi</h4>
						
						</div>
						<?php } ?>
				
				<div class="row mb-10">
				
					<div class="col-md-8">
					
						<div class="section-title-02">


							<?php $devamedensiparissec=$db->prepare("SELECT * from onsiparisler where kullanici_id=:id and siparis_turu=:turu and siparis_bildirim=:bildirim");
							$devamedensiparissec->execute(array(
"turu" => 1,
"id" => $_COOKIE['kullanici_id'],
"bildirim" => 1
							));


							$devamedensiparissay=$devamedensiparissec->rowCount();

							
					 ?>

							<h3><span>Devam eden siparişlerim</span></h3>

						
						</div>
					</div>
					
				</div>
						
				<div class="row">


				
					
					
					<div class="col-sm-12 col-md-12 col-xs-12">


						
						

						<div style="min-height: 190px;" class="restaurant-list-item-wrapper no-last-bb">
							
							<?php if ($devamedensiparissay==0) { ?>

								<h5 align="center">Devam eden sipariş bulunamadı.</h5>
								
							<?php } else { ?>



							<?php while($devamedensipariscek=$devamedensiparissec->fetch(PDO::FETCH_ASSOC)){ 

								$restoransec=$db->prepare("SELECT * from restoranlar where restoran_id=:id");
								$restoransec->execute(array(

									"id" => $devamedensipariscek['restoran_id']
								));

								$restorancek=$restoransec->fetch(PDO::FETCH_ASSOC);

								$restoran_currency=$restorancek['restoran_currency']; ?>

								<div class="restaurant-list-item clearfix">
							
								<div class="GridLex-grid-noGutter-equalHeight">
								
									
									
									<div class="GridLex-col-12_sm-12_xss-12">
									
										<div class="GridLex-grid-noGutter-equalHeight">
										
											<div class="GridLex-col-9_sm-12 content-wrapper">
											
												<div class="content">
													<p style="font-weight: bold;color: #043D75;">Sipariş No: #<?php echo $devamedensipariscek['siparis_id']; ?></p>
													<h5><a  href="preorder?sef=<?php echo $restorancek['restoran_seo']; ?>"><?php echo $restorancek['restoran_ad']; ?> <i class="fas fa-angle-right"></i></a></h5>
													
													




													<p style="font-weight: bold;" class="location"><i class="fa fa-user"></i> <?php echo $devamedensipariscek['siparis_kisisayisi']." Misafir"; ?> </p>

													<p style="font-weight: bold;"><i class="fas fa-clock"></i> Varış Zamanı: <?php echo substr($devamedensipariscek['siparis_variszaman'],11,5); ?></p>

													<?php if (!empty($devamedensipariscek['siparis_ozeltalep'])) { ?>
														<p style="font-weight: bold;"><i class="fas fa-edit"></i> "<?php echo $devamedensipariscek['siparis_ozeltalep']; ?>"</p>
												<?php	} ?>


													
													<p class="cuisine"><b>Siparişim</b>: <?php $siparisyemeksec=$db->prepare("SELECT * from onsiparisyemek where siparis_id=:id and siparisyemek_turu=:turu");
													$siparisyemeksec->execute(array(

														"id" => $devamedensipariscek['siparis_id'],
														"turu" => 1

													)); while ($siparisyemekcek=$siparisyemeksec->fetch(PDO::FETCH_ASSOC)) { 

														$yemeksec=$db->prepare("SELECT * from yemekler where yemek_id=:id");
														$yemeksec->execute(array(

															"id" => $siparisyemekcek['yemek_id']
														));

														$yemekcek=$yemeksec->fetch(PDO::FETCH_ASSOC); ?>
															<span><?php echo $yemekcek['yemek_ad']."<b> x ".$siparisyemekcek['yemek_adet']."</b>"; ?></span>
														<?php } ?> </p>
												</div>
											
											</div>
											
											<div class="GridLex-col-3_sm-12 meta-wrapper">
											
												<div class="meta">
													
													<div class="right-bottom">
														<div class="price">Sipariş Tutarı: <span><?php echo $restoran_currency."".$devamedensipariscek['siparis_tutar']; ?></span></div>
														<div class="clear"></div>
														
													</div>
												</div>
											
											</div>
										
										</div>
										
									</div>
									
								</div>
							
							</div>
 
							<?php } ?>

							

							

						


							<?php } ?>
						</div>

						
						
					</div>


				</div>
				
			

</div>

			<div class="container pt-10 pb-30">
			
				
				
				<!-- Geçmiş siparişlerim bölümü -->
				
			</div>
			
		</div>
		<!-- end Main Wrapper -->

		<?php require_once 'footer.php';?>
		<script>


         $('.silbuton').click(function(){

         	var name=$(this).attr('name');
         	var id = name.substring(5);
         	

swal({
  title: "Emin Misiniz?",
  text: "Sipariş kaydını silmek istiyor musunuz?",
  icon: "warning",
  buttons: ["Vazgeç", "Sil"],
  dangerMode: true,
})
.then((willDelete) => {
  if (willDelete) {
    window.location = 'musteriislem?siparissil=ok&siparis_id='+id;
  } 
});

         })
      </script>
			
			