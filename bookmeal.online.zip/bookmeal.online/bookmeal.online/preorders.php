<?php require_once 'header.php'; 

if ($uyelik_turu!=2 and $uyelik_turu!=4) {
	
	header("Location:/");
	exit;
};


$restoranpanelsec=$db->prepare("SELECT * from restoranlar where restoran_id=:id");
$restoranpanelsec->execute(array(
"id" => $kullanicioturumcek['restoran_id']
));

$restoranpanelcek=$restoranpanelsec->fetch(PDO::FETCH_ASSOC);
$restoran_id=$kullanicioturumcek['restoran_id'];
$suan=date('Y-m-d H:i:s');

$restoran_currency=$restoranpanelcek['restoran_currency'];

$tamsuan = date('Y-m-d H:i:s');
   $saat1once = date("Y-m-d H:i:s",strtotime('-60 minutes',strtotime($tamsuan)));

//--- Sorgu ve silme işlemleri-----

$hazirla=$db->prepare("UPDATE onsiparisler set

siparis_bildirim=:siparis_bildirim,
siparis_variszaman=:siparis_variszaman,
siparis_kaybolmazaman=:siparis_kaybolmazaman

where siparis_turu='5' and siparis_bildirim='1' and kullanici_id={$_COOKIE['kullanici_id']} and siparis_kaybolmazaman <= '$tamsuan' 
	");

$derle=$hazirla->execute(array(

"siparis_bildirim" => 0,
"siparis_variszaman" => NULL,
"siparis_kaybolmazaman" => NULL

));


//-----------------------






?>





<title>Ön Siparişler</title>
<input type="hidden" id="restoran_id" value="<?php echo $kullanicioturumcek['restoran_id']; ?>" name="">
<input type="hidden" id="currency" value="<?php echo $restoran_currency; ?>">
		
		<!-- start Main Wrapper -->
		<div class="main-wrapper scrollspy-container">
			
			
		
			<!-- start hero-header -->

			


			<audio  autoplay='autoplay' muted='muted'  id="audioPlay" oncanplay="this.muted=true">
  <source src="silence.mp3" type="audio/mpeg">
 

</audio>
			

			
			<!-- end hero-header -->

			<div class="container pt-10 pb-30">

				<div style="position: relative;" class="alert alert-info metin"><a href='javascript:void(0);' class="metinkapat"><i style="position: absolute;top:3px;right: 5px;" class="fas fa-times"></i></a><i class="fas fa-info-circle"></i> Lütfen bu sayfayı <b>F5</b> ile yenilemeyiniz. <b>Chrome</b> ve <b>Mozilla</b>'nın bazı sürümlerinde bildirim sesleri engellenebilir. Ekranın tüm gün açık kalmasını öneririz.</div>
			
				
				
				<div class="row mb-10">
				
					<div class="col-md-8">
					
						<div style="margin-top: 30px;" class="section-title-02">



							<?php 



							$kayitlisiparissec=$db->prepare("SELECT * from onsiparisler where siparis_turu=:turu and restoran_id=:id and siparis_bildirim=:bildirim order by siparis_variszaman ASC");
							$kayitlisiparissec->execute(array(

"id" => $restoranpanelcek['restoran_id'],
"turu" => 5,
"bildirim" => 1
							));

							 $kayitlisiparissay=$kayitlisiparissec->rowCount();
					 ?>

							<h3><span>Devam Eden Ön Siparişler<small class="ml-10 siparissayisi">/ <?php echo $kayitlisiparissay." SİPARİŞ"; ?></small></span></h3><a href="past-pre-orders"><button class="mt-15 btn btn-primary btn-sm"><i class="fas fa-history"></i> Geçmiş Ön Siparişler</button></a>
					
						</div>
					
					</div>
					
				</div>
						
				<div class="row">
				
					
					
					<div style="min-height: 345px;" class="col-sm-12 col-md-12 col-xs-12">
						
						

						<div class="restaurant-list-item-wrapper no-last-bb">

							<?php 


if ($kayitlisiparissay==0) { ?>

<h4 align="center">Devam eden sipariş bulunamadı.</h4>

<?php } ?> <?php
							while($kayitlisipariscek=$kayitlisiparissec->fetch(PDO::FETCH_ASSOC)){ 

								$restoransec=$db->prepare("SELECT * from restoranlar where restoran_id=:id");
								$restoransec->execute(array(

									"id" => $kayitlisipariscek['restoran_id']
								));

								$restorancek=$restoransec->fetch(PDO::FETCH_ASSOC); ?>

								<div class="restaurant-list-item clearfix <?php echo $kayitlisipariscek['siparis_id']; ?>">
							
								<div class="GridLex-grid-noGutter-equalHeight">
								
									
									
									<div class="GridLex-col-12_sm-12_xss-12">
									
										<div class="GridLex-grid-noGutter-equalHeight">
										
											<div class="GridLex-col-9_sm-12 content-wrapper">
											
												<div class="content">

													<p style="font-weight: bold; color: #043D75;"> Sipariş No: #<?php echo $kayitlisipariscek['siparis_no']; ?></p>
													
													
                                                   <p style="font-weight: bold;"><i class="fas fa-user"></i> <?php echo $kayitlisipariscek['siparis_kisisayisi']." Misafir"; ?></p>
													

													

													<p style="font-weight: bold;"><i class="fas fa-clock"></i> Varış Saati: <?php echo substr($kayitlisipariscek['siparis_variszaman'],11,5); ?></p>

													<?php if (!empty($kayitlisipariscek['siparis_ozeltalep'])) { ?>

 														<p style="font-weight: bold;"><i class="fas fa-edit"></i> <?php echo $kayitlisipariscek['siparis_ozeltalep']; ?></p>

													<?php } ?>

													
													
													<p class="cuisine"><b>Sipariş:</b> <?php $siparisyemeksec=$db->prepare("SELECT * from onsiparisyemek where siparis_id=:id");
													$siparisyemeksec->execute(array(

														"id" => $kayitlisipariscek['siparis_id']

													));  while ($siparisyemekcek=$siparisyemeksec->fetch(PDO::FETCH_ASSOC)) { 

														$yemeksec=$db->prepare("SELECT * from yemekler where yemek_id=:id");
														$yemeksec->execute(array(

															"id" => $siparisyemekcek['yemek_id']
														));

														$yemekcek=$yemeksec->fetch(PDO::FETCH_ASSOC); ?>
															<span><?php echo $yemekcek['yemek_ad']."<b> x ".$siparisyemekcek['yemek_adet']."</b>"; ?></span>
														<?php } ?> </p>
												</div>
											
											</div>
											
											<div class="GridLex-col-3_sm-12 meta-wrapper">

												
											
												<div class="meta">

													<a href='javascript:void(0);' name="name_<?php echo $kayitlisipariscek['siparis_id']; ?>" class="siparissil"><i style="color: #043D75;" class="far fa-trash-alt"></i></a>
													
													<div class="right-bottom">
														<div class="price">Sipariş Tutarı: <span><?php echo $restoran_currency."".$kayitlisipariscek['siparis_tutar']; ?></span></div>
														<div class="clear"></div>
														
													</div>
												</div>
											
											</div>
										
										</div>
										
									</div>
									
								</div>
							
							</div>
 
							<?php } ?>

							

							

						</div>

						
						
					</div>


				</div>
				
			</div>
			
		
		</div>
		<!-- end Main Wrapper -->

		<?php require_once 'footer.php';?>
		<script type="text/javascript">

			$('.metinkapat').click(function(){

$('.metin').remove();

			});

			setInterval(function(){ 

				var restoran_id=$('#restoran_id').val();
				var currency=$('#currency').val();

$.ajax({
            type : 'POST',
            url : 'ajax.php',
            data : {'restoran_id':restoran_id,'panelonsipariscek':'ok','restoran_currency':currency},
            success : function(sonuc){

            	sonuc=$.trim(sonuc);

            	if (sonuc!='dur') {

            	$('.main-wrapper').html(sonuc);
            	$('.siparissil').click(function(){

				var id1=$(this).attr("name");
                var siparis_id=id1.substring(5);

                swal({
  title: "Siparişi geçmiş ön siparişlere taşıyacağız?",
  icon: "warning",
  buttons: ["Vazgeç", "Taşı"],
  dangerMode: true,
})
.then((willDelete) => {
  if (willDelete) {
    
$.ajax({

	 type : 'POST',
            url : 'ajax.php',
            data : {'panelonsiparissil':'ok','siparis_id':siparis_id},
            success : function(sonuc){

            	sonuc=$.trim(sonuc);

           
            	$('.'+siparis_id).remove();
            	var siparissayisi = $('.restaurant-list-item').length;
            	$('.siparissayisi').html("/ "+siparissayisi+" SİPARİŞ");
            	if (siparissayisi==0) {

           $('.restaurant-list-item-wrapper').html('<h4 align="center">Devam eden sipariş yok.</h4>')

            	}
            	
               
            }
})

  } 
});
			})

            	var sound = new Audio('ping.mp3');
            	sound.play();

            	 };

            	
            	
            }
        })



			 }, 10000);
			
			$('.siparissil').click(function(){

				var id1=$(this).attr("name");
                var siparis_id=id1.substring(5);

                swal({
  title: "Siparişi geçmiş ön siparişlere taşıyacağız?",
  icon: "warning",
  buttons: ["Vazgeç", "Taşı"],
  dangerMode: true,
})
.then((willDelete) => {
  if (willDelete) {
    
$.ajax({

	 type : 'POST',
            url : 'ajax.php',
            data : {'panelonsiparissil':'ok','siparis_id':siparis_id},
            success : function(sonuc){

            	sonuc=$.trim(sonuc);

           
            	$('.'+siparis_id).remove();
            	var siparissayisi = $('.restaurant-list-item').length;
            	$('.siparissayisi').html("/ "+siparissayisi+" SİPARİŞ");
            	if (siparissayisi==0) {

           $('.restaurant-list-item-wrapper').html('<h4 align="center">Devam eden sipariş yok.</h4>')

            	}
            	
               
            }
})

  } 
});
			})
		</script>
			
			