
<?php require_once 'header.php'; 



$restoran_seo=$_GET['sef'];

$restoransec=$db->prepare("SELECT * from restoranlar where restoran_seo=:seo");
$restoransec->execute(array(
"seo" => $restoran_seo
));

$restorancek=$restoransec->fetch(PDO::FETCH_ASSOC);

$restorankullanicisec=$db->prepare("SELECT * from kullanici where restoran_id=:id");
$restorankullanicisec->execute(array(
"id" => $restorancek['restoran_id']
));

$restorankullanicicek=$restorankullanicisec->fetch(PDO::FETCH_ASSOC);

$uyelik_turu=$restorankullanicicek['uyelik_turu'];

$restoran_masasayisi=$restorancek['restoran_masasayisi'];

$restoran_currency=$restorancek['restoran_currency'];


$restoransay=$restoransec->rowCount();

if ($restoransay==0 or $_GET['tableno']<1 or $_GET['tableno']>$restoran_masasayisi or ($uyelik_turu!=1 and $uyelik_turu!=3 and $uyelik_turu!=4)) {
	
	header("Location:/");
}

$restoran_id=$restorancek['restoran_id'];

$siparissec=$db->prepare("SELECT * from siparisler where restoran_id=:id and kullanici_ip=:ip and siparis_turu=:turu");
$siparissec->execute(array(
"id" => $restoran_id,
"ip" => $ip_adresi,
"turu" => 1
));

$sipariscek=$siparissec->fetch(PDO::FETCH_ASSOC);


 $siparissay=$siparissec->rowCount();

 if ($siparissay==1 and date("Y-m-d H:i:s",strtotime($sipariscek['siparis_zaman']." +10 minutes"))<date("Y-m-d H:i:s")) {

 	$siparis_id=$sipariscek['siparis_id'];
 	
 	$siparissil=$db->prepare("DELETE from siparisler where siparis_id=:id");
 	$siparissil->execute(array(
"id" => $siparis_id
 	));

 	$siparisyemeksil=$db->prepare("DELETE from siparisyemek where siparis_id=:id");
 	$siparisyemeksil->execute(array(
"id" => $siparis_id
 	));
 }






?>

<style type="text/css">
	.hero::before {
    position: absolute;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    content: "";
    background: rgba(0, 0, 0, 0.0);
}
</style>

<title><?php echo $restorancek['restoran_ad']." Sipariş"; ?></title>




		<div class="main-wrapper scrollspy-container">
		
			<!-- start hero-header -->
			<div  class="hero hero-breadcrumb" style="height: 300px;background-color: white;">
			
				<div align="center" class="container">

					<?php if (strlen($restorancek['restoran_logo'])>0) { ?>
						<img  style="max-width: 200px;max-height: 100px;margin-bottom:10px;" src="<?php echo $restorancek['restoran_logo']; ?>">
					<?php } ?>

					
					<?php if ($uyelik_turu==1) { ?>
						
						<h1 style="color:#484848;"><?php echo $restorancek['restoran_ad']." QR MENÜ"; ?></h1>
					<?php } else { ?>

						<h1 style="color:#484848;"><?php echo $restorancek['restoran_ad']." Sipariş"; ?></h1>
					<h4 style="color: #484848;" style="font-size: 22px;color: white;"><?php echo "MASA ".$_GET['tableno']; ?></h4>
					<?php } ?>
					

					


				</div>
				
			</div>



			

			<div style="background-color: #F3F2F1;" class="container pt-10 pb-30">

				<?php if ($_GET['order']=='success') { ?>
					<div class="alert alert-success alert-icon">
						
							<i class="fa fa-check-circle"></i>
							
							<h4>Siparişinizi aldık. Teşekkür ederiz!</h4>
						
						</div>
				<?php } ?>

				
			
			
				
				<div class="row mt-40 mb-30">

					<?php if (!empty($restorancek['restoran_menuaciklama'])) { ?>
						<div class="alert alert-info"><i class="fas fa-quote-right"></i> <?php echo $restorancek['restoran_menuaciklama']; ?></div>
					<?php } ?>

					<div class="col-xs-12 col-xs-12 col-md-12">
						
						<div class="submite-list-wrapper">
						
							
							
							<div class="submite-list-box">
							
								<div class="row">
								
									<div class="col-xs-12 col-sm-12 mb-30-xs">
									
										<div class="row gap-20">
											
											<?php $anliksiparissec=$db->prepare("SELECT * from siparisler where siparis_turu=:turu and restoran_id=:id and kullanici_ip=:ip");

											$anliksiparissec->execute(array(

"id" => $restoran_id,
"ip" => $ip_adresi,
"turu" => 1

											));

											$anliksiparissay=$anliksiparissec->rowCount();

											if ($anliksiparissay==0) { ?>
											 	
                                
										

										
											
											
											
											
											
											

											<form id="siparisverform">
											
											

											<input type="hidden" value="<?php echo $restoran_id; ?>" name="restoran_id">

											<input type="hidden" value="<?php echo $_GET['tableno']; ?>" name="siparis_masano">

											

											
											
											

											
											

											<div class="col-xs-12 col-sm-12">
												
												<div id="detail-content-sticky-nav-01" class="detail-content-section clearfix">
							
								<div class="section-title-02">
									<h3><span>MENÜ</span></h3>
								</div>
								
								<div class="tab-style-01-wrapper mt-30 mb-20">

									<?php $menucesitsec=$db->prepare("SELECT * from restoranmenucesit where restoran_id=:id");
										$menucesitsec->execute(array(

											"id" => $restoran_id

										)); 

										$menucesitsay=$menucesitsec->rowCount();

									if ($menucesitsay==0 and ($restoran_id==$kullanicioturumcek['restoran_id'])) { ?>
											
                                        <h4 align="center">Henüz menü eklememişsiniz. <br><a href="menu-settings">Hemen ekleyin <i style='font-size: 17px;' class="fas fa-arrow-right"></i></a></h4>

									<?php	} ?>
							
									<ul class="tab-responsive tab-nav">

										

										<?php $say=0;


										while ($menucesitcek=$menucesitsec->fetch(PDO::FETCH_ASSOC)) { $say++; ?>

											<li  <?php if ($say==1) { ?>
												class='active'
											<?php } ?> ><a style="color:<?php echo $restorancek['restoran_renk']; ?>;" href="#cesit_id<?php echo $menucesitcek['cesit_id']; ?>" data-toggle="tab"><?php echo $menucesitcek['cesit_ad']; ?></a></li>
								
										<?php } ?>
										
										
									</ul>
									
									<div class="tab-content" >


										<?php $menucesitsec2=$db->prepare("SELECT * from restoranmenucesit where restoran_id=:id");
										$menucesitsec2->execute(array(

											"id" => $restoran_id

										));

										$say=0;


										while ($menucesitcek2=$menucesitsec2->fetch(PDO::FETCH_ASSOC)) { $say++; ?>


											<div class="tab-pane fade in <?php if($say==1){ ?>

												active


										<?php	} ?> " id="cesit_id<?php echo $menucesitcek2['cesit_id']; ?>">


										

											<div class="tab-inner">
												
												<div class="food-menu-wrapper">
												
													<div class="GridLex-gap-30">


													
														<div class="GridLex-grid-noGutter-equalHeight">

															<?php $yemeksec=$db->prepare("SELECT * from yemekler where restoran_id=:id and yemek_cesit=:cesit");
										$yemeksec->execute(array(

											"id" => $restoran_id,
											"cesit" => $menucesitcek2['cesit_id']

										));

										$say=0;

										while ($yemekcek=$yemeksec->fetch(PDO::FETCH_ASSOC)) { $say++; ?>

											<div class="GridLex-col-6_sm-12_xs-12_xss-12">
															
																
                                                  <?php if (empty($yemekcek['yemek_foto'])) { ?>

                                                  	<div class="food-menu-item no-image clearfix">


                                                  	
                                                  <?php } else { ?>


                                                                <div class="food-menu-item clearfix">

																	<div class="image">
																		<img style="height: 70px;" src="<?php echo $yemekcek['yemek_foto']; ?>" alt="image" />
																	</div>


                                                 <?php } ?>
																	
																
								
																	<div class="content">
																	
																		<h6><span><?php echo $yemekcek['yemek_ad']; ?></span></h6>
																		<p><?php echo $yemekcek['yemek_aciklama']; ?></p>
																		
																		<div style="color: <?php echo $restorancek['restoran_renk']; ?>;" class="price">
																			 <?php echo $restoran_currency." ".$yemekcek['yemek_fiyat']; ?>
																		</div>

																		
																		
																	</div>

																	<?php if ($uyelik_turu!=1) { ?>
																		<div class="checkbox-block font-icon-checkbox">
								<select  name="yemekadet_<?php echo $yemekcek['yemek_id']; ?>" class="form-control adetoption" >
									<option value="0"  selected="">Adet</option>
									<option value="1">1</option>
									<option value="2">2</option>
									<option value="3">3</option>
									<option value="4">4</option>
									<option value="5">5</option>
								</select>

								<input type="hidden" type="text" value="<?php echo $yemekcek['yemek_id']; ?>" name="yemekler[]">
							</div>
																	<?php } ?>


                                                                

																	
																</div>




															
															</div>

															
 




											

									<?php	} ?>

           
						

										 
														
															
															
														</div>
														
													</div>
												
												</div>

											</div>
										</div>
										
										
											

										<?php } ?>

										

									
										

									</div>

									<input type="hidden" name="siparisver">
									<input type="hidden" value="<?php echo $restorancek['restoran_id']; ?>" name="restoran_id">
								
								</div>
								
							</div>


							
											</div>

											 <?php if ($uyelik_turu!=1) { ?>
											 	<div class="col-xs-12 col-sm-12">
									
												<div class="form-group bootstrap3-wysihtml5-wrapper">
												
													<label>Özel İstek (opsiyonel)</label>
													<textarea class="bootstrap3-wysihtml5 form-control" maxlength="500" name="siparis_ozeltalep"  style="height: 100px;"></textarea>
													
												</div>
												
											</div>



											

											
											
											
												<div class="col-xs-12 col-sm-12">

												
											
												
												
												<button style="background-color:<?php echo $restorancek['restoran_renk']; ?>;border:1px solid <?php echo $restorancek['restoran_renk']; ?>" type="submit" id="siparisverbutton" name="siparisver" class="btn btn-primary mt-15">Siparişi Tamamla</button>
											
											</div>
											 <?php } ?>
											

											</form>
											
										

											<?php } else { ?>

												<?php while ($anliksipariscek=$anliksiparissec->fetch(PDO::FETCH_ASSOC)) {
													
                                                 $restoransec=$db->prepare("SELECT * from restoranlar where restoran_id=:id");
								$restoransec->execute(array(

									"id" => $kayitlisipariscek['restoran_id']
								));

								$restorancek=$restoransec->fetch(PDO::FETCH_ASSOC); ?>

								<div class="col-xs-12 col-md-12 col-sm-12">

								<div class="restaurant-list-item clearfix">
							
								<div class="GridLex-grid-noGutter-equalHeight">
								
									
									
									<div class="GridLex-col-12_sm-12_xss-12">
									
										<div class="GridLex-grid-noGutter-equalHeight">
										
											<div class="GridLex-col-9_sm-12 content-wrapper">
											
												<div class="content">

													<p style="font-weight: bold;color: #043D75;"> Sipariş No: #<?php echo $anliksipariscek['siparis_id']; ?></p>

													<p style="font-weight: bold;"><i class="fas fa-clock"></i> Sipariş Zamanı: <?php echo substr($anliksipariscek['siparis_zaman'],11,5); ?></p>
													
													
													<p style="font-weight: bold;" class="location"><i class="fas fa-chair"></i> <?php echo "Masa No: ".$anliksipariscek['siparis_masano']; ?> </p>

													<?php if (!empty($anliksipariscek['siparis_ozeltalep'])) { ?>

 														<p style="font-weight: bold;"><i class="fas fa-edit"></i> <?php echo $anliksipariscek['siparis_ozeltalep']; ?></p>

													<?php } ?>

													
													
													<p class="cuisine"><b>Siparişiniz:</b> <?php $siparisyemeksec=$db->prepare("SELECT * from siparisyemek where siparis_id=:id");
													$siparisyemeksec->execute(array(

														"id" => $anliksipariscek['siparis_id']
					

													));  while ($siparisyemekcek=$siparisyemeksec->fetch(PDO::FETCH_ASSOC)) { 

														$yemeksec=$db->prepare("SELECT * from yemekler where yemek_id=:id");
														$yemeksec->execute(array(

															"id" => $siparisyemekcek['yemek_id']
														));

														$yemekcek=$yemeksec->fetch(PDO::FETCH_ASSOC); ?>
															<span><?php echo $yemekcek['yemek_ad']."<b> x ".$siparisyemekcek['yemek_adet']."</b>"; ?></span>
														<?php } ?> </p>
												</div>
											
											</div>
											
											<div class="GridLex-col-3_sm-12 meta-wrapper">
											
												<div class="meta">
													
													<div class="right-bottom">
														<div class="price">Sipariş Tutarı: <span><?php echo $restoran_currency."".$anliksipariscek['siparis_tutar']; ?></span></div>
														<div class="clear"></div>
														
													</div>
												</div>
											
											</div>
										
										</div>
										
									</div>
									
								</div>
							
							</div>

							</div>

												<?php } ?>






											<?php } ?>

										</div>

									</div>
									
									
									
								</div>

							</div>

						</div>
						
					</div>

				</div>

			</div>
			
		</div>
		
		<?php require_once 'footer.php'; ?>
		<script type="text/javascript">

			
			
			$('#siparisverform').submit(function(){

				
$('#siparisverbutton').prop('disabled',true);


 event.preventDefault();
var seciliyemekler =  $(".adetoption>option:not([value='0']):selected").length;


  if(seciliyemekler==0){
     
    $('#siparisverbutton').prop('disabled',false);
    


    swal({

  title: "Yemek seçimi yapılmadı",
  text: "Hiçbir yemek seçimi yapmadınız.",
  icon: "warning",
  button: "OK",
});

               
   

} else {

$('#siparisverbutton').html("<img style='width:18px;height:18px;' src='css/images/flex-loader.gif'>");

	$.ajax({
            type : 'POST',
            url : 'ajax.php',
            data : $('#siparisverform').serialize(),
            success : function(sonuc){

            	

  var url = window.location.href;    
if (url.indexOf('?') > -1){
   url += '&order=success'
}else{
   url += '?order=success'
}
window.location.href = url;
               

               

            }
        })
}











			})

		</script>
			
		