<?php require_once 'header.php'; ?>
<title>QR Kodlarım</title>

<?php if ($uyelik_turu!=1 and $uyelik_turu!=3 and $uyelik_turu!=4) {
	header("Location:/");exit;
};


$restoransec=$db->prepare("SELECT * from restoranlar where restoran_id=:id");
$restoransec->execute(array(
"id" => $kullanicioturumcek['restoran_id']
));

$restorancek=$restoransec->fetch(PDO::FETCH_ASSOC);


$restoran_ad=$restorancek['restoran_ad'];
$restoran_logo=$restorancek['restoran_logo'];




 ?>


		<!-- start Main Wrapper -->
		<div class="main-wrapper scrollspy-container">

			
			<input type="hidden" id="restoran_id" value="<?php echo $kullanicioturumcek['restoran_id']; ?>" name="">
		
			

			<div class="container pt-10 pb-30">
			
				
				
				<div style="margin-top:30px;" class="row mb-10 tumqrkodlar">
				
					<div class="col-md-8">
					
						<div class="section-title-02">

							<h3><span>Restoranınız için tüm QR Kodlar</span></h3>
						
						</div>
					
					</div>
					
				</div>

				<div align="center" style="margin-bottom: 30px;display: none;" class="col-md-12 col-xs-12 col-sm-12 yukleniyor">

					<h4 style="color: #043d75;">Menüler hazırlanıyor</h4> <img style="height: 58px;width: 58px;" src="images/loadings.gif">
				</div>

				<div style="margin-bottom: 30px;" class="col-md-12 col-xs-12 col-sm-12 butonlar">
					<div  class="row">
						<div  align="left" class="col-md-2 col-xs-12 col-sm-2"><button id="newtable" class="btn btn-primary mt-15 col-md-12 col-xs-12 col-sm-12">Masa Ekle+</button></div>
						<div  align="left" class="col-md-2 col-xs-12 col-sm-2"><button id="deletetable" class="btn btn-primary mt-15 col-md-12 col-xs-12 col-sm-12">Son Masayı Sil</button></div>

						<div  align="left" class="col-md-3 col-xs-12 col-sm-3"><a href="javascript:void(0);"><button class="btn btn-primary mt-15 col-md-12 col-xs-12 col-sm-12 downloadqrcards"><i class="fas fa-download"></i> Tüm Menüleri İndir</button></a></div>
						
						<div  align="left" class="col-md-3 col-xs-12 col-sm-3"><a href='musteriislem?qrkodlarindir=ok&restoran_id=<?php echo $restorancek['restoran_id']; ?>'><button class="btn btn-primary mt-15 downloadqrcodes col-md-12 col-xs-12 col-sm-12"><i class="fas fa-qrcode"></i> Sadece QR Kodları İndir</button></a></div>

						<div  align="left" class="col-md-2 col-xs-12 col-sm-2"><a href='color-settings'><button class="btn btn-primary mt-15 downloadqrcodes col-md-12 col-xs-12 col-sm-12"><i class="fas fa-palette"></i> Renk Değiştir</button></a></div>

						
						

						
						
					</div>
				</div>



				<hr>




<?php if ($uyelik_turu==2 or $uyelik_turu==4) { ?>
	<div style="margin-bottom:20px;" class="col-xs-12 col-sm-6 col-md-6">
			<div class="checkbox-block"> 
				<input id="remember_me_checkbox" <?php  if ($restorancek['kart_preorder']=="yes"){ ?>
checked='checked'
				<?php } ?> name="remember_me_checkbox" class="checkbox" value="First Choice" type="checkbox"> 
				<label class="" for="remember_me_checkbox"><b>Ön sipariş adresini kartta göster</b></label>
			</div>

		
	</div>
<?php } ?>
	


	 
	


				


						
				<div class="row">


				
					
					
					<div class="col-sm-12 col-md-12 col-xs-12">
						
						
						<div class="restaurant-grid-wrapper mb-30">

							
					
							<div class="GridLex-gap-30">


							
								<div class="GridLex-grid-noGutter-equalHeight">

									
									

	 

									<?php $qrkodsec=$db->prepare("SELECT * from qrkodlar where restoran_id=:id");
									$qrkodsec->execute(array(

										"id" => $kullanicioturumcek['restoran_id']

									));

									

									while ($qrkodcek=$qrkodsec->fetch(PDO::FETCH_ASSOC)) { $kartsay++; ?>

										<div style="height: 604px;width: 430px;" class="col-md-4 qritem">







											<div class="card_<?php echo $qrkodcek['qr_masano']; ?>" align="center" style="height: 155mm;width:420px;background: white;position: relative;border: 1px solid <?php echo $restorancek['restoran_renk']; ?>">

												


												<div align="center" class="col-md-12 col-xs-12 col-sm-12" style="height: 130px;margin-top:30px;">
													
													<?php if (empty($restorancek['restoran_logo'])) { ?>
													<h4 style='color: <?php echo $restorancek['restoran_renk']; ?>'>Hoşgeldiniz!</h4>
													<?php } else { ?>

         <img style="max-height: 100px;max-width: 150px;" src="<?php echo $restoran_logo; ?>">

													<?php } ?>
													
												</div>

												<div class="col-xs-12 col-sm-12 col-md-12">
												
												<div  style="height: 190px;width: 105px;">

													<h5 align="center">QR MENÜ</h5>
						
										<div class="restaurant-grid-item">
											
												
													<img  src="<?php echo $qrkodcek['qr_foto']; ?>" alt="Image" />
												
												<div class="content">
													<h5 align="center">Masa <?php echo $qrkodcek['qr_masano']; ?></h5>
													
													
												</div>
											
										</div>
							
									</div>

									<?php if ($uyelik_turu==2 or $uyelik_turu==4) { ?>
										<div style="margin-top:30px;<?php if ($restorancek['kart_preorder']=="no") { ?>
											display: none;
										<?php } ?>" class="col-xs-12 col-sm-12 col-md-12 forpreorder">
										<b style='font-size:15px;'>Ön Sipariş İçin <i class="fas fa-angle-down"></i></b><br>
										<a style="font-weight: bold;font-size: 15px;color: <?php echo $restorancek['restoran_renk']; ?>" href="preorder?sef=<?php echo $restorancek['restoran_seo']; ?>"><?php echo $restorancek['restoran_seo']; ?>.bookmeal.online</a>
									</div>
									<?php } ?>

									</div>

									<div class="col-xs-12 col-sm-12 col-md-12" style="height: 50px;background: <?php echo $restorancek['restoran_renk']; ?>;position: absolute;left: 0px;bottom: 0px;">

										<h6 style="color: white;margin-top:13px;" align="center">QR Kodu Telefonunuzla Tarayın</h6>
										
									</div>



									

											</div>



											






						
										
							
									</div>


										
									<?php } ?>

                             
                                     
									
								
									
									
									
									
									
									
								</div>
								
							</div>

						</div>

						
						
					</div>

				</div>
				
			</div>
			
		</div>
		<!-- end Main Wrapper -->
		
		<?php require_once 'footer.php'; ?>
		<script src='js/html2canvas.js'></script>
		<script src='js/FileSaver.js'></script>
		<script src='js/jszip.js'></script>




		
		<script type="text/javascript">

			
			



			$('.downloadqrcards').click(function(){

				$('.butonlar').hide();
				$('.yukleniyor').show();
				$('.checkbox-block').hide();
	     $('html').css('overflow','hidden');
	
    
   


	
	var scrollY = $(document).scrollTop();
var scrollX = $(document).scrollLeft();
        
var cardsayisi = $('.qritem').length;



var zip = new JSZip();
var menuklasor = zip.folder("menuler");


//Kartları canvas a çevirme


var masa = 0;






  while (masa<cardsayisi-1){

	
	masa++;


	html2canvas(document.querySelector(".card_"+masa), {
        

        onrendered: function (canvas) {

        	masa++;
           
           var imgUri = canvas.toDataURL().split(';base64,')[1];
        menuklasor.file("masa_"+(masa-cardsayisi+1)+".png", imgUri, {base64: true});
       

        }
    });


	


}






html2canvas(document.querySelector(".card_"+cardsayisi), {
        onrendered: function (canvas) {

        	
           var imgUri = canvas.toDataURL().split(';base64,')[1];
        menuklasor.file("masa_"+cardsayisi+".png", imgUri, {base64: true});
        zip.generateAsync({type:"blob"})
.then(function(content) {
    // see FileSaver.js
    saveAs(content, "qrmenüler.zip");

    $('.yukleniyor').hide();
    $('.butonlar').show();
    $('.checkbox-block').show();
     $('html').css('overflow','auto');

         

});
        

        }
    });




 
















    

   
  




			});

			

    

    	
    



			$('#newtable').click(function(){

				$('.butonlar button').prop('disabled',true);
				$('#newtable').html('Ekleniyor...');

				
				var restoran_id=$('#restoran_id').val();

$.ajax({
            type : 'POST',
            url : 'ajax.php',
            data : {'yenimasaekle':'ok','restoran_id':restoran_id},
            success : function(sonuc){

            	sonuc=$.trim(sonuc);

            	 if (sonuc=='hata') {

            		

swal({

  title: "Bir şeyler ters gitti",
  text: "Lütfen tekrar deneyin.",
  icon: "error",
  button: "OK",
});

$('.butonlar button').prop('disabled',false);
$('#newtable').html('Masa Ekle+');
            	} else {


            		
swal({

  title: "Başarılı",
  text: "Yeni masa kartı eklendi. Aşağıdan kontrol edebilirsiniz.",
  icon: "success",
  button: "OK",
});


$('.qritem').last().after(sonuc);

$('.butonlar button').prop('disabled',false);
$('#newtable').html('Masa Ekle+');







            	}
            	
               
            }
        })

			});

			//---------------------------------------


$('#deletetable').click(function(){

	$('.butonlar button').prop('disabled',true);
	$('#deletetable').html('Siliniyor...');

				
				var restoran_id=$('#restoran_id').val();

$.ajax({
            type : 'POST',
            url : 'ajax.php',
            data : {'sonmasasil':'ok','restoran_id':restoran_id},
            success : function(sonuc){

            	sonuc=$.trim(sonuc);

            if (sonuc=='masasayisi1') {

            	swal({

  title: "Uyarı",
  text: "Son masanın kartını kaldıramazsınız.",
  icon: "warning",
  button: "OK",
});

            	$('.butonlar button').prop('disabled',false);
	            $('#deletetable').html('SON MASAYI SİL');



            } 	else if (sonuc=='islemtamam') {

            		$('.qritem').last().remove();

swal({

  title: "Başarılı",
  text: "Masa başarıyla kaldırıldı. Aşağıdan kontrol edebilirsiniz.",
  icon: "success",
  button: "OK",
});

$('.butonlar button').prop('disabled',false);
	$('#deletetable').html('SON MASAYI SİL');

            	} else if (sonuc=='hata') {

            		swal({

  title: "Bir şeyler ters gitti",
  text: "Lütfen tekrar deneyin.",
  icon: "error",
  button: "OK",
});

$('#deletetable').prop('disabled',false);
	$('#deletetable').html('SON MASAYI SİL');

            	}

            	
            	
               
            }
        })

});


//--------------------------------------------





$('#remember_me_checkbox').change(function(){

	var restoran_id=$('#restoran_id').val();

	$(this).prop('disabled',true);

	if (this.checked) {


$('.forpreorder').show();
$(this).val('yes');

	} else {


$('.forpreorder').hide();
$(this).val('no');


	};

	var checkboxdeger=$(this).val();

	$.ajax({
            type : 'POST',
            url : 'ajax.php',
            data : {'kartpreorder':'ok','restoran_id':restoran_id,'checkboxdeger':checkboxdeger},
            success : function(sonuc){

            	
            	$('#remember_me_checkbox').prop('disabled',false);

            	 }


})



	

	});









		</script>