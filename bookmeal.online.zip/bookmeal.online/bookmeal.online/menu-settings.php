<?php require_once 'header.php'; 

if ($kullanicioturumcek['kullanici_yetki']!=5) {
	
	header("Location:/");
};

$restoransec=$db->prepare("SELECT * from restoranlar where restoran_id=:id");
$restoransec->execute(array(
"id" => $kullanicioturumcek['restoran_id']
));

$restorancek=$restoransec->fetch(PDO::FETCH_ASSOC);

$menucesitsecc=$db->prepare("SELECT * from restoranmenucesit where restoran_id=:id");
							$menucesitsecc->execute(array(

								"id" => $restorancek['restoran_id'] 
							));

							$mevcutmenu=$menucesitsecc->rowCount();
							$kalanmenu=10-$mevcutmenu;

							$currency=$restorancek['restoran_currency'];
							

?>
<title>Menü Ayarları</title>
		
		<!-- start Main Wrapper -->
		<div class="main-wrapper scrollspy-container">
		
			<!-- start hero-header -->
			

			<div class="container pt-10 pb-30">
			
				<div class="breadcrumb-wrapper">
				
					<ol class="breadcrumb">
					
						<li><a href="/">Anasayfa</a></li>
						<li class="active">Menü Ayarları</li>
						
					</ol>
					
				</div>


				
				<div class="row mt-40 mb-30">

					<div class="col-xs-12 col-sm-10 col-sm-offset-1 col-md-10 ">

						

						<div class="row">


					
								<div class="col-md-8">
								
									<div class="section-title-02 mb-20">

										<h3><span>Menü Ayarları</span></h3>
									
										
									
									</div>
								
								</div>
								
							</div>

							<input type="hidden" value="<?php echo $currency; ?>" id="currency">
							<input type="hidden" value="<?php echo $restorancek['restoran_id']; ?>" id="restoran_id">


								<div class="sidebar-mini-search mb-20">
												<div class="input-group">
													<input id="menuaciklama" type="text" class="form-control" value="<?php echo $restorancek['restoran_menuaciklama']; ?>" maxlength="200" placeholder="Buraya menünün üst kısmında yer alacak bir açıklama yazabilirsiniz.">
													<span class="input-group-btn">
														<button class="btn btn-primary menuaciklama" type="button">GÜNCELLE</button>
													</span>
												</div>
											</div>

											<hr>
							

						
						
						<div class="submite-list-wrapper">

							<?php if($_GET['update']=="ok"){ ?>

								<div class="alert alert-success alert-icon">
						
							<i class="fa fa-check-circle"></i>
							
							<h4>Güncelleme Başarılı</h4>
						
						</div>
						<?php	} else if($_GET['addmenu']=="ok"){ ?>

							<div class="alert alert-success alert-icon">
						
							<i class="fa fa-check-circle"></i>
							
							<h4>Menüler başarıyla eklendi</h4>
						
						</div>

						<?php } ?>



						<div class="tab-vertical-style-01-wrapper mt-30 mb-20">
							
									<div class="row gap-20">
									
										<div class="col-xs-12 col-sm-12 col-md-2">
										
											<ul class="tab-responsive tab-nav">
												<li class="active"><a href="#tab-style-01-01s" data-toggle="tab">Menü Düzenle</a></li>

												<li><a href="#tab-style-01-03s" data-toggle="tab">Fotoğraf Ekle/Sil</a></li>
												<li><a href="#tab-style-01-02s" data-toggle="tab">+ Menü Ekle</a></li>


												
											</ul>

										</div>
										
										<div class="col-xs-12 col-sm-12 col-md-10">
										
											<div class="tab-content" >
									
												<div class="tab-pane fade in active" id="tab-style-01-01s">
												
													<div class="tab-inner tab-inner-edit">
														
														<?php if ($mevcutmenu==0) { ?>
												
												<h4 align="center">Menü bulunamadı. Lütfen önce menü ekleyin.</h4>			
                                                  
														<?php } else { ?>
                                                     
                                                       

														
							<form onsubmit="return false;" id="menuupdateform">
							
							<div class="submite-list-box">

								

							<?php
                         
                         
							 $sira=0;

							 $menucesitsec=$db->prepare("SELECT * from restoranmenucesit where restoran_id=:id");
							 $menucesitsec->execute(array(

"id" => $restorancek['restoran_id']
							 ));



							while ($menucesitcek=$menucesitsec->fetch(PDO::FETCH_ASSOC)) { $sira++; $cesit_id=$menucesitcek['cesit_id']; ?>
							 	<div class="food-menu-form-wrapper kategori<?php echo $sira; ?> menu_<?php echo $menucesitcek['cesit_id']; ?>">
								
									<h6 class="text-primary text-uppercase">Menü Kategori #<?php echo $sira; ?> <a style="color: #DB3944;" class="silbuton" href="javascript:void(0);" name="menu_<?php echo $menucesitcek['cesit_id']; ?>" ><i class="far fa-trash-alt"></i></a></h6>
									
									<div class="form-group form-group-lg">

										

										<input type="text" maxlength="30" placeholder="Örn. Çorba,Ana Yemek,Salatalar vs." value="<?php echo $menucesitcek['cesit_ad']; ?>" class="form-control menu_title" name="cesit_ad_<?php echo $menucesitcek['cesit_id']; ?>">
										
									</div>

									<?php $yemeksec=$db->prepare("SELECT * from yemekler where yemek_cesit=:cesit");
									$yemeksec->execute(array(

"cesit" => $cesit_id
									));

									while ($yemekcek=$yemeksec->fetch(PDO::FETCH_ASSOC)) { ?>
									 	
									


									

									<div style="padding-left: 23px;position: relative;" class="food-menu-form-box food-menu-form-box-update clearfix default yemek_<?php echo $yemekcek['yemek_id']; ?>">


										



										
									<div style="position: absolute;top:10px;right: 10px;"><a class="yemeksilbuton" name="yemek_<?php echo $yemekcek['yemek_id']; ?>" href='javascript:void(0);'><i style="color: #DB3944;" class="far fa-trash-alt"></i></a></div>
										
										
										
										
										<div  style="margin: 0;" class="food-memu-form">




										
											<div class="row gap-20">

												


											
												<div class="col-xss-12 col-xs-12 col-sm-9">


												
													<div class="form-group">
														<label>Yemek Adı</label>
														<input type="text" value="<?php echo $yemekcek['yemek_ad']; ?>" name="menu_yemekad_<?php echo $yemekcek['yemek_id']; ?>" class="form-control yemek_ad"/>
													</div>
													
												</div>
												
												<div class="col-xss-12 col-xs-12 col-sm-3">
												
													<div class="form-group">
														<label>Fiyat</label>
														<div class="input-group">
															<input type="text" value="<?php echo $yemekcek['yemek_fiyat']; ?>" name="menu_yemekfiyat_<?php echo $yemekcek['yemek_id']; ?>" class="form-control yemek_fiyat">
															<span class="input-group-addon"><?php echo $currency; ?></span>
														</div>
													</div>
													
												</div>
												
												<div class="col-xss-12 col-xs-12 col-sm-12">
												
													<div class="form-group">
														<label>Kısa Açıklama</label>
														<input type="text" value="<?php echo $yemekcek['yemek_aciklama']; ?>" name="menu_yemekaciklama_<?php echo $yemekcek['yemek_id']; ?>" class="form-control"/>
													</div>
													
												</div>



												


												
											
											</div>
											
										</div>

										
									</div>

									<?php } ?>

									<div class="clearfix mt-15">
										<a class="sutunekleupdate" name="sutunekle_<?php echo $sira; ?>" href="javascript:void(0);"><i class="fa fa-plus-circle"  aria-hidden="true"></i></a>
										<a class="sutuncikarupdate" name="sutuncikar_<?php echo $sira; ?>" href="javascript:void(0);"><i class="fa fa-minus-circle"  aria-hidden="true"></i></a>
										<span class="ml-5 font13 line-12 text-muted font-italic">Kategori başına 20 yemeğe kadar ekleyebilirsiniz.</span>
									</div>

									
                                  
									
									
									
									
									
									
								</div>

							<?php }  ?>


								
								
								
							</div>

							<input type="hidden" name="menuupdate">
							
							
							
							<div class="mt-30">
					
								
								
								<button id="menuupdatebutton" class="btn btn-primary mt-15">GÜNCELLE</button>
								
							</div>

							

							</form>
							
						


														<?php } ?>

													</div>

						
						
														
													</div>


													<div class="tab-pane fade in" id="tab-style-01-03s">
												
													<div class="tab-inner tab-inner-edit">
														
														<?php if ($mevcutmenu==0) { ?>
												
												<h4 align="center">Yemek bulunamadı. Lütfen önce yemek ekleyin.</h4>			
                                                  
														<?php } else { ?>
                                                     
                                                       

														
							
							
							<div class="submite-list-box">

								

							<?php
                         
                         
							 $sira=0;

							 $menucesitsecfoto=$db->prepare("SELECT * from restoranmenucesit where restoran_id=:id");
							 $menucesitsecfoto->execute(array(

"id" => $restorancek['restoran_id']
							 ));



							while ($menucesitcekfoto=$menucesitsecfoto->fetch(PDO::FETCH_ASSOC)) { $sira++; $cesit_id=$menucesitcekfoto['cesit_id']; ?>
							 	<div>
								
									<h6 class="text-primary text-uppercase">Menü Kategori #<?php echo $sira; ?></h6>
									
									<div class="form-group form-group-lg">

										

										<input disabled="" type="text" value="<?php echo $menucesitcekfoto['cesit_ad']; ?>" class="form-control">
										
									</div>

									<?php $yemeksecfoto=$db->prepare("SELECT * from yemekler where yemek_cesit=:cesit");
									$yemeksecfoto->execute(array(

"cesit" => $cesit_id
									));

									while ($yemekcekfoto=$yemeksecfoto->fetch(PDO::FETCH_ASSOC)) { ?>
									 	
									


									

									<div style="padding-left: 23px;" class="food-menu-form-box food-menu-form-box-update clearfix fotoyemek_<?php echo $yemekcekfoto['yemek_id']; ?>">


										<div class="image-upload upload_<?php echo $yemekcekfoto['yemek_id']; ?>">
											

                 <?php if (empty($yemekcekfoto['yemek_foto'])) { ?>

                 	<div style="border-color:#043D75;" class="dropzone food-menu-image">
                 	
                 	
												<div class="dz-default dz-message"><span>Resim Seçmek İçin <br>Aşağıya</br>Tıkla veya Sürükle <i class="fas fa-arrow-down"></i><br /></span></div>

											</div>

               <?php  } else { ?>

               	<div style="position: relative;">

               <a class="yemekfotokaldir" href="javascript:void(0);" name="fotokaldir_<?php echo $yemekcekfoto['yemek_id']; ?>"><div style="position: absolute;right: 7px;top:-15px;"><i style="color:#DB3947;font-size: 18px;" class="fas fa-trash-alt"></i></div></a>

                 <img style="height: 125px;width: 125px;" src="<?php echo $yemekcekfoto['yemek_foto']; ?>">



                 </div>

              <?php } ?>

												
											
										</div>



										
									
										
										
										
										
										<div style="margin: 0;" class="food-memu-form">


										
											<div class="row gap-20">

											


											
												<div class="col-xss-12 col-xs-12 col-sm-9">


												
													<div class="form-group">
														<label>Yemek Adı</label>
														<input disabled="" type="text" value="<?php echo $yemekcekfoto['yemek_ad']; ?>" class="form-control"/>
													</div>
													
												</div>
												
												<div class="col-xss-12 col-xs-12 col-sm-3">
												
													<div class="form-group">
														<label>Fiyat</label>
														<div class="input-group">
															<input disabled="" type="text" value="<?php echo $yemekcekfoto['yemek_fiyat']; ?>" class="form-control">
															<span class="input-group-addon"><?php echo $currency; ?></span>
														</div>
													</div>
													
												</div>
												
												<div class="col-xss-12 col-xs-12 col-sm-6">
												
													<div class="form-group">
														<label>Kısa Açıklama</label>
														<input disabled="" type="text" value="<?php echo $yemekcekfoto['yemek_aciklama']; ?>"  class="form-control"/>
													</div>
													
												</div>

												

												<div class="col-xss-12 col-xs-12 col-sm-9">
												
													<div class="form-group">
														
														<input style="border:1px dashed #043D75;" type="file" name="fotoyemek_<?php echo $yemekcekfoto['yemek_id']; ?>" class="form-control fotoekleinput"/>
													</div>

													

													
													
												</div>

												


												
											
											</div>
											
										</div>

										
									</div>

									<?php } ?>

									<br><hr>



									


									

									
                                  
									
									
									
									
									
									
								</div>

							<?php }  ?>


								
								
								
							</div>

						
							
							
							
							

							

						
							
						


														<?php } ?>

													</div>

						
						
														
													</div>
													
												
												
												


												<div class="tab-pane fade" id="tab-style-01-02s">
													
													<div class="tab-inner">
														
														<?php if ($kalanmenu==0) { ?>
															
															<h4 align="center">10 menü kategorisi sınırına ulaştınız.</h4>

														<?php } else { ?>


														<form onsubmit="return false;" id="addmenuform">

														<div class="submite-list-box">

															

								

							<?php $sira=0;

							

							while ($sira<1) { $sira++; ?>
							 	<div  class="food-menu-form-wrapper food-menu-form-wrapper-add kategoriadd<?php echo $sira; ?>" id="id_<?php echo $sira; ?>">
								
									<h6 class="text-primary text-uppercase">Menü Kategori #<?php echo $sira; ?></h6>
									
									<div class="form-group form-group-lg">

										

										<input type="text" maxlength="30" placeholder="Örn. Çorba,Ana Yemek,Salatalar vs." class="form-control" name="menu_cesit_<?php echo $sira; ?>">
										
									</div>


									

									<div class="food-menu-form-box clearfix">
									
										
										<div class="icon">
											<i class="fa fa-cutlery text-primary"></i>
											<span class="number-label">1</span>
										</div>
										
										
										<div style="margin: 10px;" class="food-memu-form">
										
											<div class="row gap-20">
											
												<div class="col-xss-12 col-xs-12 col-sm-9">
												
													<div class="form-group">
														<label>Yemek Adı</label>
														<input type="text" name="menu_yemekad_<?php echo $sira; ?>_1" class="form-control"/>
													</div>
													
												</div>
												
												<div class="col-xss-12 col-xs-12 col-sm-3">
												
													<div class="form-group">
														<label>Fiyat</label>
														<div class="input-group">
															<input type="text" name="menu_yemekfiyat_<?php echo $sira; ?>_1" class="form-control">
															<span class="input-group-addon"><?php echo $currency; ?></span>
														</div>
													</div>
													
												</div>
												
												<div class="col-xss-12 col-xs-12 col-sm-12">
												
													<div class="form-group">
														<label>Kısa Açıklama</label>
														<input type="text" name="menu_yemekaciklama_<?php echo $sira; ?>_1" class="form-control"/>
													</div>
													
												</div>

												
											
											</div>
											
										</div>
										
									</div>

									
                                  
									
									
									
									
									<div class="clearfix mt-15">
										<a class="sutunekle" name="sutunekle_<?php echo $sira; ?>" href="javascript:void(0);"><i class="fa fa-plus-circle"  aria-hidden="true"></i></a>
										<span class="ml-5 font13 line-12 text-muted font-italic">Kategori başına 20 yemeğe kadar ekleyebilirsiniz.</span>
									</div>
									
								</div>

							<?php }  ?>

							<div class="text-center">
								<h6 class="text-primary text-uppercase mb-0"><a class="menukategoriekle" href="javascript:void(0);"><i class="fa fa-plus font14"></i> menü kategorisi ekle</a></h6>
								<p class="youhave">En fazla 10 kategoriye sahip olabilirsiniz.<br>(Mevcut <b><?php echo $mevcutmenu; ?></b>)</p>
							</div>

							<input type="hidden" name="addmenu">
							<input class="kalanmenu" type="hidden" value="<?php echo $kalanmenu; ?>" name="">
							<input type="hidden" value="<?php echo $restorancek['restoran_id']; ?>" name="restoran_id">

							<button id="addmenubutton" class="btn btn-primary">Ekle</button>




								
								
								
							</div>

							</form>

													


														<?php } ?>

													</div>
												</div>
												
												

											</div>
										
										</div>
									
									</div>
								
								</div>
						
							
							
							
					</div>

				</div>

			</div>
			
		</div>
		
	<?php require_once 'footer.php'; ?>
	<script type="text/javascript" src="js/jquery-ui.min.js"></script>
	<script type="text/javascript" src="js/jquery.ui.timepicker.js"></script>
	<script type="text/javascript">

		var currency=$('#currency').val();
		
		$('.silbuton').click(function(){


         	var name=$(this).attr('name');
         	var id = name.substring(5);
         	
swal({
  title: "Emin misiniz?",
  text: "Menü kategorisini tamamen silmek istiyor musunuz?",
  icon: "warning",
  buttons: ["Vazgeç", "Sil"],
  dangerMode: true,
})
.then((willDelete) => {
  if (willDelete) {
    

$.ajax({
            type : 'POST',
            url : 'ajax.php',
            data : {'menusil':'ok',"cesit_id":id},
            success : function(sonuc){

            	sonuc=$.trim(sonuc);

            	if (sonuc=="hata") {

swal({
  title: "Bir şeyler ters gitti.",
  icon: "error",
  button: "OK",
});

            	} else if (sonuc=="ok"){
               
               swal({
  title: "Başarılı",
  text: "Menü kategorisi başarıyla kaldırıldı.",
  icon: "success",
  button: "OK",
});

               $('.menu_'+id).remove();


               var kalanmenu = parseInt($('.kalanmenu').val());
               $('.kalanmenu').val(parseInt(kalanmenu+1));

               var mevcut = 10-(parseInt($('.kalanmenu').val()));


               if (parseInt($('.kalanmenu').val())==10) {

               	$('.tab-inner-edit').html('<h4 align="center">Menü bulunamadı. Lütfen önce menü ekleyin.</h4>');
               }


               $('.youhave').html('En fazla 10 menü kategorisine sahip olabilirsiniz<br>(Mevcut <b>'+mevcut+'</b>)')


               

             

               

            	}

               

       

            }
        })


  } 
});


         });

		$('.yemeksilbuton').click(function(){

         	var name=$(this).attr('name');
         	var id = name.substring(6);
         	
swal({
  title: "Emin misiniz?",
  text: "Bu yemeği kaldırmak istiyor musunuz?",
  icon: "warning",
  buttons: ["Vazgeç", "Sil"],
  dangerMode: true,
})
.then((willDelete) => {
  if (willDelete) {
    

$.ajax({
            type : 'POST',
            url : 'ajax.php',
            data : {'yemeksil':'ok',"yemek_id":id},
            success : function(sonuc){

            	sonuc=$.trim(sonuc);

            	if (sonuc=="hata") {

swal({
  title: "Bir şeyler ters gitti.",
  icon: "error",
  button: "OK",
});

            	} else if (sonuc=="ok"){
               
              swal({
  title: "Başarılı",
  text: "Yemek başarıyla kaldırıldı.",
  icon: "success",
  button: "OK",
});

              $('.yemek_'+id).remove();
              $('.fotoyemek_'+id).remove();


            	}

               

       

            }
        })


  } 
});


         });

		$('.sutunekleupdate').click(function(){


			



var name = $(this).attr('name');
  var menuno = name.substring(10);
  var yemekno =  $('.kategori'+menuno+' .food-menu-form-box-update').length+1;

  if ($('.kategori'+menuno+' .food-menu-form-box-update').length<20) { 

$('.kategori'+menuno+' .food-menu-form-box-update').last().after('<div style="padding-left: 23px;position:relative;" class="food-menu-form-box food-menu-form-box-update clearfix"><div style="margin: 0;" class="food-memu-form"><div class="row gap-20"><div class="col-xss-12 col-xs-12 col-sm-9"><div class="form-group"><label>Yemek Adı</label><input type="text"  name="menu_yemekad_'+menuno+'_'+yemekno+'" class="form-control yemek_ad"/></div></div><div class="col-xss-12 col-xs-12 col-sm-3"><div class="form-group"><label>Fiyat</label><div class="input-group"><input type="text" name="menu_yemekfiyat_'+menuno+'_'+yemekno+'" class="form-control yemek_fiyat"><span class="input-group-addon">'+currency+'</span></div></div></div><div class="col-xss-12 col-xs-12 col-sm-12"><div class="form-group">	<label>Kısa Açıklama</label><input type="text"  name="menu_yemekaciklama_'+menuno+'_'+yemekno+'" class="form-control"/></div></div></div></div></div>');

   };

   //Created by emrhnynr1

  

		});

		$('.sutuncikarupdate').click(function(){

var name = $(this).attr('name');
  var menuno = name.substring(11);

  if ($('.kategori'+menuno+' .food-menu-form-box-update').last().hasClass('default')==false) {
 
 $('.kategori'+menuno+' .food-menu-form-box-update').last().remove();

};


		})

		$('#menuupdatebutton').click(function(){

$('#menuupdatebutton').prop('disabled',true);

var form = $('#menuupdateform')[0];
var data = new FormData(form);


var bosmenutitle = $('.menu_title').filter(function(){
    return !$.trim($(this).val());
}).length;

var bosyemekad = $('.yemek_ad').filter(function(){
    return !$.trim($(this).val());
}).length;

var bosyemekfiyat = $('.yemek_fiyat').filter(function(){
    return !$.trim($(this).val());
}).length;

if (bosmenutitle>0) {
$('#menuupdatebutton').prop('disabled',false);
swal({
  title: "Uyarı",
  text: "Hiçbir menü başlığı boş kalamaz.",
  icon: "info",
  button: "OK",
});


} else if (bosyemekad>0){
$('#menuupdatebutton').prop('disabled',false);
swal({
  title: "Uyarı",
  text: "Hiçbir yemek adı boş kalamaz.",
  icon: "info",
  button: "OK",
});

} else if (bosyemekfiyat){
$('#menuupdatebutton').prop('disabled',false);
swal({
  title: "Uyarı",
  text: "Hiçbir yemek fiyatı boş kalamaz.",
  icon: "info",
  button: "OK",
});

} else {

	$('#menuupdatebutton').html("<img style='width:18px;height:18px;' src='css/images/flex-loader.gif'>");

$.ajax({
           type : 'POST',
            url : 'ajax.php',
            enctype : 'multipart/form-data',
            data : data,
            processData: false,
            contentType: false,
            cache: false,
            success : function(sonuc){

            	sonuc=$.trim(sonuc);


if (sonuc=="ok") {


window.location = 'menu-settings?update=ok';

}


               

       
               

            }
        })

}

		});

		$('.sutunekle').click(function(){

var name=$(this).attr('name');
  var menuno = name.substring(10);
  var yemekno=  $('.kategoriadd'+menuno+' .food-menu-form-box').length+1;
 

if ($('.kategoriadd'+menuno+' .food-menu-form-box').length<20) {

 $('.kategoriadd'+menuno+' .food-menu-form-box').last().after('<div class="food-menu-form-box clearfix"><div class="icon"><i class="fa fa-cutlery text-primary"></i><span class="number-label">'+yemekno+'</span></div><div style="margin: 10px;" class="food-memu-form"><div class="row gap-20"><div class="col-xss-12 col-xs-12 col-sm-9"><div class="form-group"><label>Yemek Adı</label><input name="menu_yemekad_'+menuno+'_'+yemekno+'" type="text" class="form-control"/></div></div><div class="col-xss-12 col-xs-12 col-sm-3"><div class="form-group"><label>Fiyat</label><div class="input-group"><input name="menu_yemekfiyat_'+menuno+'_'+yemekno+'" type="text"  class="form-control"><span class="input-group-addon">'+currency+'</span></div></div></div><div class="col-xss-12 col-xs-12 col-sm-12"><div class="form-group"><label>Kısa Açıklama</label><input name="menu_yemekaciklama_'+menuno+'_'+yemekno+'" type="text"  class="form-control"/></div></div></div></div></div>');



 }
 

});

		$('.menukategoriekle').click(function(){



			var id = $('.food-menu-form-wrapper-add').last().attr('id').substring(3);
           var yeni_id = parseInt(id)+1;

         

           var kalanmenu = parseInt($('.kalanmenu').val());


         


           if (id<kalanmenu) {

           

           $('.food-menu-form-wrapper-add:last').after('<div id="id_'+yeni_id+'" class="food-menu-form-wrapper food-menu-form-wrapper-add kategoriadd'+yeni_id+'"><h6 class="text-primary text-uppercase">Menü Kategori #'+yeni_id+'</h6><div class="form-group form-group-lg"><input type="text" maxlength="30" placeholder="Örn. Çorba,Ana Yemek,Salatalar vs." class="form-control" name="menu_cesit_'+yeni_id+'"></div>	<div class="food-menu-form-box clearfix"><div class="icon"><i class="fa fa-cutlery text-primary"></i><span class="number-label">1</span></div><div style="margin: 10px;" class="food-memu-form"><div class="row gap-20"><div class="col-xss-12 col-xs-12 col-sm-9"><div class="form-group"><label>Yemek Adı</label><input type="text" name="menu_yemekad_'+yeni_id+'_1" class="form-control"/></div></div><div class="col-xss-12 col-xs-12 col-sm-3"><div class="form-group"><label>Fiyat</label><div class="input-group"><input type="text" name="menu_yemekfiyat_'+yeni_id+'_1" class="form-control"><span class="input-group-addon">'+currency+'</span></div></div></div><div class="col-xss-12 col-xs-12 col-sm-12"><div class="form-group"><label>Kısa Açıklama</label><input type="text" name="menu_yemekaciklama_'+yeni_id+'_1" class="form-control"/></div></div></div></div></div><div class="clearfix mt-15"><a href="javascript:void(0);" class="sutunekle_'+yeni_id+'" name="sutunekle_'+yeni_id+'" ><i class="fa fa-plus-circle"  aria-hidden="true"></i></a><span class="ml-5 font13 line-12 text-muted font-italic">Kategori başına 20 yemeğe kadar ekleyebilirsiniz.</span></div></div>');

           $('.sutunekle_'+yeni_id).click(function(){


var name=$(this).attr('name');
  var menuno = name.substring(10);
  var yemekno =  $('.kategoriadd'+menuno+' .food-menu-form-box').length+1;
 

if ($('.kategoriadd'+menuno+' .food-menu-form-box').length<20) {

 $('.kategoriadd'+menuno+' .food-menu-form-box').last().after('<div class="food-menu-form-box clearfix"><div class="icon"><i class="fa fa-cutlery text-primary"></i><span class="number-label">'+yemekno+'</span></div><div style="margin: 10px;" class="food-memu-form"><div class="row gap-20"><div class="col-xss-12 col-xs-12 col-sm-9"><div class="form-group"><label>Yemek Adı</label><input name="menu_yemekad_'+menuno+'_'+yemekno+'" type="text" class="form-control"/></div></div><div class="col-xss-12 col-xs-12 col-sm-3"><div class="form-group"><label>Fiyat</label><div class="input-group"><input name="menu_yemekfiyat_'+menuno+'_'+yemekno+'" type="text"  class="form-control"><span class="input-group-addon">'+currency+'</span></div></div></div><div class="col-xss-12 col-xs-12 col-sm-12"><div class="form-group"><label>Kısa Açıklama</label><input name="menu_yemekaciklama_'+menuno+'_'+yemekno+'" type="text"  class="form-control"/></div></div></div></div></div>');



 }


	})

           }
		})


		$('#addmenubutton').click(function(){

			var form = $('#addmenuform')[0];
           var data = new FormData(form);

			$('#addmenubutton').prop('disabled',true);
			$('#addmenubutton').html("<img align='center' style='width:18px;height:18px;' src='css/images/flex-loader.gif'>");
			

$.ajax({
            type : 'POST',
            url : 'ajax.php',
            enctype : 'multipart/form-data',
            data : data,
            processData: false,
            contentType: false,
            cache: false,
            success : function(sonuc){

            	  sonuc=$.trim(sonuc);

            	window.location='menu-settings?addmenu=ok';
               
            }
        })


		});

		$('.fotoekleinput').change(function(){

			
            var input = $(this);
            
           

			var foto = $(this).val();
			var filevalue = $(this).get(0).files[0];

			

			if (foto.length!=0) {
              
				input.prop("disabled", true);


            var fotouzanti=foto.split('.').pop();
            var id1=$(this).attr("name");

                var yemek_id=id1.substring(10);

                $('.upload_'+yemek_id).html("<h5 style='text-align:center;margin-top:50px;'>Yükleniyor...</h5>");
               
               
             var data = new FormData();
             data.append('yemekidhidden',yemek_id);
             data.append('yemekfotoekle',"ok");
             data.append("file",filevalue);
             

            if (fotouzanti!='jpg' && fotouzanti!='jpeg' && fotouzanti!='png'){


           swal({

  title: "Bilgi",
  text: "Sadece jpg, jpeg, png uzantılı dosyaları yükleyebilirsiniz.",
  icon: "info",
  button: "OK",
});


            	 } else {

            	 	 $.ajax({
            type : 'POST',
            url : 'ajax.php',
            enctype : 'multipart/form-data',
            data : data,
            processData: false,
            contentType: false,
            cache: false,
            success : function(sonuc){

sonuc=$.trim(sonuc);

$('.upload_'+yemek_id).html(sonuc);

input.val('');
input.prop("disabled", false)

$('.yemekfotokaldir').click(function(){

 var id1=$(this).attr("name");
                var yemek_id=id1.substring(11);

               swal({
  title: "Bu yemeğin resmini kaldırmak istediğinize emin misiniz?",
  icon: "warning",
  buttons: ["Vazgeç", "Sil"],
  dangerMode: true,
})
.then((willDelete) => {
  if (willDelete) {

  	$.ajax({

	 type : 'POST',
            url : 'ajax.php',
            data : {'yemekfotokaldir':'ok','yemek_id':yemek_id},
            success : function(sonuc){

            	sonuc=$.trim(sonuc);


if (sonuc=="ok") {


$('.upload_'+yemek_id).html('<div style="border-color:#043D75;" class="dropzone food-menu-image"><input name="file" type="file"><div class="dz-default dz-message"><span>Resim Seçmek İçin <br>Aşağıya</br>Tıkla veya Sürükle <i class="fas fa-arrow-down"></i><br /></span></div></div>');



}



            	 }

            	 })

  	 }

  	 })

		})



            	 }
            
			});


            	 }
            

            

             }







		});


		$('.yemekfotokaldir').click(function(){

 var id1=$(this).attr("name");
                var yemek_id=id1.substring(11);

               swal({
  title: "Bu yemeğin resmini kaldırmak istediğinize emin misiniz?",
  icon: "warning",
  buttons: ["Vazgeç", "Sil"],
  dangerMode: true,
})
.then((willDelete) => {
  if (willDelete) {

  	$.ajax({

	 type : 'POST',
            url : 'ajax.php',
            data : {'yemekfotokaldir':'ok','yemek_id':yemek_id},
            success : function(sonuc){

            	sonuc=$.trim(sonuc);


if (sonuc=="ok") {


$('.upload_'+yemek_id).html('<div style="border-color:#043D75;" class="dropzone food-menu-image"><input name="file" type="file"><div class="dz-default dz-message"><span>Resim Seçmek İçin <br>Aşağıya</br>Tıkla veya Sürükle <i class="fas fa-arrow-down"></i><br /></span></div></div>');



}



            	 }

            	 })

  	 }

  	 })

		});

		$('.menuaciklama').click(function(){


var menuaciklama = $.trim($('#menuaciklama').val());



 



	$('.menuaciklama').prop('disabled', true);

	 var restoran_id=$('#restoran_id').val();

	 $.ajax({
            type : 'POST',
            url : 'ajax.php',
            data : {'menuaciklamagir':'ok','restoran_id':restoran_id,'menuaciklama':menuaciklama},
            success : function(sonuc){

            	

              sonuc=$.trim(sonuc);

               swal({
  title: "Başarılı",
  text: "Menü açıklaması güncellendi.",
  icon: "success",
  button: "OK",

});

     $('.menuaciklama').prop('disabled', false);

               
            }
        })


	  

		})


	

	</script>




