<!-- start Footer Wrapper -->
		<div align="center" class="footer-wrapper scrollspy-footer">
		

			
			<footer class="main-footer">
				
			
				<div  class="container">
				
					<div class="row">
					
						
						
						<div class="col-xs-12 col-sm-12 col-md-10">
						
							<div  class="pl-wrapper">
							
								<div  class="row">
								

									
									
									<div class="clear"></div>
									
									<div  class="col-xss-12 col-xs-12 col-sm-12 col-md-12 mb-12-xss">
									
										<h4 class="footer-title">Şirket</h4>
										<ul class="menu-footer clearfix">
											
											
											
											<li><a href="contact">İletişim</a></li>
											<li><a href="privacy-policy">Gizlilik</a></li>
											<li><a href="terms-conditions">Topluluk Sözleşmesi</a></li>
											
											
										</ul>
										
									</div>
									
									
									
									
								</div>

							</div>
						
						</div>
						
					</div>
					
				</div>
				
			
			</footer>
			
			<footer class="secondary-footer">
			
				<div align="center" class="container">

					<img style="width: 190px;height: 40px;" src="images/logo-white.png" alt="Image" />
				
					
					<p class="copy-right"> 2021 &#169; Tüm hakları saklıdır.</p>

				
				</div>
				
			</footer>
			
		</div>
		<!-- end Footer Wrapper -->
		
	</div> 
	<!-- end Container Wrapper -->
 


<div id="ajaxLoginModal" class="modal fade login-box-wrapper" data-width="500" data-backdrop="static" data-keyboard="false" tabindex="-1" style="display: none;"></div>
		
<div id="ajaxRegisterModal" class="modal fade login-box-wrapper" data-width="500" data-backdrop="static" data-keyboard="false" tabindex="-1" style="display: none;">
</div>

<div id="ajaxForgotPasswordModal" class="modal fade login-box-wrapper" data-width="500" data-backdrop="static" data-keyboard="false" tabindex="-1" style="display: none;"></div>

 
<!-- JS -->
<script type="text/javascript" src="js/jquery-2.2.4.min.js"></script>
<script type="text/javascript" src="js/jquery-migrate-1.4.1.min.js"></script>
<script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/SmoothScroll.min.js"></script>
<script type="text/javascript" src="js/jquery.waypoints.min.js"></script>
<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="js/jquery.slicknav.min.js"></script>
<script type="text/javascript" src="js/spin.min.js"></script>
<script type="text/javascript" src="js/jquery.introLoader.min.js"></script>
<script type="text/javascript" src="js/fancySelect.js"></script>
<script type="text/javascript" src="js/bootstrap-rating.js"></script> 
<script type="text/javascript" src="js/select2.full.js"></script>
<script type="text/javascript" src="js/slick.min.js"></script>
<script type="text/javascript" src="js/jquery.placeholder.min.js"></script>
<script type="text/javascript" src="js/ion.rangeSlider.min.js"></script>
<script type="text/javascript" src="js/readmore.min.js"></script>
<script type="text/javascript" src="js/bootstrap-modalmanager.js"></script>
<script type="text/javascript" src="js/bootstrap-modal.js"></script>
<script type="text/javascript" src="js/instagram.min.js"></script>
<script type="text/javascript" src="js/customs.js"></script>
<script type="text/javascript" src="js/sweetalert.min.js"></script>
<script src="js/jquery.magnific-popup.js"></script>



</body>


</html>
