<?php require_once 'header.php';

if ($kullanicioturumcek['kullanici_yetki']!=5 or $uyelik_turu=='expired') {
	header("Location:/");
}



 ?>

 <title>Üyelik</title>

 <head><style type="text/css">
 	.bulk-actions {
  display: none; }

table.countries_list {
  width: 100%; }

table.countries_list td {
  padding: 0 10px;
  line-height: 30px;
  border-top: 1px solid #eeeeee; }

.dataTables_paginate a {
  padding: 6px 9px !important;
  background: #ddd !important;
  border-color: #ddd !important; }

.paging_full_numbers a.paginate_active {
  background-color: rgba(38, 185, 154, 0.59) !important;
  border-color: rgba(38, 185, 154, 0.59) !important; }

button.DTTT_button, div.DTTT_button, a.DTTT_button {
  border: 1px solid #E7E7E7 !important;
  background: #E7E7E7 !important;
  box-shadow: none !important; }

table.jambo_table {
  border: 1px solid rgba(221, 221, 221, 0.78); }

table.jambo_table thead {
  background: rgba(52, 73, 94, 0.94);
  color: #ECF0F1; }

table.jambo_table tbody tr:hover td {
  background: rgba(38, 185, 154, 0.07);
  border-top: 1px solid rgba(38, 185, 154, 0.11);
  border-bottom: 1px solid rgba(38, 185, 154, 0.11); }

table.jambo_table tbody tr.selected {
  background: rgba(38, 185, 154, 0.16); }

table.jambo_table tbody tr.selected td {
  border-top: 1px solid rgba(38, 185, 154, 0.4);
  border-bottom: 1px solid rgba(38, 185, 154, 0.4); }

.dataTables_paginate a {
  background: #ff0000; }

.dataTables_wrapper {
  position: relative;
  clear: both;
  zoom: 1; }

.dataTables_processing {
  position: absolute;
  top: 50%;
  left: 50%;
  width: 250px;
  height: 30px;
  margin-left: -125px;
  margin-top: -15px;
  padding: 14px 0 2px 0;
  border: 1px solid #ddd;
  text-align: center;
  color: #999;
  font-size: 14px;
  background-color: white; }

.dataTables_length {
  width: 40%;
  float: left; }

.dataTables_filter {
  width: 50%;
  float: right;
  text-align: right; }

.dataTables_info {
  width: 60%;
  float: left; }

.dataTables_paginate {
  float: right;
  text-align: right; }

table.dataTable th.focus,
table.dataTable td.focus {
  outline: 2px solid #1ABB9C !important;
  outline-offset: -1px; }

table.display {
  margin: 0 auto;
  clear: both;
  width: 100%; }

table.display thead th {
  padding: 8px 18px 8px 10px;
  border-bottom: 1px solid black;
  font-weight: bold;
  cursor: pointer; }

table.display tfoot th {
  padding: 3px 18px 3px 10px;
  border-top: 1px solid black;
  font-weight: bold; }

table.display tr.heading2 td {
  border-bottom: 1px solid #aaa; }

table.display td {
  padding: 3px 10px; }

table.display td.center {
  text-align: center; }

table.display thead th:active, table.display thead td:active {
  outline: none; }

.dataTables_scroll {
  clear: both; }

.dataTables_scrollBody {
  *margin-top: -1px;
  -webkit-overflow-scrolling: touch; }

.top .dataTables_info {
  float: none; }

.clear {
  clear: both; }

.dataTables_empty {
  text-align: center; }

tfoot input {
  margin: 0.5em 0;
  width: 100%;
  color: #444; }

tfoot input.search_init {
  color: #999; }

td.group {
  background-color: #d1cfd0;
  border-bottom: 2px solid #A19B9E;
  border-top: 2px solid #A19B9E; }

td.details {
  background-color: #d1cfd0;
  border: 2px solid #A19B9E; }

.example_alt_pagination div.dataTables_info {
  width: 40%; }

.paging_full_numbers {
  width: 400px;
  height: 22px;
  line-height: 22px; }

.paging_full_numbers a:active {
  outline: none; }

.paging_full_numbers a:hover {
  text-decoration: none; }

.paging_full_numbers a.paginate_button, .paging_full_numbers a.paginate_active {
  border: 1px solid #aaa;
  -webkit-border-radius: 5px;
  -moz-border-radius: 5px;
  padding: 2px 5px;
  margin: 0 3px;
  cursor: pointer; }

.paging_full_numbers a.paginate_button {
  background-color: #ddd; }

.paging_full_numbers a.paginate_button:hover {
  background-color: #ccc;
  text-decoration: none !important; }

.paging_full_numbers a.paginate_active {
  background-color: #99B3FF; }

table.display tr.even.row_selected td {
  background-color: #B0BED9; }

table.display tr.odd.row_selected td {
  background-color: #9FAFD1; }

div.box {
  height: 100px;
  padding: 10px;
  overflow: auto;
  border: 1px solid #8080FF;
  background-color: #E5E5FF; }

  

@media only screen and (max-width: 800px) {

.tablepc {

  display: none;
}

    }

    @media only screen and (min-width: 801px) {

.tablemobil {

display: none;

  }

    }

 </style></head>

 <div class="main-wrapper scrollspy-container">
		
			<!-- start hero-header -->
			

			<div class="container pt-10 pb-60">

        <div style="margin-top: 30px;" class="section-title-02">

          <?php $baslangic14=date("Y-m-d H:i:s",strtotime('+14 days',strtotime($kullanicioturumcek['uyelik_baslangic'])));
          $bitis=$kullanicioturumcek['uyelik_bitis']; ?>



              

              <h3><span>ÜYELİK DETAYLARI</span></h3>
             
          
            </div>
			
				
						
				<div  class="mt-40">
					
					<div style="margin-top:70px;" class="table-responsive tablepc">
                      <table class="table table-striped jambo_table bulk_action">
                        <thead>
                          <tr class="headings">
                            
                            <th style="text-align: center;" class="column-title">Üyelik Modeli </th>
                            <th style="text-align: center;" class="column-title">Üyelik Başlangıcı </th>
                            <th style="text-align: center;" class="column-title">Üyelik Bitişi </th>
                           
                            
                           
                           
                            
              
                          </tr>
                        </thead>

                        <tbody>
                          <tr class="even pointer">
                            
                            <td align="center" class=" "><b><?php switch ($uyelik_turu) {
                            	case '1':
                            		echo "QR Menü";
                            		break;
                            	
                            	case '2':
                            		echo "Ön Sipariş";
                            		break;

                            		case '3':
                            		echo "QR Menü Sipariş";
                            		break;

                            		case '4':
                            		echo "QR Menü Sipariş + Ön Sipariş";
                            		break;
                            } ?></b></td>
                            <td align="center" class=" "><b><?php switch (substr($kullanicioturumcek['uyelik_baslangic'],5,2)) {

														case '01':
															echo substr($kullanicioturumcek['uyelik_baslangic'],8,2)." Ocak ".substr($kullanicioturumcek['uyelik_baslangic'],0,4);
															break;

														case '02':
															echo substr($kullanicioturumcek['uyelik_baslangic'],8,2)." Şubat ".substr($kullanicioturumcek['uyelik_baslangic'],0,4);
															break;

															case '03':
															echo substr($kullanicioturumcek['uyelik_baslangic'],8,2)." Mart ".substr($kullanicioturumcek['uyelik_baslangic'],0,4);
															break;

															case '04':
															echo substr($kullanicioturumcek['uyelik_baslangic'],8,2)." Nisan ".substr($kullanicioturumcek['uyelik_baslangic'],0,4);
															break;

															case '05':
															echo substr($kullanicioturumcek['uyelik_baslangic'],8,2)." Mayıs ".substr($kullanicioturumcek['uyelik_baslangic'],0,4);
															break;

															case '06':
															echo substr($kullanicioturumcek['uyelik_baslangic'],8,2)." Haziran ".substr($kullanicioturumcek['uyelik_baslangic'],0,4);
															break;

															case '07':
															echo substr($kullanicioturumcek['uyelik_baslangic'],8,2)." Temmuz ".substr($kullanicioturumcek['uyelik_baslangic'],0,4);
															break;

															case '08':
															echo substr($kullanicioturumcek['uyelik_baslangic'],8,2)." Ağustos ".substr($kullanicioturumcek['uyelik_baslangic'],0,4);
															break;

															case '09':
															echo substr($kullanicioturumcek['uyelik_baslangic'],8,2)." Eylül ".substr($kullanicioturumcek['uyelik_baslangic'],0,4);
															break;

															case '10':
															echo substr($kullanicioturumcek['uyelik_baslangic'],8,2)." Ekim ".substr($kullanicioturumcek['uyelik_baslangic'],0,4);
															break;

															case '11':
															echo substr($kullanicioturumcek['uyelik_baslangic'],8,2)." Kasım ".substr($kullanicioturumcek['uyelik_baslangic'],0,4);
															break;


															case '12':
															echo substr($kullanicioturumcek['uyelik_baslangic'],8,2)." Aralık ".substr($kullanicioturumcek['uyelik_baslangic'],0,4);
															break;
														
													} ?></b></td>
                            <td align="center" class=" "><b><?php switch (substr($kullanicioturumcek['uyelik_bitis'],5,2)) {

														case '01':
															echo substr($kullanicioturumcek['uyelik_bitis'],8,2)." Ocak ".substr($kullanicioturumcek['uyelik_bitis'],0,4);
															break;

														case '02':
															echo substr($kullanicioturumcek['uyelik_bitis'],8,2)." Şubat ".substr($kullanicioturumcek['uyelik_bitis'],0,4);
															break;

															case '03':
															echo substr($kullanicioturumcek['uyelik_bitis'],8,2)." Mart ".substr($kullanicioturumcek['uyelik_bitis'],0,4);
															break;

															case '04':
															echo substr($kullanicioturumcek['uyelik_bitis'],8,2)." Nisan ".substr($kullanicioturumcek['uyelik_bitis'],0,4);
															break;

															case '05':
															echo substr($kullanicioturumcek['uyelik_bitis'],8,2)." Mayıs ".substr($kullanicioturumcek['uyelik_bitis'],0,4);
															break;

															case '06':
															echo substr($kullanicioturumcek['uyelik_bitis'],8,2)." Haziran ".substr($kullanicioturumcek['uyelik_bitis'],0,4);
															break;

															case '07':
															echo substr($kullanicioturumcek['uyelik_bitis'],8,2)." Temmuz ".substr($kullanicioturumcek['uyelik_bitis'],0,4);
															break;

															case '08':
															echo substr($kullanicioturumcek['uyelik_bitis'],8,2)." Ağustos ".substr($kullanicioturumcek['uyelik_bitis'],0,4);
															break;

															case '09':
															echo substr($kullanicioturumcek['uyelik_bitis'],8,2)." Eylül ".substr($kullanicioturumcek['uyelik_bitis'],0,4);
															break;

															case '10':
															echo substr($kullanicioturumcek['uyelik_bitis'],8,2)." Ekim ".substr($kullanicioturumcek['uyelik_bitis'],0,4);
															break;

															case '11':
															echo substr($kullanicioturumcek['uyelik_bitis'],8,2)." Kasım ".substr($kullanicioturumcek['uyelik_bitis'],0,4);
															break;


															case '12':
															echo substr($kullanicioturumcek['uyelik_bitis'],8,2)." Aralık ".substr($kullanicioturumcek['uyelik_bitis'],0,4);
															break;
														
													} ?></b></td>
                           
                           
                            
                            </td>
                            <?php if ($baslangic14!=$bitis) { ?>
                             <td align="center"><a href='javascript:void(0);' style="font-weight: bold;">Otomatik Ödemeyi İptal Et</a></td>
                           <?php } ?>
                            
                          </tr>
                         
                        </tbody>
                      </table>

                      
                    </div>

                    <div style="margin-top:40px;" class="table-responsive tablemobil">
                      <table class="table table-striped jambo_table bulk_action">
                        <thead>
                          <tr class="headings">
                           
                            <th style="text-align: center;" class="column-title">Üyelik Modeli </th>
                            
                           
                            
                           
                           
                            
              
                          </tr>
                        </thead>

                        <tbody>
                          <tr class="even pointer">
                            
                            <td align="center" class=" "><b><?php switch ($uyelik_turu) {
                              case '1':
                                echo "QR Menü";
                                break;
                              
                              case '2':
                                echo "Ön Sipariş";
                                break;

                                case '3':
                                echo "QR Menü Sipariş";
                                break;

                                case '4':
                                echo "QR Menü Sipariş + Ön Sipariş";
                                break;
                            } ?></b></td>
                            
                           
                           
                            
                            
                            
                            
                          </tr>
                         
                        </tbody>
                      </table>

                      
                    </div>

                    <div style="margin-top:40px;" class="table-responsive tablemobil">
                      <table class="table table-striped jambo_table bulk_action">
                        <thead>
                          <tr class="headings">
                           
                            <th style="text-align: center;" class="column-title">Üyelik Başlangıç </th>
                            
                           
                            
                           
                           
                            
              
                          </tr>
                        </thead>

                        <tbody>
                          <tr class="even pointer">
                            
                           <td align="center" class=" "><b><?php switch (substr($kullanicioturumcek['uyelik_baslangic'],5,2)) {

                            case '01':
                              echo substr($kullanicioturumcek['uyelik_baslangic'],8,2)." Ocak ".substr($kullanicioturumcek['uyelik_baslangic'],0,4);
                              break;

                            case '02':
                              echo substr($kullanicioturumcek['uyelik_baslangic'],8,2)." Şubat ".substr($kullanicioturumcek['uyelik_baslangic'],0,4);
                              break;

                              case '03':
                              echo substr($kullanicioturumcek['uyelik_baslangic'],8,2)." Mart ".substr($kullanicioturumcek['uyelik_baslangic'],0,4);
                              break;

                              case '04':
                              echo substr($kullanicioturumcek['uyelik_baslangic'],8,2)." Nisan ".substr($kullanicioturumcek['uyelik_baslangic'],0,4);
                              break;

                              case '05':
                              echo substr($kullanicioturumcek['uyelik_baslangic'],8,2)." Mayıs ".substr($kullanicioturumcek['uyelik_baslangic'],0,4);
                              break;

                              case '06':
                              echo substr($kullanicioturumcek['uyelik_baslangic'],8,2)." Haziran ".substr($kullanicioturumcek['uyelik_baslangic'],0,4);
                              break;

                              case '07':
                              echo substr($kullanicioturumcek['uyelik_baslangic'],8,2)." Temmuz ".substr($kullanicioturumcek['uyelik_baslangic'],0,4);
                              break;

                              case '08':
                              echo substr($kullanicioturumcek['uyelik_baslangic'],8,2)." Ağustos ".substr($kullanicioturumcek['uyelik_baslangic'],0,4);
                              break;

                              case '09':
                              echo substr($kullanicioturumcek['uyelik_baslangic'],8,2)." Eylül ".substr($kullanicioturumcek['uyelik_baslangic'],0,4);
                              break;

                              case '10':
                              echo substr($kullanicioturumcek['uyelik_baslangic'],8,2)." Ekim ".substr($kullanicioturumcek['uyelik_baslangic'],0,4);
                              break;

                              case '11':
                              echo substr($kullanicioturumcek['uyelik_baslangic'],8,2)." Kasım ".substr($kullanicioturumcek['uyelik_baslangic'],0,4);
                              break;


                              case '12':
                              echo substr($kullanicioturumcek['uyelik_baslangic'],8,2)." Aralık ".substr($kullanicioturumcek['uyelik_baslangic'],0,4);
                              break;
                            
                          } ?></b></td>
                            
                           
                           
                            
                            
                            
                            
                          </tr>
                         
                        </tbody>
                      </table>

                      
                    </div>

                    <div style="margin-top:40px;" class="table-responsive tablemobil">
                      <table class="table table-striped jambo_table bulk_action">
                        <thead>
                          <tr class="headings">
                           
                            <th style="text-align: center;" class="column-title">Üyelik Bitiş </th>
                            
                           
                            
                           
                           
                            
              
                          </tr>
                        </thead>

                        <tbody>
                          <tr class="even pointer">
                            
                            <td align="center" class=" "><b><?php switch (substr($kullanicioturumcek['uyelik_bitis'],5,2)) {

                            case '01':
                              echo substr($kullanicioturumcek['uyelik_bitis'],8,2)." Ocak ".substr($kullanicioturumcek['uyelik_bitis'],0,4);
                              break;

                            case '02':
                              echo substr($kullanicioturumcek['uyelik_bitis'],8,2)." Şubat ".substr($kullanicioturumcek['uyelik_bitis'],0,4);
                              break;

                              case '03':
                              echo substr($kullanicioturumcek['uyelik_bitis'],8,2)." Mart ".substr($kullanicioturumcek['uyelik_bitis'],0,4);
                              break;

                              case '04':
                              echo substr($kullanicioturumcek['uyelik_bitis'],8,2)." Nisan ".substr($kullanicioturumcek['uyelik_bitis'],0,4);
                              break;

                              case '05':
                              echo substr($kullanicioturumcek['uyelik_bitis'],8,2)." Mayıs ".substr($kullanicioturumcek['uyelik_bitis'],0,4);
                              break;

                              case '06':
                              echo substr($kullanicioturumcek['uyelik_bitis'],8,2)." Haziran ".substr($kullanicioturumcek['uyelik_bitis'],0,4);
                              break;

                              case '07':
                              echo substr($kullanicioturumcek['uyelik_bitis'],8,2)." Temmuz ".substr($kullanicioturumcek['uyelik_bitis'],0,4);
                              break;

                              case '08':
                              echo substr($kullanicioturumcek['uyelik_bitis'],8,2)." Ağustos ".substr($kullanicioturumcek['uyelik_bitis'],0,4);
                              break;

                              case '09':
                              echo substr($kullanicioturumcek['uyelik_bitis'],8,2)." Eylül ".substr($kullanicioturumcek['uyelik_bitis'],0,4);
                              break;

                              case '10':
                              echo substr($kullanicioturumcek['uyelik_bitis'],8,2)." Ekim ".substr($kullanicioturumcek['uyelik_bitis'],0,4);
                              break;

                              case '11':
                              echo substr($kullanicioturumcek['uyelik_bitis'],8,2)." Kasım ".substr($kullanicioturumcek['uyelik_bitis'],0,4);
                              break;


                              case '12':
                              echo substr($kullanicioturumcek['uyelik_bitis'],8,2)." Aralık ".substr($kullanicioturumcek['uyelik_bitis'],0,4);
                              break;
                            
                          } ?></b></td>
                            
                           
                           
                            
                            
                            
                            
                          </tr>
                         
                        </tbody>
                      </table>

                      
                    </div>

                    <?php if ($baslangic14!=$bitis) { ?>


                    <div style="margin-top:40px;" class="table-responsive tablemobil">
                      <table class="table table-striped jambo_table bulk_action">
                        <thead>
                          <tr class="headings">
                           
                          
                            
                           
                            
                            
                             
                           
                           
                            
              
                          </tr>
                        </thead>

                        <tbody>
                          <tr class="even pointer">
                            
                            
                            <td align="center"><a href='javascript:void(0);' style="font-weight: bold;">Otomatik Ödemeyi İptal Et</a></td>
                           
                           
                            
                            
                            
                            
                          </tr>
                         
                        </tbody>
                      </table>

                      
                    </div>

                    <?php } ?>
				</div>
				
			</div>
			
			
			
			

			
			
			
		</div>




<?php require_once 'footer.php'; ?>