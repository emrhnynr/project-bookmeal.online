<div class="modal-header">
	<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
	<h4 class="modal-title text-center">Yeni bir şifre isteyin</h4>
</div>

<div style="margin-top:100px;" class="modal-body">
	<div class="row gap-20">
		
		<div class="col-xs-12 col-sm-12 col-md-12">
			<p class="mb-20">Size şifrenizi yenilemeniz için bir link göndereceğiz.</p>
		</div>
		
		<div class="col-xs-12 col-sm-12 col-md-12">

			<div class="form-group"> 
				<label>E-Posta Adresiniz</label>
				<input class="form-control" id="kullanici_mail" maxlength="100" placeholder="E-Posta adresinizi girin." type="text"> 
			</div>
		
		</div>

		
		
		<div class="col-xs-12 col-sm-12 col-md-12">
			<div class="login-box-box-action">
				 <a data-toggle="modal" href="#loginModal">Giriş Sayfası</a>
			</div>
		</div>


		
	</div>

	<div style="display: none;" class="alert alert-danger uyarikutu"></div>
</div>

<div style="margin-top:100px;" class="modal-footer text-center">
	<button type="button" class="btn btn-primary restorebuton">Gönder</button>
	<button type="button" data-dismiss="modal" class="btn btn-dark">Kapat</button>
</div>

<script type="text/javascript">
	
$('.restorebuton').click(function(){

	

var kullanici_mail=$.trim($('#kullanici_mail').val());

if (kullanici_mail.length==0) {

$('.uyarikutu').show();
$('.uyarikutu').html('E-Posta adresinizi girin.');

} else {

$('.restorebuton').prop('disabled',true);
$('.restorebuton').html("<img style='width:18px;height:18px;' src='css/images/flex-loader.gif'>");

	$.ajax({
            type : 'POST',
            url : 'ajax.php',
            data : {'sifremiunuttum':'ok','kullanici_mail':kullanici_mail},
            success : function(sonuc){

            	sonuc=$.trim(sonuc);

            	if (sonuc=='kullanicibulunamadi') {

$('.uyarikutu').show();
$('.uyarikutu').html("Bu e-posta adresine kayıtlı bir hesap bulunmuyor.");
$('.restorebuton').prop('disabled',false);
$('.restorebuton').html("GÖNDER");

            	} else if (sonuc=='mailgonderilmis'){

$('.uyarikutu').show();
$('.uyarikutu').html("Yenileme linki zaten gönderildi.");
$('.restorebuton').prop('disabled',false);
$('.restorebuton').html("GÖNDER");


            	} else if (sonuc=='ok'){

            		swal({
  title: "Başarılı",
  text: "Şifrenizi yenilemek için e-posta adresinize bir link yolladık. Lütfen kontrol edin.",
  icon: "success",
  button: "OK",
});

           $('.modal').modal('hide');
            	};

            	

            	}

})
}

})

</script>