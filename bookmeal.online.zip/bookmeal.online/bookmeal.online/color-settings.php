<?php require_once 'header.php';

if (empty($kullanicioturum)) {
	
	header("Location:/");
	exit;
};

$restoransec=$db->prepare("SELECT * from restoranlar where restoran_id=:id");
$restoransec->execute(array(
"id" => $kullanicioturumcek['restoran_id']
));

$restorancek=$restoransec->fetch(PDO::FETCH_ASSOC);

$restoran_renk=$restorancek['restoran_renk'];

 ?>


<style type="text/css">
	
	.renkseclink div {

height: 90px;
	}

	

</style>

<title>Renk Ayarları</title>
		<!-- start Main Wrapper -->
		<div class="main-wrapper scrollspy-container">
		
			<!-- start hero-header -->
			

			<div class="container pt-10 pb-30">

				<input type="hidden" id="restoran_id" value="<?php echo $restorancek['restoran_id']; ?>" name="">
			
				
				
				<div  class="row mt-40 mb-30">

					<div class="col-xs-12 col-sm-12 col-sm-offset-1 col-md-10">
						
						<div  class="submite-list-wrapper">
						
							<h4>Mevcut Ana Renk</h4>

							<hr>
							
							<div class="submite-list-box">
							
								

									<div id="current-color" style="margin-right:10px;height: 90px;background: <?php echo $restoran_renk; ?>;" class="col-md-2 col-sm-2 col-xs-6"></div>
									

											
											
											
											
										

									</div>




									
									
									
								</div>

								



							</div>

							<?php $renkler=array("F80A02","F9051B","CC0618","D10C0C","B20C0C","C80404","A70B0B","EC0E06","DE170F","C4110A","AD0E08","910A04","961B15","610E0A","F32A0B","E22204","E32A0D","CF250A","FB2908","DE270A","F05D09","D34F04","FA1F01","C44B05","E15605","C94F08","F37708","E07413","F99D07","DA8906","E85D0D","E62E15","C61800","9B1604","871505","F24A06","DC4306","F78002","DC760A","DC760A","FAA701","E79D0A","F8D305","F2BC04","FCC403","EBBB14","D9EE02","C1D20F","C2D503","BACB08","B1C013","C8DB06","AFBF09","ABD50F","C0F107","8EBA0D","94C20C","7DB60B","61E703","5BD506","52C303","4CB007","5ACB0C","4AAB07","419507","388701","3F8410","2D6805","39780F","07F419","02DA12","09D133","047B1D","068B22","06751A","055E15","07E69F","0CA474","0B8A62","046D4C","04543B","084331","0CB1B9","0A9BA2","03898F","08696D","084F52","094571","083252","09273E","0438FA","0E36CD","112C93","042397","041A6F","081751","030D32","9B0CDD","830BBA","6C079B","5F0787","480E63","691D8C","6B2E88","46195B","2F103E","DE08CB","BF11B0","A7109A","A30695","E22ED2","A42598","8C097F","68045E","46042D","5F063D","63082A","47051E","320616","8E0329","AD0432","AD0420","76081A","FAD403","D3B308","C6A807","BA9E08","AC930B","B9CD0C","ABBD0B","9EAF08","93A20A","86A20A","A0F305","89CF08","80BD10","71A80B","679A09","5FFA06","56D40D","49C302","43A609","8BC34A","2ADD35","08FA30","0DE531","00CF23","06BA24","19AD32","15962B","20B439","13F156","07DE48","09934E","11AD5F","00A955","0FFA9D","02EE90","0CCC7F","02AF6A","28B093","28B0B0","24CDC6","106DB0","045895","03487A","033961","032E4E","156AA9","235C86","3A7FB2","235ABB","0C46AD","0D57D9","073FEF","070BEF","140F9D","4C197C","430D76","430280","8403C4","3C0756","43125B","804E98","FB05FB","FA2EFA","B41FB4","270827","27081F","FC0453","DB0F50","BD2A59","801033","BF052C","BD1337","0A0108","050004",); ?>

							<div style="margin-top:50px;" class="col-xs-12 col-sm-12 col-sm-offset-1 col-md-10">
						
						<div  class="submite-list-wrapper">

							<div class="col-md-6 col-sm-6 col-xs-12">
								<h4>Yeni Renk Seçin</h4>
							</div>

							<div align="right" class="col-md-6 col-sm-6 col-xs-12">
								<div class="sidebar-mini-search mb-20">
												<div class="input-group">
													<input id="colorcode" type="text" class="form-control" maxlength="10" placeholder="Renk Kodu (Örn. #043D75)">
													<span class="input-group-btn">
														<button class="btn btn-primary colorcodeapply" type="button">UYGULA</button>
													</span>
												</div>
											</div>
							</div>

						
							  

							<hr>
							
							<div class="submite-list-box">

								<?php foreach ($renkler as $renk) { ?>
									
									<a class="renkseclink" name="renk_<?php echo $renk; ?>" href='javascript:void(0);'><div style="margin-right:10px;margin-bottom:15px;background: #<?php echo $renk; ?>;" class="col-md-1 col-sm-1 col-xs-2"></div></a>

								<?php } ?>
							
								

									
									

											
											
											
											
										

									</div>




									
									
									
								</div>

								



							</div>


						</div>
						
					</div>

				</div>

			</div>
			
		</div>
		
		<?php require_once 'footer.php'; ?>
	    <script type="text/javascript">

	    	$('.colorcodeapply').click(function(){

var renkkodu = $.trim($('#colorcode').val());

if (renkkodu.length!=7) {

 swal({
  title: "Bilgi",
  text: "Renk kodu 7 karakterden oluşmalıdır. (# Kullanın)",
  icon: "info",
  button: "OK",

});

} else {

	$('.colorcodeapply').prop('disabled', true);

	 var restoran_id=$('#restoran_id').val();

 $.ajax({
            type : 'POST',
            url : 'ajax.php',
            data : {'renkkoduisle':'ok','restoran_id':restoran_id,'renkkodu':renkkodu},
            success : function(sonuc){

            	

              sonuc=$.trim(sonuc);

              if (sonuc=='kodisletamam') {

              	$('#current-color').css('background-color',renkkodu);
                swal({
  title: "Ana Renk Değiştirildi!",
  icon: "success",
  button: "OK",
});


    $('#colorcode').val("");
    $('.colorcodeapply').prop('disabled', false);


              }
               

               
            }
        })

}


	    	})
	    
	    $('.renkseclink').click(function(){

	    	

       var name=$(this).attr("name");
             var kod=name.substring(5);
             var restoran_id=$('#restoran_id').val();

             $.ajax({
            type : 'POST',
            url : 'ajax.php',
            data : {'renkdegistir':'ok','restoran_id':restoran_id,'renkkodu':kod},
            success : function(sonuc){

            	

              sonuc=$.trim(sonuc);

              if (sonuc=='islemtamam') {
                
                $('#current-color').css('background-color',"#"+kod);
                swal({
  title: "Ana Renk Değiştirildi!",
  icon: "success",
  button: "OK",
});




              }
               

               

            }
        })

	    })

	    </script>