<?php require_once 'header.php'; ?>
<title>Fiyatlandırma</title>
<?php if ($kullanicioturumcek['kullanici_yetki']==1 or $uyelik_turu==4 or $uyelik_turu==3 or $uyelik_turu==1 or $uyelik_turu==2) {
	header("Location:/");
} ?>

<style type="text/css">
	@import url(https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css);
@import url(https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,600);

	.help-page-wrapper .panel-default {
  margin-top: 0!important;
  border-radius: 0!important;
  border: none;
  box-shadow: none;
  margin-bottom: 3px;
  -webkit-transition: all 0.3s ease-out;
  -moz-transition: all 0.3s ease-out;
  -ms-transition: all 0.3s ease-out;
  -o-transition: all 0.3s ease-out;
  transition: all 0.3s ease-out;
}
.help-page-wrapper .panel-default:last-child {
  border-bottom: 0;
}
.help-page-wrapper .panel-default .panel-heading {
  border-top-left-radius: 0;
  border-top-right-radius: 0;
  background-color: #043D75 !important;
  padding: 0;
  -webkit-transition: all 0.3s ease-out;
  -moz-transition: all 0.3s ease-out;
  -ms-transition: all 0.3s ease-out;
  -o-transition: all 0.3s ease-out;
  transition: all 0.3s ease-out;
}
.help-page-wrapper .panel-default .panel-heading .panel-title a {
  color: #ffffff;
  font-size: 18px;
  padding: 13px 15px 15px;
  display: block;
}
.help-page-wrapper .panel-default .panel-heading .accordion-toggle {
  position: relative;
}
.help-page-wrapper .panel-default .panel-heading .accordion-toggle:after {
  font-family: FontAwesome;
  content: "\f0de";
  right: 15px;
  position: absolute;
  top: 15px;
  color: #ffffff;
  font-size: 18px;
  z-index: 1;
}
.help-page-wrapper .panel-default .panel-heading .accordion-toggle.collapsed:after {
  content: "\f0dd";
  font-family: FontAwesome;
}
.help-page-wrapper .panel-default .panel-collapse {
  background: #f5f5f5;
  -webkit-transition: all 0.3s ease-out;
  -moz-transition: all 0.3s ease-out;
  -ms-transition: all 0.3s ease-out;
  -o-transition: all 0.3s ease-out;
  transition: all 0.3s ease-out;
}
.help-page-wrapper .panel-default .panel-body {
  padding: 30px 50px;
}
.help-page-wrapper .panel-default .panel-body h3 {
  font-size: 20px;
  color: #444444;
  font-weight: 700;
}
.help-page-wrapper .panel-default .panel-body p {
  color: #707070;
}
.help-page-wrapper .panel-default .active {
  background: #f5f5f5;
  -webkit-transition: all 0.3s ease-out;
  -moz-transition: all 0.3s ease-out;
  -ms-transition: all 0.3s ease-out;
  -o-transition: all 0.3s ease-out;
  transition: all 0.3s ease-out;
}


.snip1404 {
  font-family: 'Source Sans Pro', Arial, sans-serif;
  color: #043d75;
  text-align: left;
  font-size: 16px;
  width: 100%;
  max-width: 1200px;

}

.plan header {

border-bottom: 1px solid rgba(0, 0, 0, 0.2);
padding-bottom: 10px;

}

.snip1404 .plan {
  margin: 0;
  width: 25%;
  position: relative;
  float: left;
  overflow: hidden;
  
  box-shadow: 0 0 5px rgba(0, 0, 0, 0.3);
  background-color: #ffffff;
}
.snip1404 .plan:hover i,
.snip1404 .plan.hover i {
  -webkit-transform: scale(1.2);
  transform: scale(1.2);
}
.snip1404 .plan:first-of-type {
  border-radius: 8px 0 0 8px;
}
.snip1404 .plan:last-of-type {
  border-radius: 0 8px 8px 0;
}
.snip1404 * {
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  -webkit-transition: all 0.25s ease-out;
  transition: all 0.25s ease-out;
}

.snip1404 .plan-title {
  background-color: #043d75;
  position: relative;
  margin: 0;
  padding: 20px 20px 0;
  text-transform: uppercase;
  letter-spacing: 4px;
}
.snip1404 .plan-title:after {
  position: absolute;
  content: '';
  top: 100%;
  left: 0;
  width: 0;
  height: 0;
  border-style: solid;
  border-width: 40px 300px 0 0;
  border-color: #043d75 transparent transparent;
}
.snip1404 .plan-cost {
  padding: 40px 20px 10px;
  text-align: right;
  color:#043d75;
}
.snip1404 .plan-price {
  font-weight: 600;
  font-size: 3em;
}
.snip1404 .plan-type {
  opacity: 0.8;
  font-size: 0.7em;
  text-transform: uppercase;
}
.snip1404 .plan-features {
  padding: 0 0 20px;
  margin: 0;
  list-style: outside none none;
  margin-top:20px;
}
.snip1404 .plan-features li {
  padding: 8px 5%;
  color:#626262;
}
.snip1404 .plan-features i {
  margin-right: 8px;
  color: #043d75;
}
.snip1404 .plan-select {
  border-top: 1px solid rgba(0, 0, 0, 0.2);
  padding: 20px;
  text-align: center;
}
.snip1404 .plan-select a {
  background-color: #043d75;
  color: #ffffff;
  text-decoration: none;
  padding: 12px 20px;
  font-size: 0.75em;
  font-weight: 600;
  border-radius: 20px;
  text-transform: uppercase;
  letter-spacing: 4px;
  display: inline-block;
}
.snip1404 .plan-select a:hover {
  background-color: #db3947;
}
.snip1404 .featured {
  margin-top: -10px;
  border-color: #331926;
  box-shadow: 0 0 25px rgba(0, 0, 0, 0.4);
  z-index: 1;
  border-radius: 8px;
}
.snip1404 .featured .plan-select {
  padding: 30px 20px;
}
@media only screen and (max-width: 767px) {
  .snip1404 .plan {
    width: 50%;
  }
  .snip1404 .plan-title,
  .snip1404 .plan-select a {
    -webkit-transform: translateY(0);
    transform: translateY(0);
  }
  .snip1404 .plan-select,
  .snip1404 .featured .plan-select {
    padding: 20px;
  }
  .snip1404 .featured {
    margin-top: 0;
  }
}
@media only screen and (max-width: 440px) {
  .snip1404 .plan {
    width: 100%;
  }


}

@media only screen and (min-width: 441px) {
  

  .plan-features {

    height: 380px;
  }
}

</style>


		
		<!-- start Main Wrapper -->
		<div  class="main-wrapper scrollspy-container">




		  <div class="hero hero-breadcrumb" style="background-color:#043d75;">
      
        <div class="container">

          <?php if ($uyelik_turu=="expired") { ?>

            <h1>Deneme sürümünüz doldu<br><h4 style="color: #ffffff;">Hizmet almaya devam edebilmek için aşağıdan bir üyelik planı seçin.</h4></h1>
            

        <?php  } else { ?>

        <h1>14 Gün Ücretsiz Deneyin<br><h4 style="color: #ffffff;">Kredi kartı gerekmez.</h4></h1>
        <?php } ?>

          
          
        </div>
        
      </div>
			

			<div class="container pt-10 pb-30">

        <!-- start hero-header -->
    
			
				<div class="breadcrumb-wrapper">
					<ol class="breadcrumb">
						<li><a href="/">Anasayfa</a></li>
						<li class="active">Fiyatlandırma</li>
					</ol>
				</div>
						
			<div align="center" class="mt-40">

				<div class="row">
				
						<div class="col-md-8 col-md-offset-2">
						
							<div class="section-title-02 text-center">

								<h3><span>PLANLAR</span></h3>


								
								
							</div>
						
						</div>
						
					</div>

				

				<div class="snip1404">
  <div class="plan">
    <header>
      <h4 style="color:#fff;" class="plan-title">
        QR MENÜ
      </h4>
      <div class="plan-cost"><span class="plan-price">₺14</span><span class="plan-type">/Ay</span></div>
    </header>
    <ul  class="plan-features">
      <li><i class="ion-checkmark"> </i>QR Menü sahibi olun</li>
      <li><i class="ion-checkmark"> </i>Menünüzü dizayn edin</li>
      <li><i class="ion-checkmark"> </i>Yemeklerinizin resmini yükleyin.</li>
      <li><i class="ion-checkmark"> </i>24/7 canlı chat desteği</li>
    </ul>
    
    <?php if ($uyelik_turu=='expired') { ?>

    <div class="plan-select"><a href="checkout?membership=1">Satın Al</a></div>

   <?php } else { ?>

 <div class="plan-select"><a href="restaurant-submit">Şimdi Dene</a></div>

  <?php } ?>

  </div>
   <div class="plan">
    <header>
      <h4 style="color:#fff;" class="plan-title">
         
        ÖN SİPARİŞ
      </h4>
      <div class="plan-cost"><span class="plan-price">₺99</span><span class="plan-type">/Ay</span></div>
    </header>
    <ul  class="plan-features">
      <li><i class="ion-checkmark"> </i>Ön sipariş alın</li>
      <li><i class="ion-checkmark"> </i>Siparişlerinizi panel üzerinden yönetin</li>
      <li><i class="ion-checkmark"> </i>Geçmiş siparişlerinizi analiz edin</li>
      <li><i class="ion-checkmark"> </i>Menünüzü dizayn edin</li>
      <li><i class="ion-checkmark"> </i>Yemeklerinizin resmini yükleyin</li>
      <li><i class="ion-checkmark"> </i>24/7 canlı chat desteği</li>
    </ul>
    
    <?php if ($uyelik_turu=='expired') { ?>

    <div class="plan-select"><a href="checkout?membership=3">Satın Al</a></div>

   <?php } else { ?>

 <div class="plan-select"><a href="restaurant-submit">Şimdi Dene</a></div>

  <?php } ?>

  </div>
  <div class="plan">
    <header>
      <h4 style="color:#fff;" class="plan-title">
         
        QR SİPARİŞ
      </h4>
      <div class="plan-cost"><span class="plan-price">₺199</span><span class="plan-type">/Ay</span></div>
    </header>
    <ul  class="plan-features">
      <li><i class="ion-checkmark"> </i>QR Menü üzerinden sipariş alın</li>
      <li><i class="ion-checkmark"> </i>Siparişlerinizi panel üzerinden yönetin</li>
      <li><i class="ion-checkmark"> </i>Geçmiş siparişlerinizi analiz edin</li>
      <li><i class="ion-checkmark"> </i>Menünüzü dizayn edin.</li>
      <li><i class="ion-checkmark"> </i>Yemeklerinizin resmini yükleyin</li>
      <li><i class="ion-checkmark"> </i>24/7 canlı chat desteği</li>
 
    </ul>
     
    <?php if ($uyelik_turu=='expired') { ?>

    <div class="plan-select"><a href="checkout?membership=2">Satın Al</a></div>

   <?php } else { ?>

 <div class="plan-select"><a href="restaurant-submit">Şimdi Dene</a></div>

  <?php } ?>

  </div>
 
  <div class="plan">
    <header>
      <h4 style="color:#fff;" class="plan-title">
         
        KOMPLE
      </h4>
      <div class="plan-cost"><span class="plan-price">₺239</span><span class="plan-type">/Ay</span></div>
    </header>
    <ul class="plan-features">
      <li><i class="ion-checkmark"> </i>QR Menü üzerinden sipariş alın</li>
      <li><i class="ion-checkmark"> </i>Ön sipariş alın</li>
      <li><i class="ion-checkmark"> </i>İki tür siparişlerinizi de panel üzerinden basitçe yönetin</li>
      <li><i class="ion-checkmark"> </i>Geçmiş siparişlerinizi analiz edin</li>
      <li><i class="ion-checkmark"> </i>Menünüzü dizayn edin</li>
      <li><i class="ion-checkmark"> </i>Yemeklerinizin resmini yükleyin</li>
      <li><i class="ion-checkmark"> </i>24/7 canlı chat desteği</li>
    </ul>
     
    <?php if ($uyelik_turu=='expired') { ?>

    <div class="plan-select"><a href="checkout?membership=4">Satın Al</a></div>

   <?php } else { ?>

 <div class="plan-select"><a href="restaurant-submit">Şimdi Dene</a></div>

  <?php } ?>

  </div>
</div>




			</div>
				
			</div>

      

     

      <div style="margin-top:80px;" class="container">



          <div class="row">
        
            <div class="col-md-8 col-md-offset-2">
            
              <div class="section-title-02 text-center">

                <h3><span>SSS</span></h3>


                
                
              </div>
            
            </div>
            
          </div>

          <div class="inner-page-details inner-page-padding"> 
                        <div class="panel-group help-page-wrapper" id="accordion">
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <div class="panel-title">
                                        <a aria-expanded="false" class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseOne">
                                           1. 14 günlük denemede hangi özellikleri kullanabilirim?
                                        </a>
                                    </div>
                                </div>
                                <div aria-expanded="false" id="collapseOne" role="tabpanel" class="panel-collapse collapse">
                                    <div class="panel-body">
                                        
                                        <p style="font-size:22px;color: black;">Deneme sürümü boyunca <b>Komple</b> pakete sahip olursunuz. Sağladığımız tüm imkanları kullanabilme imkanınız olur.</p>
                                        
                                    </div>
                                </div>
                            </div>
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <div class="panel-title">
                                        <a aria-expanded="false" class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo">
                                          2. Kredi kartı gerekli mi?
                                        </a>
                                    </div>
                                </div>
                                <div aria-expanded="false" id="collapseTwo" role="tabpanel" class="panel-collapse collapse">
                                    <div class="panel-body">
                                        <p style="font-size: 22px;color: black;"><b>Hayır</b>, Ürünümüzü deneyip satın almaya karar verene kadar kart bilgilerinizi girmeniz gerekmez.</p>
                                    </div>
                                </div>
                            </div>

                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <div class="panel-title">
                                        <a aria-expanded="false" class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseFive">
                                          3. Üyeliğimi istersem yükseltebilir miyim?
                                        </a>
                                    </div>
                                </div>
                                <div aria-expanded="false" id="collapseFive" role="tabpanel" class="panel-collapse collapse">
                                    <div class="panel-body">
                                        <p style="font-size: 22px;color: black;"><b>Evet</b>, üyelik planınızı isteğe bağlı güçlendirebilirsiniz.</p>
                                    </div>
                                </div>
                            </div>
                            
                             

                               

                           

                           

                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <div class="panel-title">
                                        <a aria-expanded="false" class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseEight">
                                           4. Siparişlerimi hangi cihazlar üzerinden yönetebilirim?
                                        </a>
                                    </div>
                                </div>
                                <div aria-expanded="false" id="collapseEight" role="tabpanel" class="panel-collapse collapse">
                                    <div class="panel-body">
                                         
                                         <p style="font-size:22px;color: black;">Farketmez, <b>Bilgisayar</b>, <b>Tablet</b> veya <b>Akıllı Telefon</b> üzerinden yönetebilirsiniz. BookMeal tüm cihazlarla uyumlu çalışır.</p>
                                        
                                    </div>
                                </div>
                            </div>    

                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <div class="panel-title">
                                        <a aria-expanded="false" class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseSix">
                                           5. Herhangi bir durumda size nasıl ulaşabilirim?
                                        </a>
                                    </div>
                                </div>
                                <div aria-expanded="false" id="collapseSix" role="tabpanel" class="panel-collapse collapse">
                                    <div class="panel-body">
                                        <p style="font-size: 22px;color: black;">Müşteri hizmetlerimize <b>24/7 sağ altta bulunan canlı chat yazılımı</b> aracılığıyla ulaşabilirsiniz. Size yardımcı olmaktan memnuniyet duyarız.</p>
                                    </div>
                                </div>
                            </div>  
 

                                                    
                        </div>
                    </div>
          

        </div>

		</div>
		<!-- end Main Wrapper -->
		
		<?php require_once 'footer.php'; ?>
		<script type="text/javascript">
			/* Demo purposes only */
$(".hover").mouseleave(
  function () {
    $(this).removeClass("hover");
  }
);

		</script>