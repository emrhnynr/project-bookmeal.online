<?php require_once 'header.php';

if (empty($kullanicioturum)) {
	
	header("Location:/");
}

 ?>
<title>Şifre Değiştir</title>
		<!-- start Main Wrapper -->
		<div class="main-wrapper scrollspy-container">
		
			<!-- start hero-header -->
			

			<div class="container pt-10 pb-30">
			
				<div class="breadcrumb-wrapper">
				
					<ol class="breadcrumb">
					
						<li><a href="/">Anasayfa</a></li>
						<li class="active">Şifre Değiştir</li>
						
					</ol>
					
				</div>
				
				<div style="min-height: 365px;" class="row mt-40 mb-30">

					<div class="col-xs-12 col-sm-10 col-sm-offset-1 col-md-8 col-md-offset-2">
						
						<div class="submite-list-wrapper">
						
							<div class="row">
					
								<div class="col-md-8">
								
									<div class="section-title-02 mb-20">

										<h3><span>Şifre Değiştir</span></h3>
									
										
									
									</div>
								
								</div>
								
							</div>
							
							<div class="submite-list-box">
							
								<div class="row">

									<form onsubmit="return false;" id="changepasswordform">
								
									<div class="col-xs-12 col-sm-12 mb-30-xs">
									
										<div class="row gap-20">
										
											<div class="col-xs-12 col-sm-12">
											
												<div class="form-group">
													<label>Mevcut Şifreniz*</label>
													<input type="password" maxlength="40" name="mevcut_sifre" class="form-control mevcut_sifre" />
												</div>
												
											</div>
											
											<div class="col-xs-12 col-sm-6">
											
												<div class="form-group">
													<label>Yeni Şifreniz*</label>
													<input type="password" maxlength="40" name="yeni_sifre" placeholder="Minimum 8 karakter" class="form-control yeni_sifre" />
												</div>
												
											</div>
											
											<div class="col-xs-12 col-sm-6">
											
												<div class="form-group">
													<label>Yeni Şifreniz Tekrar*</label>
													<input type="password" name="yeni_sifre_tekrar" placeholder="Yeni şifrenizi tekrar giriniz." maxlength="40" class="form-control yeni_sifre_tekrar" />
												</div>
												
											</div>

											<input type="hidden"  name="sifredegistir">

											<div class="col-xs-12 col-sm-12">
											
												
												<button id="changepasswordbutton" class="btn btn-primary mt-15">DEĞİŞTİR</button>
											
											</div>

											</form>
											
											
											
											
										</div>

									</div>
									
									
									
								</div>

							</div>

						</div>
						
					</div>

				</div>

			</div>
			
		</div>
		
		<?php require_once 'footer.php'; ?>
	    <script type="text/javascript">
	    	$('#changepasswordbutton').click(function(){

$('#changepasswordbutton').prop('disabled', true);
$('#changepasswordbutton').html('<img style="width:18px;height:18px;" src="css/images/flex-loader.gif">');


$.ajax({
            type : 'POST',
            url : 'ajax.php',
            data : $('#changepasswordform').serialize(),
            success : function(sonuc){

            	sonuc=$.trim(sonuc);

            	if (sonuc=="sifreyanlis") {

$('#changepasswordbutton').prop('disabled', false);
$('#changepasswordbutton').html('DEĞİŞTİR');
            		swal({
  title: "Yanlış Şifre",
  text: "Girdiğiniz mevcut şifre yanlış. Lütfen tekrar deneyin.",
  icon: "warning",
  button: "OK",
});
            	} else if(sonuc=="kisasifre"){

$('#changepasswordbutton').prop('disabled', false);
$('#changepasswordbutton').html('DEĞİŞTİR');
 swal({
  title: "Kısa Şifre",
  text: "Şifreniz minimum 8 karakter içermelidir.",
  icon: "warning",
  button: "OK",
});
            	} else if(sonuc=="uyusmayansifre"){


$('#changepasswordbutton').prop('disabled', false);
$('#changepasswordbutton').html('DEĞİŞTİR');
swal({
  title: "Yeni şifreler uyuşmuyor.",
  text: "Girdiğiniz yeni şifreler uyuşmuyor.",
  icon: "warning",
  button: "OK",
});
            	} else if(sonuc=="hata"){

$('#changepasswordbutton').prop('disabled', false);
$('#changepasswordbutton').html('DEĞİŞTİR');
swal({
  title: "Bir şeyler ters gitti.",
  icon: "error",
  button: "OK",
});

            	} else if(sonuc=="ok"){


$('.mevcut_sifre, .yeni_sifre, .yeni_sifre_tekrar').val('');
$('#changepasswordbutton').prop('disabled', false);
$('#changepasswordbutton').html('DEĞİŞTİR');

swal({
  title: "Şifreniz Değiştirildi!",
  icon: "success",
  button: "OK",
});





            	}
               
            }
        })
	    		
	    	})
	    </script>