
<?php require_once 'header.php'; 

if ($uyelik_turu!=2 and $uyelik_turu!=4) {
	
	header("Location:/");
	exit;
};

$restoranpanelsec=$db->prepare("SELECT * from restoranlar where restoran_id=:id");
$restoranpanelsec->execute(array(
"id" => $kullanicioturumcek['restoran_id']
));

$restoranpanelcek=$restoranpanelsec->fetch(PDO::FETCH_ASSOC);

$restoran_id=$restoranpanelcek['restoran_id'];

$restoran_currency=$restoranpanelcek['restoran_currency'];

	

?>

<input type="hidden" id="restoran_id" value="<?php echo $restoran_id; ?>" name="">
<input type="hidden" id="restoran_currency" value="<?php echo $restoran_currency; ?>" name="">

<title>Geçmiş Ön Siparişler</title>


		
		<!-- start Main Wrapper -->
		<div  class="main-wrapper scrollspy-container">
		
			

			
			<!-- end hero-header -->

			<div  class="container pt-10 pb-30">
			
				
				
				<div class="row mb-10">
				
					<div class="col-md-8">
					
						<div style="margin-top: 30px;" class="section-title-02">
							

							

							<h3><span>GEÇMİŞ ÖN SİPARİŞLER</span></h3>

							<select style="margin-top:20px;" class="form-control zamandegistir">
					<option value="tumzamanlar" selected="">Tüm Zamanlar</option>
					<option value="bugun">Bugün</option>
					<option value="dun">Dün</option>
					<option value="buay">Bu Ay</option>
					<option value="gecenay">Geçen Ay</option>
					<option value="buhafta">Son 1 Hafta</option>
				</select>
					
						
						</div>
					
					</div>
					
				</div>

				
	
				<div class="row gecmisonsiparisler"></div>
				
			</div>

		
			
		</div>
		<!-- end Main Wrapper -->

		<?php require_once 'footer.php';?>
		<script type="text/javascript">
			
			$('.zamandegistir').change(function(){


 var zamandilimi = $(this).val();
 var restoran_id = $('#restoran_id').val();
 var restoran_currency = $('#restoran_currency').val();
 $('.gecmisonsiparisler').html('<h3 align="center">Yükleniyor...</h3>');

 $.ajax({
            type : 'POST',
            url : 'ajax.php',
            data : {'restoran_id':restoran_id,'gecmisonsipariszamandilimidegistir':'ok',"restoran_currency":restoran_currency,"zamandilimi":zamandilimi},
            success : function(sonuc){

            	sonuc=$.trim(sonuc);

            	$('.gecmisonsiparisler').html(sonuc);

            	 }

            	});



			}).change();

		</script>
			
			