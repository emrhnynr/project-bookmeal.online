<?php require_once 'header.php';

if ($kullanicioturumcek['kullanici_mailonay']!="no") {
	
	header("Location:/");
	exit;
}


 ?>
<title>E-Posta Aktivasyon</title>
		<!-- start Main Wrapper -->
		<div class="main-wrapper scrollspy-container">
		
			<!-- start hero-header -->
			

			<div class="container pt-10 pb-30">

				
			
				
				
				<div style="min-height: 380px;" class="row mt-40 mb-30">



					<div class="col-xs-12 col-sm-10 col-sm-offset-1 col-md-8 col-md-offset-2">
						
						<div style="margin-top:50px;" class="submite-list-wrapper">

							<div class="row">
					
								<div class="col-md-8">
								
									<div class="section-title-02 mb-20">

										<h3><span>Mail Aktivasyon</span></h3>
									
										
									
									</div>
								
								</div>
								
							</div>
						
							<div class="alert alert-info"><i class="fas fa-info-circle"></i> <b><?php echo $kullanicioturumcek['kullanici_mail']; ?></b> adresine bir aktivasyon kodu gönderdik. Lütfen eposta kutunuzu kontrol edip aktivasyon kodunu girin.<br>

								  <a id="sendagain" href="javascript:void(0);">● Yeni kod gönder</a><br>
							      <a id="changemail" href="javascript:void(0);">● Mail adresimi değiştir</a></div>
							
							<div class="submite-list-box">
							
								<div  class="row icerik">

									<form onsubmit="return false;" id="changepasswordform">
								
									<div  class="col-xs-12 col-sm-12 mb-30-xs">
									
										<div class="row gap-20">
										
											<div class="col-xs-12 col-sm-12">
											
												<div class="form-group">
													<label>Aktivasyon Kodu</label>
													<input type="text" maxlength="40" name="kullanici_aktivasyonkod" class="form-control" />
												</div>
												
											</div>
											
											
											
											

											

											<div class="col-xs-12 col-sm-12">
											
												
												<button id="activationbutton" class="btn btn-primary mt-15">GÖNDER</button>
											
											</div>

											</form>

											


											
											
											
											
										</div>

									</div>
									
									
									
								</div>

							</div>

						</div>
						
					</div>

				</div>

			</div>
			
		</div>
		
		<?php require_once 'footer.php'; ?>
	    <script type="text/javascript">

$('#sendagain').click(function(){

$.ajax({
            type : 'POST',
            url : 'ajax.php',
            data : {"yenikodgonder":"ok"},
            success : function(sonuc){



sonuc=$.trim(sonuc);

if (sonuc=='ok') {

swal({
  title: "Yeni kod eposta adresinize gönderildi.",
  icon: "success",
  button: "OK",
});

}
            	

            	 }
        })


});


$('#changemail').click(function(){


$('.icerik').html('<form onsubmit="return false;" id="changemailform"><div  class="col-xs-12 col-sm-12 mb-30-xs"><div class="row gap-20"><div class="col-xs-12 col-sm-12"><div class="form-group">	<label>Yeni eposta adresiniz</label>	<input type="email" maxlength="100" name="kullanici_mail" placeholder="Yeni eposta adresinizi girin" class="form-control kullanicimail" /><input type="hidden" name="changemail"></div></div><div class="col-xs-12 col-sm-12"><button id="changemailbutton" class="btn btn-primary mt-15">GÖNDER</button></div></form>');


$('.alert-info').remove();

$('#changemailbutton').click(function(){

	$('#changemailbutton').prop('disabled',true);
	$('#changemailbutton').html("<img style='width:18px;height:18px;' src='css/images/flex-loader.gif'>");

var kullanici_mail=$.trim($('.kullanicimail').val());

if (kullanici_mail.length<=3) {

$('#changemailbutton').prop('disabled',false);
$('#changemailbutton').html("GÖNDER");
swal({
  title: "Lütfen eposta adresinizi kontrol edin.",
  icon: "warning",
  button: "OK",
});

} else {

$.ajax({
            type : 'POST',
            url : 'ajax.php',
            data : $('#changemailform').serialize(),
            success : function(sonuc){

            	sonuc=$.trim(sonuc);

            	if (sonuc=='aynimail') {


$('#changemailbutton').prop('disabled',false);
swal({
  title: "Mail adresiniz mevcut olanla aynı olamaz.",
  icon: "warning",
  button: "OK",
});

$('#changemailbutton').html("GÖNDER");

            	} else if(sonuc=='mevcutmail'){

$('#changemailbutton').prop('disabled',false);
swal({
  title: "Bu eposta adresi zaten mevcut.",
  icon: "warning",
  button: "OK",
});

$('#changemailbutton').html("GÖNDER");

            	} else if(sonuc=="ok"){

window.location.reload();

            	}

            	
               
            }
        })

}


});

});



	    	$('#activationbutton').click(function(){

	    		$('#activationbutton').prop('disabled',true);
	    		$('#activationbutton').html('Aktif Ediliyor...');
	    		kod=$.trim($('[name="kullanici_aktivasyonkod"]').val());

	    		$.ajax({
            type : 'POST',
            url : 'ajax.php',
            data : {"kullanici_aktivasyonkod":kod,"uyelikaktivasyon":"ok"},
            success : function(sonuc){

            	sonuc=$.trim(sonuc);

            	

            	if (sonuc=="yanliskod") {

            $('#activationbutton').prop('disabled',false);
	    		$('#activationbutton').html('GÖNDER');
	    		swal({
  title: "Aktivasyon kodu yanlış.",
  icon: "warning",
  button: "OK",
});

            	} else if(sonuc=="kullaniciok"){
                     
                     swal({
  title: "Aktif Edildi!",
  icon: "success",
  button: "OK",
});
            		window.location = 'orders';

            	} else if(sonuc=="adminok"){

swal({
  title: "Aktif Edildi!",
  icon: "success",
  button: "OK",
});
            		window.location = 'mypanel';

            	}
               
            }
        })
	    	})
	    </script>