<?php require_once 'baglann.php';

require_once 'fonksiyon.php';

 $ip_adresi=$_SERVER['REMOTE_ADDR'];
 date_default_timezone_set('Europe/Istanbul');
/*$query=@unserialize(file_get_contents('http://ip-api.com/php/'.$ip_adresi));


if($query && $query['status']=='success'){
    
     $timezone=$query['timezone'];
      date_default_timezone_set($timezone);
      
      
} else {
    
    date_default_timezone_set('America/Los_Angeles');
} */

if (empty($_POST) and empty($_GET)) {
  
  header("Location:/");



}  else if ($_GET['siparissil']=="ok"){


$siparis_id=$_GET['siparis_id'];

$siparissec=$db->prepare("SELECT * from siparisler where siparis_id=:id");
$siparissec->execute(array(
"id" => $siparis_id
));

$sipariscek=$siparissec->fetch(PDO::FETCH_ASSOC);

if ($sipariscek['kullanici_id']!=$_COOKIE['kullanici_id'] or $sipariscek['siparis_bildirim']==1) {
  
  header("orders");
  exit;
}


$hazirla=$db->prepare("DELETE from siparisler where siparis_id=:id and siparis_turu=:turu");
$derle=$hazirla->execute(array(
"id" => $siparis_id,
"turu" => 1
));

$hazirla2=$db->prepare("DELETE from siparisyemek where siparis_id=:id and siparisyemek_turu=:turu");
$derle2=$hazirla2->execute(array(
"id" => $siparis_id,
"turu" => 1
));

header("Location:orders?siparissil=ok");

} else if(isset($_POST['mail_konu'])){

$mail_ad=$_POST['mail_ad'];
$mail_konu=$_POST['mail_konu'];
$mail_text=$_POST['mail_text'];
$mail_adres=$_POST['mail_adres'];

require("phpmailer/class/class.phpmailer.php");

  $mail = new PHPMailer(); // Sinifimizi $mail degiskenine atadik
 $mail->CharSet  ="utf-8";
 $mail->Encoding="base64";
$mail->IsSMTP();  // Mailimizin SMTP ile gönderilecegini belirtiyoruz
$mail->Host     = "smtpout.secureserver.net";//"localhost"; //SMTP server adresi
$mail->Port     = '80'; 
$mail->SMTPAuth = true; //SMTP server'a kullanici adi ile baglanilcagini belirtiyoruz.
$mail->Username = "help@bookmeal.online";//"admin@localhost"; //SMTP kullanici adi
$mail->Password = "386Emirhan.";//""; //SMTP mailinizin sifresi
$mail->SMTPSecure = 'SSL';
$mail->From     = $mail_adres;//"admin@localhost"; //Gönderen kisminda yer alacak e-mail adresi
$mail->FromName = $mail_ad;//"PHP Mailer";//gönderenin ismi
$mail->AddAddress('help@bookmeal.online'); // Mail gönderilecek adresleri ekliyoruz.
$mail->IsHTML(true); //Mailimizin HTML formatinda hazirlanacagini bildiriyoruz.
$mail->Subject  = $mail_konu;//"Deneme Maili"; // Mailin Konusu Konu


  $mail->Body = $mail_text;
  
  if ($mail->Send()) {

    header("Location:contact?mail=success");

  } else {

   header("Location:contact");
  }

} else if ($_GET['qrkodlarindir']=="ok"){

 $restoran_id=$_GET['restoran_id'];

 $kullanicisec=$db->prepare("SELECT * from kullanici where kullanici_id=:id");
 $kullanicisec->execute(array(
"id" => $_COOKIE['kullanici_id']
 ));

 $kullanicicek=$kullanicisec->fetch(PDO::FETCH_ASSOC);
 


 if ($kullanicicek['restoran_id']!=$restoran_id) {
   
header("Location:/");
exit;

 };

$qrkodsec=$db->prepare("SELECT * from qrkodlar where restoran_id=:id");
$qrkodsec->execute(array(
"id" => $restoran_id
));




if (extension_loaded('zip')) {

  $zip = new ZipArchive();
  $zipAdi = "qrkodlar.zip";

  if ($zip->open($zipAdi, ZIPARCHIVE::CREATE)) {

    while ($qrkodcek=$qrkodsec->fetch(PDO::FETCH_ASSOC)) {
      
      $qr=$qrkodcek['qr_foto'];
      $zip->addFile($qr);
    };

    $zip->close();
        
        if (file_exists($zipAdi)) {
      
      header("Content-type: application/zip");
      header("Content-disposition: attachment; filename={$zipAdi}");
      readfile($zipAdi);
      unlink($zipAdi);

      echo "ok";

    } else {

      echo "File exist problemi";
    }
    
    
  } else {
    echo "Zip dosyası açılamadı.";
  }
  
} else {

  echo "zip extension yüklenemedi.";
}


} 















 ?>