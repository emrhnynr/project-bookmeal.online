<?php require_once 'header.php'; ?>
<title>Gizlilik</title>

<div class="main-wrapper scrollspy-container">
		
			<!-- start hero-header -->
			
			<div class="container pt-10 pb-30">


				
			
				
				
				<div style="padding: 50px;" class="row mt-40 mb-30">
					
					<h2 align="center">Gizlilik Sözleşmesi</h2>

					<p>İşbu Gizlilik Politikası'nın amacı, www.bookmeal.online adresinde yer alan siteye ("Site", "Uygulama", "Platform") üye olarak kaydolan kişiler ("Kullanıcı(lar)", "Yetkili Kişi") tarafından Site'de yer alan Platform'dan faydalanılması aşamasında Bookmeal Teknoloji A.Ş. ("Şirket") ile paylaşılan bilgi ve verilerin kullanımına ilişkin koşul ve şartları tespit etmektir. Gizlilik Politikası, Kullanıcı ile akdedilen Kullanıcı Sözleşmesi'nin eki ve ayrılmaz bir parçası niteliğindedir.</p>

					<b>Kullanıcı tarafından Site'ye yüklenen İçerik, Kullanıcı'nın mülkiyetindedir. Şirket, bu İçerik'i Kullanıcı'nın önceden onayını almaksızın açıklamayacak veya satmayacaktır.</b>

					<p>Şirket, Bookmeal üzerinden kendisine elektronik ortamdan iletilen İçerikleri'i Kullanıcılar ile yaptığı Kullanıcı Sözleşmesi'nde belirlenen amaçlar ve kapsam dışında üçüncü kişilere açıklamayacaktır.</p>

					<p>Bu kapsamda Şirket, İçerikler'i kesinlikle özel ve gizli tutmayı, bunu bir sır saklama yükümü olarak addetmeyi ve gizliliğin sağlanması ve sürdürülmesi, gizli bilginin tamamının veya herhangi bir kısmının kamu alanına girmesini veya yetkisiz kullanımını veya üçüncü bir kişiye ifşasını önlemek için gerekli tüm tedbirleri almayı ve gerekli özeni göstermeyi taahhüt etmektedir.</p>

					<p>Şirket, İçerikler’i sipariş bilgilendirmesi gibi talep edilen hizmetlerin sağlanması amacıyla kullanıcının müşterilerine, kullanıcının onayı ile 3. Parti kişilere aktarabilir.</p>

					<p>Kişisel bilgiler Kullanıcı ile temas kurmak veya Kullanıcı’nın Site’deki tecrübesini iyileştirmek (Hizmetlere ilişkin bakım ve destek, mevcut hizmetlerin geliştirilmesi/güncellenmesi, yeni hizmetler oluşturulması ve kişiye özel hizmetler sunulması gibi) amacıyla kullanılabileceği gibi veri tabanı oluşturma, üyeliklerin sürdürülmesi ve Şirket’in hizmetlerinin Kullanıcı’ya sağlanması için gerekli olan diğer faaliyetleri gerçekleştirme amacıyla da işleyebilecek, saklayabilecek ve üçüncü kişilere aktarabilecektir.</p>

					<p>Şirket, Kullanıcı’nın Site üzerinde gerçekleştirdiği kullanım ve işlem bilgilerini anonim hale getirerek; istatistiki değerlendirmelerde, performans değerlendirmelerinde, Şirket ve iş ortaklarının pazarlama kampanyalarında, yıllık rapor ve benzeri raporlarda kullanmak üzere bu amaçların gerçekleştirilmesi için gereken sürede saklayabilir, işleyebilir ve iş ortaklarına iletebilir.</p>

					<p>Site üzerinden düzenlenebilecek olan periyodik veya periyodik olmayan anketlere cevap veren ve kişisel bilgilerinin işlenmesi konusunda rıza gösteren Kullanıcılar’dan talep edilen bilgiler, Şirket tarafından bu kişilere doğrudan pazarlama yapmak, istatistiki analiz yapmak ve veri tabanı oluşturmak amacıyla kullanılabilecektir.</p>

					<p>Şirket ayrıca, aşağıdaki koşulların varlığı halinde Kullanıcı’ya ait bilgileri üçüncü kişilerle paylaşabilecektir:</p>

					<ul>
						<li><b>*</b> Kullanıcı Sözleşmesi kapsamındaki yükümlülüklerin yerine getirilmesi için ilgili ifşanın zorunlu olması,</li><br>
						<li><b>*</b> Yetkili idari ve adli bir kurum tarafından ilgili mevzuat doğrultusunda usulüne göre yürütülen bir araştırma veya soruşturmanın yürütümü amacıyla kullanıcılarla ilgili bilgi talep edilmesi,</li><br>
						<li><b>*</b> Kullanıcıların hakları veya güvenliklerini korumak için bilgi vermenin gerekli olması.</li>
					</ul>

					<p>Sistemle ilgili teknik sorunların tanımlanması ve çözülmesi için, Şirket gereken hallerde kullanıcıların IP adresini tespit etmek ve kullanmak durumunda kalabilir. IP adresleri, ayrıca kullanıcıları genel bir şekilde tanımlamak ve kapsamlı demografik bilgi toplamak amacıyla da kullanılabilir.</p>

					<p>Şirket, yukarıda anılan amaçlarla ilgili verileri Kullanıcı’nın ikamet ettiği ülke dışında dünyanın herhangi bir yerinde bulunan sunucularına (sunucular kendisine, bağlı şirketlerine veya alt yüklenicilerine ait olabilir) aktarma hakkına sahiptir.</p>

					<p>Site üzerinden başka site ve uygulamalara link verilmesi mümkün olup, Şirket’in bu site ve uygulamaların gizlilik uygulamaları ve içeriklerine yönelik herhangi bir sorumluluk taşımamaktadır. Şirket, işbu Gizlilik Politikası hükümlerini dilediği zaman Site’de yayımlamak suretiyle değiştirebilir. Şirket’in değişiklik yaptığı Gizlilik Politikası hükümleri Site’de yayınlandığı tarihte yürürlük kazanır.</p>

					


				</div>
						
					</div>

				</div>

			


<?php require_once 'footer.php'; ?>