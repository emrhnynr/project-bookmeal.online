

<?php require_once 'header.php'; ?>

<head>
	<style type="text/css">

		
		
		.hero .container {

			margin-top:50px;
		}

		
.imagee img {

	width: 500px;
	height: 500px;
}

		.help-page-wrapper .panel-default {
  margin-top: 0!important;
  border-radius: 0!important;
  border: none;
  box-shadow: none;
  margin-bottom: 3px;
  -webkit-transition: all 0.3s ease-out;
  -moz-transition: all 0.3s ease-out;
  -ms-transition: all 0.3s ease-out;
  -o-transition: all 0.3s ease-out;
  transition: all 0.3s ease-out;
}
.help-page-wrapper .panel-default:last-child {
  border-bottom: 0;
}
.help-page-wrapper .panel-default .panel-heading {
  border-top-left-radius: 0;
  border-top-right-radius: 0;
  background-color: #043D75 !important;
  padding: 0;
  -webkit-transition: all 0.3s ease-out;
  -moz-transition: all 0.3s ease-out;
  -ms-transition: all 0.3s ease-out;
  -o-transition: all 0.3s ease-out;
  transition: all 0.3s ease-out;
}
.help-page-wrapper .panel-default .panel-heading .panel-title a {
  color: #ffffff;
  font-size: 18px;
  padding: 13px 15px 15px;
  display: block;
}
.help-page-wrapper .panel-default .panel-heading .accordion-toggle {
  position: relative;
}
.help-page-wrapper .panel-default .panel-heading .accordion-toggle:after {
  font-family: FontAwesome;
  content: "\f0de";
  right: 15px;
  position: absolute;
  top: 15px;
  color: #ffffff;
  font-size: 18px;
  z-index: 1;
}
.help-page-wrapper .panel-default .panel-heading .accordion-toggle.collapsed:after {
  content: "\f0dd";
  font-family: FontAwesome;
}
.help-page-wrapper .panel-default .panel-collapse {
  background: #f5f5f5;
  -webkit-transition: all 0.3s ease-out;
  -moz-transition: all 0.3s ease-out;
  -ms-transition: all 0.3s ease-out;
  -o-transition: all 0.3s ease-out;
  transition: all 0.3s ease-out;
}
.help-page-wrapper .panel-default .panel-body {
  padding: 30px 50px;
}
.help-page-wrapper .panel-default .panel-body h3 {
  font-size: 20px;
  color: #444444;
  font-weight: 700;
}
.help-page-wrapper .panel-default .panel-body p {
  color: #707070;
}
.help-page-wrapper .panel-default .active {
  background: #f5f5f5;
  -webkit-transition: all 0.3s ease-out;
  -moz-transition: all 0.3s ease-out;
  -ms-transition: all 0.3s ease-out;
  -o-transition: all 0.3s ease-out;
  transition: all 0.3s ease-out;
}

		

		
		




		
.herometin {

	margin-top:100px;
}

@media only screen and (max-width: 1920px){ 

.indexgetpre {

		margin-top:300px;
	}

	.howto {

		height: 700px;
	}

	.howto1,.howto2 {

		margin-top:100px;
	}

	

  }

@media only screen and (max-width: 1750px){ 

	.indexgetpre {

		margin-top:200px;
	}

	.howto {

		height: 660px;
	}

	.howto1,.howto2 {

		margin-top:90px;
	}

	.commoncontainer {

		height: 700px;
	}

  }

@media only screen and (max-width: 1536px){
  




	.howto {

		height: 630px;
	}

	.howto1,.howto2 {

		margin-top:90px;
	}

}
		
@media only screen and (max-width: 1366px) {


 .commoncontainer {

			height: 600px;
		}
	

	.howto {

		height: 600px;
	}

	.howto1,.howto2 {

		margin-top:90px;
	}





	  }

	  @media only screen and  (max-width: 1024px) {


  .margintop0 {

  	margin-top: 40px;
  }
	  	  }
		

		@media only screen and  (max-width: 991px) {

			.imagee img {

	width: 450px;
	height: 450px;
}

			.howto {

		height: 600px;
	}

	.howto1,.howto2 {

		margin-top:90px;
	}


.indexgetpre1,.indexgetpre3,.indexgetpre2 {

			margin-top:50px;
		}


		.getpreimg {

			margin-left:120px;
			height: 450px;
			width: 450px;
		}


		.customizeimg {

			margin-left:120px;
			height: 450px;
			width: 450px;
		}

		.responsiveimg {

			margin-left:145px;
			height: 400px;
			width: 400px;
		}

		.supportimg {

margin-left:145px;
			height: 400px;
			width: 400px;


		}

 .margintop0 {

 	margin-top:0;
 }

			  }

			  @media only screen and  (max-width: 991px) {

			.imagee img {

	width: 420px;
	height: 420px;
}

  }

			  @media only screen  and (max-width: 767px) {

            
        .howitworkcontainer {

margin-top:150px;

        }

			  	.hero .container {

			margin-top:30px;
		}

			  	.imagee img {
    
    margin-top:20px;
	width: 350px;
	height: 350px;
}

			  	.getpreimg {

			margin-left:120px;
			
			
		}


		.customizeimg {

			margin-left:120px;
			
		}

		.responsiveimg {

			margin-left:200px;
			height: 320px;
         width: 320px;
			
		}

		.supportimg {

margin-left:200px;
margin-top:30px;
height: 300px;
width: 300px;
			

		}

			  	.howto {

		height: 1010px;
	}

	.howto1,.howto2 {

		margin-top:90px;
	}


.herometin {

	margin-top:0px;
}
			  	  }

			  @media only screen  and (max-width: 600px) {

			  	.imagee img {

	width: 300px;
	height: 300px;
}

			  	.herometin {

	margin-top:0px;
}

			  	

			  	#world-map-gdp {
height: 350px;

		}

.indexgetpre1,.indexgetpre3,.indexgetpre2 {

			margin-top:50px;
		}


		.getpreimg {

			margin-left:40px;
			height: 450px;
			width: 450px;
		}


		.customizeimg {

			margin-left:40px;
			height: 450px;
			width: 450px;
		}

		.responsiveimg {

			margin-left:40px;
			height: 450px;
			width: 450px;
		}

		.supportimg {

margin-left:40px;
			height: 450px;
			width: 450px;

		}
			  }

			  @media only screen and  (max-width: 414px) {

			  	.imagee img {

	width: 280px;
	height: 280px;
}

			  	.herometin {

	margin-top:0px;
}

			  	#world-map-gdp {
height: 250px;

		}

.indexgetpre1,.indexgetpre3,.indexgetpre2 {

			margin-top:80px;
		}


		.getpreimg {


			
			height: 275px;
			width: 275px;
		}


		.customizeimg {

			
			height: 275px;
			width: 275px;
		}

		.responsiveimg {

			
			height: 275px;
			width: 275px;
		}

		.supportimg {


			height: 275px;
			width: 275px;

		}
			  }

			   @media only screen  and (max-width: 393px) {

			   .imagee img {

	width: 265px;
	height: 265px;
}

			   	.herometin {

	margin-top:0px;
}

			   	#world-map-gdp {
height: 210px;

		}

.indexgetpre1,.indexgetpre3,.indexgetpre2 {

			margin-top:80px;
		}


		.getpreimg {


			margin-left:50px;
			height: 240px;
			width: 240px;
		}


		.customizeimg {

			margin-left:50px;
			height: 240px;
			width: 240px;
		}

		.responsiveimg {

			margin-left:50px;
			height: 240px;
			width: 240px;
		}

		.supportimg {

            margin-left:50px;
			height: 240px;
			width: 240px;

		}
			  }

			  @media only screen and  (max-width: 380px) {



			  	.howto1,.howto2 {

		margin-top:70px;
	}

			  	.herometin {

	margin-top:0px;
}

.indexgetpre1,.indexgetpre3,.indexgetpre2 {

			margin-top:80px;
		}


		.getpreimg {


			
			height: 230px;
			width: 230px;
		}


		.customizeimg {

			
			height: 230px;
			width: 230px;
		}

		.responsiveimg {

			
			height: 230px;
			width: 230px;
		}

		.supportimg {


			height: 230px;
			width: 230px;

		}
			  }

			  @media only screen and  (max-width: 365px) {



			  	.herometin {

	margin-top:0px;
}

.indexgetpre1,.indexgetpre3,.indexgetpre2 {

			margin-top:80px;
		}


		.getpreimg {


			
			height: 220px;
			width: 220px;
		}


		.customizeimg {

			
			height: 220px;
			width: 220px;
		}

		.responsiveimg {

			
			height: 220px;
			width: 220px;
		}

		.supportimg {


			height: 220px;
			width: 220px;

		}

		.bottombutton {

			font-size: 10px;
		}


			  }

			  @media only screen and (max-width: 335px) {

			  	.herometin {

	margin-top:0px;
}

			  	#world-map-gdp {
height: 170px;

		}

.indexgetpre1,.indexgetpre3,.indexgetpre2 {

			margin-top:80px;
		}


		.getpreimg {


			
			height: 190px;
			width: 190px;
		}


		.customizeimg {

			
			height: 190px;
			width: 190px;
		}

		.responsiveimg {

			
			height: 190px;
			width: 190px;
		}

		.supportimg {


			height: 190px;
			width: 190px;

		}
			  }

			  .mainbutton {

			  	background: #DB3947;
			  	border: 1px solid #DB3947;
			  }

			  .mainbutton:hover {

          background: #BA0600;
			  	border: 1px solid #BA0600;

			  }

			  
		/*@media only screen and (max-width: 991px) {

 

 .indexgetpre1 {

 	margin-top:90px;
 }

 .indexgetpre3 {

 	margin-top:40px;
 }

 .indexgetpre4 {

 	margin-top:40px;
 }



		}

		@media only screen and (max-width: 400px) {

 .hero {

 	background-image:url('images/hero-header/girisfoto2_mobile.jpg');
 }

 .herotext {

 	margin-top:50px;
 }


		}*/




	</style>
</head>

<title>BookMeal | Yeni Nesil Sipariş Yönetim Yazılımı</title>
<!-- end Header -- >




<?php

if ($uyelik_turu==3 or $uyelik_turu==4) {
	
	header("Location:mypanel");

} else if($uyelik_turu==2){

header("Location:preorders");

} else if($uyelik_turu==1){

header("Location:qr-codes");

} else if($kullanicioturumcek['kullanici_yetki']==1){

    header("Location:orders");
}

 ?>



 
 





		<!-- start Main Wrapper -->
	
	
		
		<!-- start Main Wrapper -->
		<div style="background: white;" class="main-wrapper scrollspy-container">
		
			<!-- start hero-header -->
			<div style="padding-top:50px;background-image :radial-gradient(#1763AE 5%,#043D75);" class="hero text-center">
				<div  class="container">

					<div class="row">


					
						<div class="col-xs-12 col-sm-6 col-md-6 herotext herometin">
						
										<h1 style="color: #fff;" class="indextitle">Artık 25% Daha Az Garsona İhtiyacınız Var</h1>
										<p>Bookmeal yazılımı restoran & cafelere maliyet azaltımı sağlarken müşteri memnuniyetini artırmalarına yardımcı olur.</p>

							<a class="btn btn-primary mt-15 mainbutton" href="restaurant-submit">Şimdi Ücretsiz Deneyin <i class="fas fa-chevron-right"></i></a>



							


							


						
							
							
						
						</div>

						<div  class="col-xs-12 col-sm-6 col-md-6 herotext herofoto">
							
							<div style="margin-bottom:50px;position: relative;" align="center" class="imagee">
								<img style="border-radius: 10px;" data-src="images/hero-header/arkaplann.jpg" class="lazyload">

							</div>
						</div>
						
					</div>

				</div>
				
			</div>
			<!-- end hero-header -->

		
			
			
			<section style="padding-top: 0;">

				

			
				
					
					<div >


						
						<div style="margin-top:40px;" class="container howitworkcontainer">
							<div class="row">
								<h3 style='font-weight: 500;font-size: 40px;color: #043D75;' align="center">Nasıl Çalışır?</h3>

								<div style="margin-bottom:100px;" class="col-xs-12 col-sm-12 col-md-12">

									

									<div style="margin-top:30px;" class="col-xs-12 col-sm-6 col-md-6">
										<div class="image" align="center"><img style="width: 100px;height: 100px;" data-src="images/how-it-work/qr-menu.png" class="lazyload"></div>
										<div class="content" style="font-size: 20px;margin-top:9px;" align="center">Yönetici hesabınızı oluşturun, menünüzü girin, temel restoran bilgilerinizi girin, logonuzu yükleyin.</div>
									</div>
									
									<div style="margin-top:30px;" class="col-xs-12 col-sm-6 col-md-6">
										<div class="image" align="center"><img style="width: 100px;height: 100px;" data-src="images/how-it-work/artist.png" class="lazyload"></div>
										<div class="content" style="font-size: 20px;margin-top:9px;" align="center">QR Menünüzü tasarlayın, hepsini tek bir tıkla indirin ve masa numarasına göre yerleştirin.</div>
									</div>
									
									<div style="margin-top:30px;" class="col-xs-12 col-sm-6 col-md-6">
										<div class="image" align="center"><img style="width: 100px;height: 100px;" data-src="images/how-it-work/qr-code.png" class="lazyload"></div>
										<div class="content" style="font-size: 20px;margin-top:9px;" align="center">Müşterileriniz QR kodu tarasın, tüm menü ve yemekleri fotoğraflarıyla görüp 2 dakikada siparişini versin.</div>
									</div>
									
									<div style="margin-top:30px;" class="col-xs-12 col-sm-6 col-md-6">
										<div class="image" align="center"><img style="width: 100px;height: 100px;" data-src="images/how-it-work/responsive-design.png" class="lazyload"></div>
										<div class="content" style="font-size: 20px;margin-top:9px;" align="center">Siparişler bildirim sesiyle birlikte anında panelinize düşsün ve yemeği hazırlayıp ilgili masaya götürün. <i style='color: green;' class="fas fa-check"></i></div>
									</div>

									
								</div>
							</div>
						</div>

						

						 <div class="container">
						 	

					<div  class="row">

						


						
					
						<div style="margin-bottom:60px; margin-top: 40px;" class="col-xs-12 col-sm-10 col-sm-offset-1 col-md-10">
												
							
							<h3 align="center" style="font-weight: 700;color:#043D75;">QR Menünün Avantajları<i class="fas fa-chevron-down"></i></h3>
							

							 <div class="mt-40">

							 	<div class="row">



                 <div  class="how-it-work-wrapper">

								<div class="how-it-work-item">
							
									<div class="GridLex-gap-50">
									
										<div class="GridLex-grid-noGutter-equalHeight GridLex-grid-middle">

											<div class="GridLex-col-3_sm-5_xs-12">
												<div  class="image">
													<img class="lazyload" data-src="images/how-it-work/02.png" alt="Image" />
												</div>
											</div>
										
											<div class="GridLex-col-9_sm-7_xs-12">
												<div style="padding:10px;" class="content">
													<h3 style="font-weight: 500;color:#043D75;">Maliyetlerinizi 25% Azaltın</h3>
													<p style="font-size:18.5px;font-weight: 400;"> Garsonlarınız büyük çoğunlukla sipariş almaya gitmez, sadece siparişi masaya götürmekle ilgilenir. Bu da daha az garsona ihtiyacınız var demektir.</p>
													
												</div>
											</div>
											
											
											
										</div>

									</div>
									
								</div>


								
								<div class="how-it-work-item">
							
									<div class="GridLex-gap-50">
									
										<div class="GridLex-grid-noGutter-equalHeight GridLex-grid-middle">
										
											
											
											<div class="GridLex-col-9_sm-7_xs-12">
												<div style="padding:10px;" class="content">
													<h3 style="font-weight: 500;color: #043D75;">Müşteri Memnuniyetini Artırın</h3>
														
													<ul style="font-size: 18.5px;font-weight: 400;text-align: left;padding: 10px;">
													<li><i style="color: #043D75;" class="fas fa-angle-right"></i> Müşterileriniz garsonun sipariş almasını beklemek zorunda kalmaz.</li>
													<li><i style="color:#043D75;" class="fas fa-angle-right"></i> Müşterileriniz tüm yemekleri fotoğraflarıyla görebilir, kolayca sipariş verebilir ve sipariş zamanını kontrol edebilir.</li>
													</ul>											</div>
											</div>

											<div class="GridLex-col-3_sm-5_xs-12">
												<div  class="image">
													<img class="lazyload" data-src="images/how-it-work/03.png" alt="Image" />
												</div>
											</div>
											
										</div>

									</div>
									
								</div>
								
								<div class="how-it-work-item">
							
									<div class="GridLex-gap-50">
									
										<div class="GridLex-grid-noGutter-equalHeight GridLex-grid-middle">

												<div class="GridLex-col-3_sm-5_xs-12">
												<div  class="image">
													<img class="lazyload" data-src="images/how-it-work/01.png" alt="Image" />
												</div>
											</div>
											
											<div class="GridLex-col-9_sm-7_xs-12">
												<div class="content">
													<h3 style="font-weight: 500;color: #043D75;">Fiziksel menülerden kurtulun</h3>
													
													<ul style="font-size: 18.5px;font-weight: 400;text-align: left;padding-left: 20px;">
													<li><i style="color: #043D75;" class="fas fa-angle-right"></i>   Basım maliyetinden kurtulun.</li>
													<li><i style="color:#043D75;" class="fas fa-angle-right"></i>   Ürün ve fiyatları hızlıca güncelleyin.</li>
													<li><i style="color: #043D75;" class="fas fa-angle-right"></i>   Kampanya ve indirimleri kolayca duyurun.</li>
													<li><i style="color: #043D75;" class="fas fa-angle-right"></i>  Restoranınızda teması azaltın ve hijyeni artırın.</li>
													</ul>
												</div>
											</div>
											
										
											
										</div>

									</div>
									
								</div>


								
								

								
							
							</div>

							


							
					
					
					


					</div>

					
					
			
				</div>  
				

							

							
					
						</div>
						
					</div>

					</div> 



					



	<div style="background-image :radial-gradient(#1763AE 5%,#043D75);" class="container commoncontainer">

	<div  class="row">
		
		

		<div class="col-sm-12 col-xs-12 col-md-6">
			<div  align="center" class="content indexgetpre indexgetpre1">
													<h3 style="font-weight: 500;color: #fff;">ÖN SİPARİŞ ALIN</h3>
													<p style="font-size:18.5px;font-weight: 400;color:#fff;">Menünüzü oluşturduğunuzda, restoranınıza özel bir subdomain oluştururuz <span style='color: #fff;'>(myrestaurant.bookmeal.online)</span> ve müşterileriniz restoranınıza varmadan bu linkten ön sipariş verebilirler.</p>												</div>
		</div>

		<div class="col-sm-12 col-xs-12 col-md-6">
			<div  class="image getpreimg">
				<img class="lazyload" data-src="images/how-it-work/05.png">
			</div>
		</div>

	</div>

	</div>





												
							
							
							

							 

							 	<div style="margin-bottom:60px;margin-top:60px;" class="container">

							 	<div class="row">



                 <div  class="how-it-work-wrapper">

								<div class="how-it-work-item">
							
									<div class="GridLex-gap-50">
									
										<div class="GridLex-grid-noGutter-equalHeight GridLex-grid-middle">

											<div class="GridLex-col-5_sm-5_xs-12">
												<div  class="image">
													<img class="lazyload" data-src="images/how-it-work/satisfaction.png" alt="Image" />
												</div>
											</div>
										
											<div class="GridLex-col-7_sm-7_xs-12">
												<div style="padding:10px;" class="content">
													
													<h3 style="font-weight: 500;color: #043D75;">Müşterileriniz İçin Ekstra Hizmet</h3>
													<p style="font-size:18.5px;font-weight: 400;">İstatistiklere göre, Müşterilerin 66%'sı restoranda sipariş beklemekten şikayetçi. Ön sipariş sistemi sayesinde bu müşterileri sadık müşterileriniz haline getirebilirsiniz.</p>
												</div>
											</div>
											
											
											
										</div>

									</div>
									
								</div>


								
								
								
								


								
								

								
							
							</div>

							


							
					
					
					


					</div>

					

					
					
			
			
				

							

							
					
						</div>



	<div style="margin-top:40px;background-image :radial-gradient(#1763AE 5%,#043D75);" class="container commoncontainer">

	<div class="row">

		
		
		

		<div class="col-sm-12 col-xs-12 col-md-6">
			<div  align="center" class="content indexgetpre indexgetpre2">
													<h3 style="font-weight: 500;color: #fff;">Özelleştirilebilir QR Menüler</h3>
													<p style="font-size:18.5px;font-weight: 400;color: #fff;">Sipariş sayfanızı ve QR kartınızı 200'e yakın renkten birini seçerek özelleştirebilirsiniz. Kendi şablonunuzu kullanmak isterseniz de, Yalnızca QR kodları indirip QR kartlarını dizayn ettirebilirsiniz.</p>												</div>
		</div>

		<div class="col-sm-12 col-xs-12 col-md-6">
			<div style="margin-top:50px;" class="image customizeimg">
				<img class="lazyload" data-src="images/how-it-work/04.png">
			</div>
		</div>

		

	</div>

	


</div>



	<div style="margin-top: 50px;"  class="container commoncontainer">

	<div class="row">
		
		

		

		<div class="col-sm-12 col-xs-12 col-md-6">
			<div class="image responsiveimg">
				<img class="lazyload" data-src="images/how-it-work/08.png">
			</div>
		</div>

		<div class="col-sm-12 col-xs-12 col-md-6">
			<div align="center" class="content indexgetpre indexgetpre3">
													<h3 style="font-weight: 500;color: #043D75;">BASİT, HIZLI,<br>UYUMLU</h3>
													<p style="font-size:18.5px;font-weight: 400;">Bookmeal yazılımı hem müşteriler hem de yöneticiler için oldukça kolay ve etkilidir. Kullanıcı deneyimine büyük önem verilerek hazırlandı. Dahası, tüm cihazlarda kolayca kullanılabilir.</p>												</div>
		</div>

		

	</div>

	


</div>



	<div  style="margin-top:40px;" class="container commoncontainer">

	<div class="row">

		
		
		

		<div  class="col-sm-12 col-xs-12 col-md-8">
			<div  align="center" class="content indexgetpre margintop0">
													<h3 style="font-weight: 500;color: #043D75;">24/7 Canlı Chat Desteği</h3>
													<p style="font-size:18.5px;font-weight: 400;">Bize dilediğiniz zaman sağ alttaki canlı chat aracılığıyla ulaşabilir, şikayet ve önerilerinizi bizimle paylaşabilirsiniz. Destek ekibimiz çevrimiçi ise size anında cevap verirler, değil ise bıraktığınız eposta adresinden size en kısa sürede dönüş yaparlar.</p>												</div>
		</div>

		<div class="col-sm-12 col-xs-12 col-md-4">
			<div class="image supportimg indexgetpre4">
				<img class="lazyload" data-src="images/how-it-work/07.png">
			</div>
		</div>

		

	</div>


</div>








						

						

			
			


			

						

			

						
					
					</div>

				

				


				

				
			
			</section>

			<section>
			
				<div class="container">

					<div class="row">
				
						<div class="col-md-8 col-md-offset-2">
						
							<div class="section-title-02 text-center">

								<h3><span>Bookmeal Kim İçin?</span></h3>
								
								
							</div>
						
						</div>
						
					</div>
					
					<div class="GridLex-gap-30 GridLex-gap-20-mdd">
						
						<div class="GridLex-grid-noGutter-equalHeight">
						
							<div class="GridLex-col-3_sm-3_xs-6_xss-6">
							
								<div class="featured-icon text-center">
									<div class="icon text-primary">
										<i style="color: #043D75;" class="fas fa-utensils"></i>
									</div>
									<h5>Restoranlar</h5>
									
								</div>
								
							</div>

							<div class="GridLex-col-3_sm-3_xs-6_xss-6">
							
								<div class="featured-icon text-center">
									<div class="icon text-primary">
										<i style="color: #043D75;" class="fas fa-coffee"></i>
									</div>
									<h5>Kafeler</h5>
									
								</div>
								
							</div>

							<div class="GridLex-col-3_sm-3_xs-6_xss-6">
							
								<div class="featured-icon text-center">
									<div class="icon text-primary">
										<i style="color: #043D75;" class="fas fa-building"></i>
									</div>
									<h5>Oteller</h5>
									
								</div>
								
							</div>

							<div class="GridLex-col-3_sm-3_xs-6_xss-6">
							
								<div class="featured-icon text-center">
									<div class="icon text-primary">
										<i style="color: #043D75;" class="fas fa-glass-martini-alt"></i>
									</div>
									<h5>Barlar</h5>
									
								</div>
								
							</div>

							
							
						</div>
						
					</div>

				</div>


				<div style="margin-top:80px;" class="container">

					<div class="row">
				
						<div class="col-md-8 col-md-offset-2">
						
							<div class="section-title-02 text-center">

								<h3><span>SSS</span></h3>


								
								
							</div>
						
						</div>
						
					</div>

					<div class="inner-page-details inner-page-padding"> 
                        <div class="panel-group help-page-wrapper" id="accordion">
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <div class="panel-title">
                                        <a aria-expanded="false" class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseOne">
                                           1. Bookmeal Nedir?
                                        </a>
                                    </div>
                                </div>
                                <div aria-expanded="false" id="collapseOne" role="tabpanel" class="panel-collapse collapse">
                                    <div class="panel-body">
                                        
                                        <p style="font-size:22px;color: black;">Bookmeal, restoranlara QR Menü üzerinden ve Ön Sipariş almalarını sağlayan bir restoran verimlilik yazılımıdır. Ana amacımız <b>restoranların maliyetlerini azaltmak</b> ve <b>müşteri memnuniyetlerini artırmaktır</b>.</p>
                                        
                                    </div>
                                </div>
                            </div>
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <div class="panel-title">
                                        <a aria-expanded="false" class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo">
                                          2. COVID-19 Sürecinde Etkili Mi?
                                        </a>
                                    </div>
                                </div>
                                <div aria-expanded="false" id="collapseTwo" role="tabpanel" class="panel-collapse collapse">
                                    <div class="panel-body">
                                        <p style="font-size: 22px;color: black;"><b>Tabii ki</b>, daha öncelerde de çok beğenilen bir sistem olsa da, COVID sürecinde değeri daha iyi anlaşıldı. Birçok restoran QR Menü sistemleriyle COVID sürecini en az hasarla atlatıyor.</p>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <div class="panel-title">
                                        <a aria-expanded="false" class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseFour">
                                           3. Ücretsiz deneyebilir miyim?
                                        </a>
                                    </div>
                                </div>
                                <div aria-expanded="false" id="collapseFour" role="tabpanel" class="panel-collapse collapse">
                                    <div class="panel-body">
                                         
                                         <p style="font-size:22px;color: black;"><b>Evet,</b> Bookmeal yazılımını <b>14 gün</b> ücretsiz deneyebilirsiniz. <a href="restaurant-submit"><b>Şimdi Dene</b></a></p>
                                        
                                    </div>
                                </div>
                            </div>     

                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <div class="panel-title">
                                        <a aria-expanded="false" class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseFive">
                                           4. Kredi kartı gerekli mi?
                                        </a>
                                    </div>
                                </div>
                                <div aria-expanded="false" id="collapseFive" role="tabpanel" class="panel-collapse collapse">
                                    <div class="panel-body">
                                         
                                         <p style="font-size:22px;color: black;"><b>Hayır,</b> Siz deneyip satın almaya karar verene kadar kart bilgilerinize ihtiyaç duymayız. <a href="restaurant-submit"><b>Şimdi Dene</b></a></p>
                                        
                                    </div>
                                </div>
                            </div>      

                                

                            
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <div class="panel-title">
                                        <a aria-expanded="false" class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseEight">
                                           5. Siparişleri hangi cihazlardan yönetebilirim?
                                        </a>
                                    </div>
                                </div>
                                <div aria-expanded="false" id="collapseEight" role="tabpanel" class="panel-collapse collapse">
                                    <div class="panel-body">
                                         
                                         <p style="font-size:22px;color: black;"><b>Farketmez,</b> siparişlerinizi <b>PC, Tablet</b> ve <b>Akıllı telefonlarınız</b> aracılığıyla yönetebilirsiniz. Bookmeal tüm cihazlarla uyumlu çalışır.</p>
                                        
                                    </div>
                                </div>
                            </div>      
 

                                                    
                        </div>
                    </div>
					

				</div>

				

				
			
			</section>


			
			<section class="bg-white">
				
      <div class="container">
      	
				<div class="col-md-12 col-sm-12 col-xs-12" style="border-radius: 20px;background:rgba(219, 57, 68,0.1);height: 400px;padding: 55px;">
					<h4 style="color: #043D75;font-weight: 600;margin-top:30px;" align="center">YENİ NESİL <br>SİPARİŞ YÖNETİM SİSTEMİ</h4>
					<h4 style="color: #043D75;" align="center">Önce deneyin, beğenirseniz ödeyin.<br>
					Kredi kartı gerekmez.</h4>


							<div align="center" class="row mt-50">
					
								<div class="col-xs-12 col-xs-offset-0 col-sm-6 col-sm-offset-3 col-md-4 col-md-offset-4">
									<a href="restaurant-submit" class="btn btn-primary btn-block btn-lg bottombutton">14 GÜN DENEYİN <i class="ti-arrow-right"></i></a>
									<br>
									

								</div>
								
							</div>
							
						
				</div>

				</div>



			</section>


			
	
			
		</div>
		<!-- end Main Wrapper -->
		
		
		
		<!-- end Main Wrapper -->
		
	<?php require_once 'footer.php'; ?>
	<script type="text/javascript" src="js/lazysizes.js"></script>
	
    
    
     
	