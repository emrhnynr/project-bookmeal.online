<?php require_once 'header.php'; 

if ($kullanicioturumcek['kullanici_yetki']!=5) {
  
header("Location:/");

}

?>

<title>Rehber</title>

<style type="text/css">
	
	.help-page-wrapper .panel-default {
  margin-top: 0!important;
  border-radius: 0!important;
  border: none;
  box-shadow: none;
  margin-bottom: 3px;
  -webkit-transition: all 0.3s ease-out;
  -moz-transition: all 0.3s ease-out;
  -ms-transition: all 0.3s ease-out;
  -o-transition: all 0.3s ease-out;
  transition: all 0.3s ease-out;
}
.help-page-wrapper .panel-default:last-child {
  border-bottom: 0;
}
.help-page-wrapper .panel-default .panel-heading {
  border-top-left-radius: 0;
  border-top-right-radius: 0;
  background-color: #043D75 !important;
  padding: 0;
  -webkit-transition: all 0.3s ease-out;
  -moz-transition: all 0.3s ease-out;
  -ms-transition: all 0.3s ease-out;
  -o-transition: all 0.3s ease-out;
  transition: all 0.3s ease-out;
}
.help-page-wrapper .panel-default .panel-heading .panel-title a {
  color: #ffffff;
  font-size: 18px;
  padding: 13px 15px 15px;
  display: block;
}
.help-page-wrapper .panel-default .panel-heading .accordion-toggle {
  position: relative;
}
.help-page-wrapper .panel-default .panel-heading .accordion-toggle:after {
  font-family: FontAwesome;
  content: "\f0de";
  right: 15px;
  position: absolute;
  top: 15px;
  color: #ffffff;
  font-size: 18px;
  z-index: 1;
}
.help-page-wrapper .panel-default .panel-heading .accordion-toggle.collapsed:after {
  content: "\f0dd";
  font-family: FontAwesome;
}
.help-page-wrapper .panel-default .panel-collapse {
  background: #f5f5f5;
  -webkit-transition: all 0.3s ease-out;
  -moz-transition: all 0.3s ease-out;
  -ms-transition: all 0.3s ease-out;
  -o-transition: all 0.3s ease-out;
  transition: all 0.3s ease-out;
}
.help-page-wrapper .panel-default .panel-body {
  padding: 30px 50px;
}
.help-page-wrapper .panel-default .panel-body h3 {
  font-size: 20px;
  color: #444444;
  font-weight: 700;
}
.help-page-wrapper .panel-default .panel-body p {
  color: #707070;
}
.help-page-wrapper .panel-default .active {
  background: #f5f5f5;
  -webkit-transition: all 0.3s ease-out;
  -moz-transition: all 0.3s ease-out;
  -ms-transition: all 0.3s ease-out;
  -o-transition: all 0.3s ease-out;
  transition: all 0.3s ease-out;
}


</style>
		<!-- start Main Wrapper -->
		<div class="main-wrapper scrollspy-container">
		
			<!-- start hero-header -->
		
			<div class="container pt-10 pb-60">
			
				<div class="breadcrumb-wrapper">
					<ol class="breadcrumb">
						<li><a href="/">Anasayfa</a></li>
						<li class="active">Rehber</li>
					</ol>
				</div>
						
				<div class="mt-50">

					<div class="row">
					
						<div class="col-xs-12 col-sm-10 col-sm-offset-1 col-md-8 col-md-offset-2">

							<div class="faq-wrapper">
							
								<div class="faq-item">
									
									<h4><span class="text-primary mr-5">Q.</span> Nedir bu rehber?</h4>
									<p style="font-size: 17px;">Bu rehber Bookmeal yazılımını en kısa ve basit şekilde kullanmaya başlamanızı sağlayacak bilgileri size vermek için hazırlandı. Aşağıdaki yönergeleri takip ederek kullanmaya başlayabilirsiniz.</p>

									
								</div>

								<div class="inner-page-details inner-page-padding"> 
                        <div class="panel-group help-page-wrapper" id="accordion">
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <div class="panel-title">
                                        <a aria-expanded="false" class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseOne">
                                           1. Menü Ekle/Düzenle
                                        </a>
                                    </div>
                                </div>
                                <div aria-expanded="false" id="collapseOne" role="tabpanel" class="panel-collapse collapse">
                                    <div class="panel-body">
                                        
                                        <p style="font-size:22px;color: black;">Herşeyden önce, <a target="_blank" href="menu-settings"><b>buradan</b></a> menü oluşturmalısınız. Oluşturduktan sonra, tüm yemekleriniz için kolayca resim yükleyebilirsiniz. Menünüzü oluşturduğunuzda veya herhangi bir değişiklikte direkt <a href="r-<?php echo $headerrestorancek['restoran_seo']; ?>-1" target="_blank"><b>QR Sipariş Sayfanıza</b></a> giderek kontrolünüzü yapabilirsiniz.</p>
                                        
                                    </div>
                                </div>
                            </div>
                           
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <div class="panel-title">
                                        <a aria-expanded="false" class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseThree">
                                           2. Restoran Logosu Ekleme
                                        </a>
                                    </div>
                                </div>
                                <div aria-expanded="false" id="collapseThree" role="tabpanel" class="panel-collapse collapse">
                                    <div class="panel-body">
                                        <p style="font-size: 22px;color: black;">Kayıt aşamasında logo yüklemediyseniz, <a href="logo" target="_blank"><b>buradan</b></a> kolayca yükleyebilirsiniz. Logonuzun olması marka imajı açısından çok değerlidir. Logonuz tüm sipariş sayfalarınız ve <a href="qr-codes" target="_blank"><b>QR Menü Kartınızın</b></a> üst kısmına yerleştirilir.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <div class="panel-title">
                                        <a aria-expanded="false" class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseFour">
                                           3. QR Menüleri Masaya Yerleştirme
                                        </a>
                                    </div>
                                </div>
                                <div aria-expanded="false" id="collapseFour" role="tabpanel" class="panel-collapse collapse">
                                    <div class="panel-body">
                                         
                                         <p style="font-size:22px;color: black;">İlk olarak, <a href="qr-codes" target="_blank"><b>buradan</b></a> tüm QR Menüleri indirmeniz gerekiyor. Kartlar hazır olarak veya sadece QR Kodu olarak indirilebilir. Hazır versiyonunu indirdiyseniz direkt çıktı alabilirsiniz. Aksi taktirde kendiniz dizayn etmeniz gerekiyor. Çıktılar alındıktan sonra üzerindeki masa numarasına göre masalara yerleştirilir.</p>
                                        
                                    </div>
                                </div>
                            </div>     

                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <div class="panel-title">
                                        <a aria-expanded="false" class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseFive">
                                           4. Vardiya Saatleri Neden Gerekli?
                                        </a>
                                    </div>
                                </div>
                                <div aria-expanded="false" id="collapseFive" role="tabpanel" class="panel-collapse collapse">
                                    <div class="panel-body">
                                         
                                         <p style="font-size:22px;color: black;">Vardiya saatleri, <b>ön sipariş</b> sistemini kullanmak isteyen restoranlar için zorunludur. Müşterilerinizin ön siparişleri bu saatlere göre denetlenir. Boş bıraktığınız gün restoranınızı <b>kapalı</b> varsayarız.</p>
                                        
                                    </div>
                                </div>
                            </div>   

                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <div class="panel-title">
                                        <a aria-expanded="false" class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseSix">
                                           5. QR Menü ve Sipariş Sayfalarınızı Renklendirin
                                        </a>
                                    </div>
                                </div>
                                <div aria-expanded="false" id="collapseSix" role="tabpanel" class="panel-collapse collapse">
                                    <div class="panel-body">
                                         
                                         <p style="font-size:22px;color: black;"><a href="color-settings" target="_BLANK"><b>Renk Ayarları</b></a> sekmesinden restoranınıza özel rengi seçebilir, spesifik bir renk kodunuz varsa işleyebilirsiniz. Bu renk tüm sipariş sayfalarınızın ve QR Menü Kartınızın ana tema rengi olur.</p>
                                        
                                    </div>
                                </div>
                            </div>    

                            

                            
 

                                                    
                        </div>
                    </div>
					
								
								
							
							</div>
							
							<div class="notify-box mt-40 mb-0">
						
								<div class="notify-inner">
									
									<h4 class="text-uppercase">Öneri ve Görüşleriniz?</h4>
									
									<a href="contact" class="btn btn-primary btn-sm btn-absolute">Bize Ulaşın</a>
									
								</div>
							
							</div>
					
						</div>
					
					</div>

				</div>
				
			</div>

		</div>
		<!-- end Main Wrapper -->
		
		<?php require_once 'footer.php'; ?>