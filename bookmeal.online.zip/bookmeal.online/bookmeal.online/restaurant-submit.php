<?php require_once 'header.php'; 

if ($kullanicioturumcek['kullanici_asama']==2) {

	header("Location:/");exit;
}

?>

<?php if ($kullanicioturumcek['kullanici_asama']==1) { ?>

	<title>Restoran Bilgileri</title>

<?php } else { ?>

<title>Kullanmaya Başla</title>

<?php } ?>
		<!-- start Main Wrapper -->
		<div class="main-wrapper scrollspy-container">
		
			




			<div class="container pt-10 pb-30">
			
				<?php if ($kullanicioturumcek['kullanici_asama']!=1) { ?>

					<div class="breadcrumb-wrapper">
				
					<ol class="breadcrumb">
					
						<li><a href="/">Anasayfa</a></li>
						<li class="active">Kullanmaya Başla</li>
						
					</ol>
					
				</div>

				<?php } ?>
				
				<div class="row mt-40 mb-30">

					<div class="col-xs-12 col-sm-10 col-sm-offset-1 col-md-10 ">

						<?php if ($kullanicioturumcek['kullanici_asama']==1) { ?>

							<div class="submite-list-wrapper">

							<form onsubmit="return false;"  id="restaurantsubmitform">

							

							
							
							
						
							<div class="row">
					
								<div class="col-md-8">
								
									<div class="section-title-02 mb-20">

										<h3><span>Adım 2 : Restoran Bilgileri</span></h3>
									
										
									
									</div>
								
								</div>
								
							</div>

							
							
							
							<div class="submite-list-box">
							
								<div class="row ga-20">
								
									<div class="col-xs-12 col-sm-12">
									
										<div class="form-group form-group-lg">
										
											<label>Restoran Adı <span class="text-danger">*</span></label>
											<input type="text" name="restoran_ad" maxlength="80" class="form-control"/>
											
										</div>
									
									</div>

									<div class="col-xs-12 col-sm-12">
									
										<div class="form-group form-group-lg">
										
											<label>Restoran Subdomain (<b style='color:#043D75;'>xxxxx</b>.bookmeal.online) <span class="text-danger">*</span></label>
											<input type="text" name="restoran_subdomain" placeholder="örn.myrestaurant" maxlength="100" class="form-control"/>
											
										</div>
									
									</div>

									<div class="col-xs-12 col-sm-12">
									
										<div class="form-group form-group-lg">
										
											<label>Masa Sayısı <span class="text-danger">*</span></label>
											<select class="form-control" name="restoran_masasayisi" >
												<option value="0" disabled="" selected="">Masa Sayısını Seçin</option>
												<?php $optionsay=0;

												while ($optionsay<100) { $optionsay++; ?>
												 	
                 <option><?php echo $optionsay; ?></option>

												<?php } ?>
											</select>
											
										</div>
									
									</div>

									<div class="col-xs-12 col-sm-12">
									
										<div class="form-group form-group-lg">
										
											<label>Para Birimi <span class="text-danger">*</span></label>
											<select class="form-control" name="restoran_currency" >
												<option value="0" disabled="" selected="">Para Birimini Seçin</option>
												
												<option value="₺">TRY (₺)</option>
												<option value="$">USD ($)</option>
												<option value="₹">INR (₹)</option>
												<option value="€">EUR (€)</option>
												<option value="£">GBP (£)</option>
											</select>
											
										</div>
									
									</div>

									


									<div class="col-xs-12 col-sm-12">
									
										<div class="form-group">
										
											<label>Restoran Logo</label>
											<input type="file" name="restoran_logo" id="logo" class="form-control"/>
											
										</div>
									
									</div>


									
									
									
									
									
								</div>

								<h6 class="text-primary text-uppercase mt-15">Vardiya Saatleri<small style="font-size: 13px;"> (Doldurmadığınız gün restoranınız kapalı varsayarız.)</small><br><small>* Bu alanı daha sonra da doldurabilirsiniz.</small></h6>

								<div class="opening-hours-wrapper">
								
									<div class="opening-hours-box">
									
										<div class="row gap-20">
										
											<div class="col-xs-12 col-sm-6 col-md-6">


											
												<label class="day-name">Pazartesi</label> 

												
												<div class="row gap-10">
												
													<div class=" col-xs-6 col-sm-6 col-md-6">
													
														<div class="input-group from mb-15">
															<span class="input-group-addon">-dan</span>
															<input class="oh-timepicker form-control" type="time" name="restoran_pazartesiacilis">
														</div>
														
													</div>
													
													<div class=" col-xs-6 col-sm-6 col-md-6">
													
														<div class="input-group to mb-15">
															<span class="input-group-addon">-e</span>
															<input class="oh-timepicker form-control" type="time" name="restoran_pazartesikapanis">
														</div>
														
													</div>
													
												</div>
												
											</div>
											
											<div class="col-xs-12 col-sm-6 col-md-6">
											
												<label class="day-name">Salı</label>
												
												<div class="row gap-10">
												
													<div class=" col-xs-6 col-sm-6 col-md-6">
													
														<div class="input-group from mb-15">
															<span class="input-group-addon">-dan</span>
															<input class="oh-timepicker form-control" type="time" name="restoran_saliacilis">
														</div>
														
													</div>
													
													<div class=" col-xs-6 col-sm-6 col-md-6">
													
														<div class="input-group to mb-15">
															<span class="input-group-addon">-e</span>
															<input class="oh-timepicker form-control" type="time" name="restoran_salikapanis">
														</div>
														
													</div>
													
												</div>
												
											</div>
											
											<div class="col-xs-12 col-sm-6 col-md-6">
											
												<label class="day-name">Çarşamba</label>
												
												<div class="row gap-10">
												
													<div class=" col-xs-6 col-sm-6 col-md-6">
													
														<div class="input-group from mb-15">
															<span class="input-group-addon">-dan</span>
															<input class="oh-timepicker form-control" type="time" name="restoran_carsambaacilis">
														</div>
														
													</div>
													
													<div class=" col-xs-6 col-sm-6 col-md-6">
													
														<div class="input-group to mb-15">
															<span class="input-group-addon">-e</span>
															<input class="oh-timepicker form-control" type="time" name="restoran_carsambakapanis">
														</div>
														
													</div>
													
												</div>
												
											</div>
											
											<div class="col-xs-12 col-sm-6 col-md-6">
											
												<label class="day-name">Perşembe</label>
												
												<div class="row gap-10">
												
													<div class=" col-xs-6 col-sm-6 col-md-6">
													
														<div class="input-group from mb-15">
															<span class="input-group-addon">-dan</span>
															<input class="oh-timepicker form-control" type="time" name="restoran_persembeacilis">
														</div>
														
													</div>
													
													<div class=" col-xs-6 col-sm-6 col-md-6">
													
														<div class="input-group to mb-15">
															<span class="input-group-addon">-e</span>
															<input class="oh-timepicker form-control" type="time" name="restoran_persembekapanis">
														</div>
														
													</div>
													
												</div>
												
											</div>
											
											<div class="col-xs-12 col-sm-6 col-md-6">
											
												<label class="day-name">Cuma</label>
												
												<div class="row gap-10">
												
													<div class=" col-xs-6 col-sm-6 col-md-6">
													
														<div class="input-group from mb-15">
															<span class="input-group-addon">-dan</span>
															<input class="oh-timepicker form-control" type="time" name="restoran_cumaacilis">
														</div>
														
													</div>
													
													<div class=" col-xs-6 col-sm-6 col-md-6">
													
														<div class="input-group to mb-15">
															<span class="input-group-addon">-e</span>
															<input class="oh-timepicker form-control" type="time" name="restoran_cumakapanis">
														</div>
														
													</div>
													
												</div>
												
											</div>
											
											<div class="col-xs-12 col-sm-6 col-md-6">
											
												<label class="day-name">Cumartesi</label>
												
												<div class="row gap-10">
												
													<div class=" col-xs-6 col-sm-6 col-md-6">
													
														<div class="input-group from mb-15">
															<span class="input-group-addon">-dan</span>
															<input class="oh-timepicker form-control" type="time" name="restoran_cumartesiacilis">
														</div>
														
													</div>
													
													<div class=" col-xs-6 col-sm-6 col-md-6">
													
														<div class="input-group to mb-15">
															<span class="input-group-addon">-e</span>
															<input class="oh-timepicker form-control" type="time" name="restoran_cumartesikapanis">
														</div>
														
													</div>
													
												</div>
												
											</div>
											
											<div class="col-xs-12 col-sm-6 col-md-6">
											
												<label class="day-name">Pazar</label>
												
												<div class="row gap-10">
												
													<div class=" col-xs-6 col-sm-6 col-md-6">
													
														<div class="input-group from mb-15">
															<span class="input-group-addon">-dan</span>
															<input class="oh-timepicker form-control" type="time" name="restoran_pazaracilis">
														</div>
														
													</div>
													
													<div class=" col-xs-6 col-sm-6 col-md-6">
													
														<div class="input-group to mb-15">
															<span class="input-group-addon">-e</span>
															<input class="oh-timepicker form-control" type="time"  name="restoran_pazarkapanis">
														</div>
														
													</div>
													
												</div>
												
											</div>

										</div>
									
									</div>

								</div>

							
								
								
								
								
								
								
							</div>
							
							

							

							<div class="submite-list-box">

								

							

							


								
								
								
							</div>
							
							
							
							

							
							
							<div class="mt-30">
					

								<div style="display: none;" class="alert alert-danger uyarikutu" ></div>

								<input type="hidden" name="restaurantsubmit" >
								
								<button type="submit" id="restaurantsubmitbutton" class="btn btn-primary mt-15">KAYDI TAMAMLA</button><br>

								
							</div>

							</form>
							
						</div>
							
						<?php } else { ?>

							<div class="submite-list-wrapper">

							<form onsubmit="return false;"  id="ownerregisterform">

							<div class="row">
					
								<div class="col-md-8">
								
									<div class="section-title-02 mb-20">

										<h3><span>HESAP</span></h3>
									
										<p>Restoranınızı yönetmek için bir yönetici hesabı oluşturun.</p>
									
									</div>
								
								</div>
								
							</div>

							
							
							<div class="submite-list-box">
							
								
									<div class="row gap-20">


									<div class="col-xss-12 col-xs-12 col-sm-12">
												
										<div class="form-group">
											<label>E-Posta Adresiniz <span class="text-danger">*</span></label>
											<input type="text" name="kullanici_mail" placeholder="E-Posta adresinizi girin" maxlength="100" class="form-control"/>
										</div>
										
									</div>
									
									<div class="col-xss-12 col-xs-6 col-sm-6">
												
										<div class="form-group">
											<label>Şifre <span class="text-danger">*</span></label>
											<input type="password" name="kullanici_sifre" placeholder="Minimum 8 karakter" maxlength="40" class="form-control"/>
										</div>
										
									</div>
								
									
									
									<div class="col-xs-12 col-sm-12 col-md-6">
												
										<div class="form-group">
											<label>Şifre Tekrar <span class="text-danger">*</span></label>
											<input type="password" name="kullanici_sifretekrar" placeholder="Şifrenizi tekrar girin" maxlength="40" class="form-control"/>
										</div>
										
									</div>
									
									
									
									
									
									
									
									
									
								</div>
									
								
								
							</div>
						
							

							
							
							
							
							
							
							
							

							
							
							<div class="mt-30">
					
								<div align="center" class="checkbox-block font-icon-checkbox">
									
									<span class="" >Devam ederek <a target="_blank" href="terms-conditions" class="font700">Topluluk Sözleşmesi</a>'ni onaylamış olursunuz.</span>
								</div>

								<div style="display: none;" class="alert alert-danger uyarikutu" ></div>

								<input type="hidden" name="ownerregister">
								
								<button type="submit" id="ownerresgisterbutton" class="btn btn-primary mt-15">14 Günlük Denemeyi Başlat</button><br>

								
							</div>

							</form>
							
						</div>


					<?php } ?>
						
						
						
					</div>

				</div>

			</div>
			
		</div>
		
	<?php require_once 'footer.php'; ?>
	<script type="text/javascript" src="js/bootstrap3-wysihtml5.min.js"></script>
<script type="text/javascript" src="js/bootstrap-tokenfield.js"></script>
<script type="text/javascript" src="js/typeahead.bundle.min.js"></script>
<script type="text/javascript" src="js/jquery-ui.min.js"></script>
<script type="text/javascript" src="js/dropzone.min.js"></script>
<script type="text/javascript" src="js/jquery.ui.timepicker.js"></script>
<script type="text/javascript" src="js/infobox.js"></script>
<script type="text/javascript" src="js/richmarker-compiled.js"></script>
<script type="text/javascript" src="js/customs-submit.js"></script>
<script type="text/javascript">






$('#ownerresgisterbutton').click(function(){

$('#ownerresgisterbutton').prop('disabled', true);

var kullanici_mail=$.trim($('[name="kullanici_mail"]').val());
var kullanici_sifre=$('[name="kullanici_sifre"]').val();
var kullanici_sifretekrar=$('[name="kullanici_sifretekrar"]').val();

 if (kullanici_mail.length<6) {

 $('#ownerresgisterbutton').prop('disabled', false);
event.preventDefault();
$('.uyarikutu').show();
$('.uyarikutu').html('<i class="fas fa-info-circle"></i> Lütfen e-posta adresinizi kontrol edin.');

} else if(kullanici_sifre.length<8){

 $('#ownerresgisterbutton').prop('disabled', false);
event.preventDefault();
$('.uyarikutu').show();
$('.uyarikutu').html('<i class="fas fa-info-circle"></i> Şifreniz Minimum 8 karakterden oluşmalıdır.');

} else if(kullanici_sifre!=kullanici_sifretekrar){

 $('#ownerresgisterbutton').prop('disabled', false);
event.preventDefault();
$('.uyarikutu').show();
$('.uyarikutu').html('<i class="fas fa-info-circle"></i> Şifreler uyuşmuyor. Lütfen kontrol edin.');

} else {

	$('#ownerresgisterbutton').html("<img style='width:18px;height:18px;' src='css/images/flex-loader.gif'>");


		$.ajax({
            type : 'POST',
            url : 'ajax.php',
            data : $('#ownerregisterform').serialize(),
            success : function(sonuc){

            	//Created by emrhnynr1 - AJAX kullanıcı deneyimi etkisi


sonuc=$.trim(sonuc);

if (sonuc=='mevcutmail') {

$('#ownerresgisterbutton').prop('disabled', false);
$('#ownerresgisterbutton').html('14 GÜNLÜK DENEMEYİ BAŞLAT');
event.preventDefault();
$('.uyarikutu').show();
$('.uyarikutu').html('<i class="fas fa-info-circle"></i> Bu eposta adresi zaten mevcut.');

            	 } else if(sonuc=="hata"){

 $('#ownerresgisterbutton').prop('disabled', false);
 $('#ownerresgisterbutton').html('14 GÜNLÜK DENEMEYİ BAŞLAT');
event.preventDefault();
$('.uyarikutu').show();
$('.uyarikutu').html('<i class="fas fa-info-circle"></i> Bir şeyler ters gitti.');

            	 } else if (sonuc=="ok") {
                     
                
                    $('.uyarikutu').hide();
                    window.location = 'email-activation';
            	 	
            	 }

            	 }

            	})
}


});

	$('#restaurantsubmitbutton').click(function(){

 $('#restaurantsubmitbutton').prop('disabled', true);

var form = $('#restaurantsubmitform')[0];
var data = new FormData(form);



var restoran_ad=$.trim($('[name ="restoran_ad"]').val());
var restoran_subdomain=$.trim($('[name ="restoran_subdomain"]').val());
var restoran_currency=$('[name="restoran_currency"]').val();
var masasayisi=$('[name="restoran_masasayisi"]').val();
var logo=$("#logo").val();
var logouzanti = $('#logo').val().split('.').pop();


 if (restoran_ad.length<3) {

 $('#restaurantsubmitbutton').prop('disabled', false);
event.preventDefault();
$('.uyarikutu').show();
$('.uyarikutu').html('<i class="fas fa-info-circle"></i> Restoran ismi en az 3 karakter içermelidir.');

} else if (restoran_subdomain.length<2) {

 $('#restaurantsubmitbutton').prop('disabled', false);
event.preventDefault();
$('.uyarikutu').show();
$('.uyarikutu').html('<i class="fas fa-info-circle"></i> Restoran subdomain en az 2 karakter içermelidir.');

}  else if (masasayisi==null) {

 $('#restaurantsubmitbutton').prop('disabled', false);
event.preventDefault();
$('.uyarikutu').show();
$('.uyarikutu').html('<i class="fas fa-info-circle"></i> Lütfen masa sayısını seçin.');

} 

else if (restoran_currency==null) {

 $('#restaurantsubmitbutton').prop('disabled', false);
event.preventDefault();
$('.uyarikutu').show();
$('.uyarikutu').html('<i class="fas fa-info-circle"></i> Lütfen para birimini seçin.');

}
  else if(logo!="" && (logouzanti!='jpg' && logouzanti!='jpeg' && logouzanti!='png')){

$('#restaurantsubmitbutton').prop('disabled', false);
event.preventDefault();
$('.uyarikutu').show();
$('.uyarikutu').html("<i class='fas fa-info-circle'></i> Logonuzun uzantısı sadece <b>'.jpg, .png, .jpeg'</b> olabilir.");


}   else {

$('#restaurantsubmitbutton').html("<img style='width:18px;height:18px;' src='css/images/flex-loader.gif'>");


	$.ajax({
            type : 'POST',
            url : 'ajax.php',
            enctype : 'multipart/form-data',
            data : data,
            processData: false,
            contentType: false,
            cache: false,
            success : function(sonuc){

            	  sonuc=$.trim(sonuc);

            	  if (sonuc=='mevcutsubdomain') {

$('#restaurantsubmitbutton').prop('disabled', false);
$('#restaurantsubmitbutton').html("Başlayalım <i class='fas fa-arrow-right'></i>");
event.preventDefault();
$('.uyarikutu').show();
$('.uyarikutu').html('<i class="fas fa-info-circle"></i> Bu subdomain zaten mevcut.');

            	 } else if(sonuc=="hata"){

 $('#restaurantsubmitbutton').prop('disabled', false);
 $('#restaurantsubmitbutton').html("Başlayalım <i class='fas fa-arrow-right'></i>");
event.preventDefault();
$('.uyarikutu').show();
$('.uyarikutu').html('<i class="fas fa-info-circle"></i> Bir şeyler ters gitti.');

            	 } else if (sonuc=="ok") {
                     
                
                    $('.uyarikutu').hide();
                    window.location = 'mypanel';
            	 	
            	 }
               
            }
        })

    
}


	});




</script>